<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-28 03:44:16 --> Config Class Initialized
DEBUG - 2014-02-28 03:44:16 --> Hooks Class Initialized
DEBUG - 2014-02-28 03:44:16 --> Utf8 Class Initialized
DEBUG - 2014-02-28 03:44:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 03:44:16 --> URI Class Initialized
DEBUG - 2014-02-28 03:44:16 --> Router Class Initialized
DEBUG - 2014-02-28 03:44:16 --> Output Class Initialized
DEBUG - 2014-02-28 03:44:17 --> Security Class Initialized
DEBUG - 2014-02-28 03:44:17 --> Input Class Initialized
DEBUG - 2014-02-28 03:44:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 03:44:17 --> Language Class Initialized
DEBUG - 2014-02-28 03:44:17 --> Loader Class Initialized
DEBUG - 2014-02-28 03:44:17 --> Database Driver Class Initialized
ERROR - 2014-02-28 03:44:17 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\apps\career\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-02-28 03:44:18 --> Session Class Initialized
DEBUG - 2014-02-28 03:44:18 --> Helper loaded: string_helper
DEBUG - 2014-02-28 03:44:18 --> A session cookie was not found.
DEBUG - 2014-02-28 03:44:18 --> Session routines successfully run
DEBUG - 2014-02-28 03:44:18 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 03:44:18 --> User Agent Class Initialized
DEBUG - 2014-02-28 03:44:18 --> Controller Class Initialized
DEBUG - 2014-02-28 03:44:18 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 03:44:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-02-28 03:45:27 --> Config Class Initialized
DEBUG - 2014-02-28 03:45:27 --> Hooks Class Initialized
DEBUG - 2014-02-28 03:45:27 --> Utf8 Class Initialized
DEBUG - 2014-02-28 03:45:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 03:45:27 --> URI Class Initialized
DEBUG - 2014-02-28 03:45:27 --> Router Class Initialized
DEBUG - 2014-02-28 03:45:27 --> Output Class Initialized
DEBUG - 2014-02-28 03:45:27 --> Security Class Initialized
DEBUG - 2014-02-28 03:45:27 --> Input Class Initialized
DEBUG - 2014-02-28 03:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 03:45:27 --> Language Class Initialized
DEBUG - 2014-02-28 03:45:27 --> Loader Class Initialized
DEBUG - 2014-02-28 03:45:27 --> Database Driver Class Initialized
DEBUG - 2014-02-28 03:45:27 --> Session Class Initialized
DEBUG - 2014-02-28 03:45:27 --> Helper loaded: string_helper
DEBUG - 2014-02-28 03:45:27 --> Session routines successfully run
DEBUG - 2014-02-28 03:45:27 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 03:45:27 --> User Agent Class Initialized
DEBUG - 2014-02-28 03:45:27 --> Controller Class Initialized
DEBUG - 2014-02-28 03:45:27 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 03:45:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-02-28 03:46:02 --> Config Class Initialized
DEBUG - 2014-02-28 03:46:02 --> Hooks Class Initialized
DEBUG - 2014-02-28 03:46:02 --> Utf8 Class Initialized
DEBUG - 2014-02-28 03:46:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 03:46:02 --> URI Class Initialized
DEBUG - 2014-02-28 03:46:02 --> Router Class Initialized
DEBUG - 2014-02-28 03:46:02 --> Output Class Initialized
DEBUG - 2014-02-28 03:46:02 --> Security Class Initialized
DEBUG - 2014-02-28 03:46:02 --> Input Class Initialized
DEBUG - 2014-02-28 03:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 03:46:02 --> Language Class Initialized
DEBUG - 2014-02-28 03:46:02 --> Loader Class Initialized
DEBUG - 2014-02-28 03:46:02 --> Database Driver Class Initialized
ERROR - 2014-02-28 03:46:02 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\apps\career\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-02-28 03:46:03 --> Session Class Initialized
DEBUG - 2014-02-28 03:46:03 --> Helper loaded: string_helper
DEBUG - 2014-02-28 03:46:03 --> Session routines successfully run
DEBUG - 2014-02-28 03:46:03 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 03:46:03 --> User Agent Class Initialized
DEBUG - 2014-02-28 03:46:03 --> Controller Class Initialized
DEBUG - 2014-02-28 03:46:03 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 03:46:29 --> Config Class Initialized
DEBUG - 2014-02-28 03:46:29 --> Hooks Class Initialized
DEBUG - 2014-02-28 03:46:29 --> Utf8 Class Initialized
DEBUG - 2014-02-28 03:46:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 03:46:29 --> URI Class Initialized
DEBUG - 2014-02-28 03:46:29 --> Router Class Initialized
DEBUG - 2014-02-28 03:46:29 --> Output Class Initialized
DEBUG - 2014-02-28 03:46:29 --> Security Class Initialized
DEBUG - 2014-02-28 03:46:29 --> Input Class Initialized
DEBUG - 2014-02-28 03:46:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 03:46:29 --> Language Class Initialized
DEBUG - 2014-02-28 03:46:29 --> Loader Class Initialized
DEBUG - 2014-02-28 03:46:29 --> Database Driver Class Initialized
DEBUG - 2014-02-28 03:46:29 --> Session Class Initialized
DEBUG - 2014-02-28 03:46:29 --> Helper loaded: string_helper
DEBUG - 2014-02-28 03:46:29 --> Session routines successfully run
DEBUG - 2014-02-28 03:46:29 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 03:46:29 --> User Agent Class Initialized
DEBUG - 2014-02-28 03:46:29 --> Controller Class Initialized
DEBUG - 2014-02-28 03:46:29 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 03:46:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-02-28 03:48:11 --> Config Class Initialized
DEBUG - 2014-02-28 03:48:11 --> Hooks Class Initialized
DEBUG - 2014-02-28 03:48:11 --> Utf8 Class Initialized
DEBUG - 2014-02-28 03:48:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 03:48:11 --> URI Class Initialized
DEBUG - 2014-02-28 03:48:11 --> Router Class Initialized
DEBUG - 2014-02-28 03:48:11 --> Output Class Initialized
DEBUG - 2014-02-28 03:48:11 --> Security Class Initialized
DEBUG - 2014-02-28 03:48:11 --> Input Class Initialized
DEBUG - 2014-02-28 03:48:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 03:48:11 --> Language Class Initialized
DEBUG - 2014-02-28 03:48:11 --> Loader Class Initialized
DEBUG - 2014-02-28 03:48:11 --> Database Driver Class Initialized
ERROR - 2014-02-28 03:48:11 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\apps\career\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-02-28 03:48:12 --> Session Class Initialized
DEBUG - 2014-02-28 03:48:12 --> Helper loaded: string_helper
DEBUG - 2014-02-28 03:48:12 --> Session routines successfully run
DEBUG - 2014-02-28 03:48:12 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 03:48:12 --> User Agent Class Initialized
DEBUG - 2014-02-28 03:48:12 --> Controller Class Initialized
DEBUG - 2014-02-28 03:48:12 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 03:48:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-02-28 03:48:28 --> Config Class Initialized
DEBUG - 2014-02-28 03:48:28 --> Hooks Class Initialized
DEBUG - 2014-02-28 03:48:28 --> Utf8 Class Initialized
DEBUG - 2014-02-28 03:48:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 03:48:28 --> URI Class Initialized
DEBUG - 2014-02-28 03:48:28 --> Router Class Initialized
DEBUG - 2014-02-28 03:48:28 --> Output Class Initialized
DEBUG - 2014-02-28 03:48:28 --> Security Class Initialized
DEBUG - 2014-02-28 03:48:28 --> Input Class Initialized
DEBUG - 2014-02-28 03:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 03:48:28 --> Language Class Initialized
DEBUG - 2014-02-28 03:48:28 --> Loader Class Initialized
DEBUG - 2014-02-28 03:48:28 --> Database Driver Class Initialized
DEBUG - 2014-02-28 03:48:28 --> Session Class Initialized
DEBUG - 2014-02-28 03:48:28 --> Helper loaded: string_helper
DEBUG - 2014-02-28 03:48:28 --> Session routines successfully run
DEBUG - 2014-02-28 03:48:28 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 03:48:28 --> User Agent Class Initialized
DEBUG - 2014-02-28 03:48:28 --> Controller Class Initialized
DEBUG - 2014-02-28 03:48:28 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 03:48:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-02-28 03:49:19 --> Config Class Initialized
DEBUG - 2014-02-28 03:49:19 --> Hooks Class Initialized
DEBUG - 2014-02-28 03:49:19 --> Utf8 Class Initialized
DEBUG - 2014-02-28 03:49:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 03:49:19 --> URI Class Initialized
DEBUG - 2014-02-28 03:49:19 --> Router Class Initialized
DEBUG - 2014-02-28 03:49:19 --> Output Class Initialized
DEBUG - 2014-02-28 03:49:19 --> Security Class Initialized
DEBUG - 2014-02-28 03:49:19 --> Input Class Initialized
DEBUG - 2014-02-28 03:49:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 03:49:19 --> Language Class Initialized
DEBUG - 2014-02-28 03:49:19 --> Loader Class Initialized
DEBUG - 2014-02-28 03:49:19 --> Database Driver Class Initialized
DEBUG - 2014-02-28 03:49:19 --> Session Class Initialized
DEBUG - 2014-02-28 03:49:19 --> Helper loaded: string_helper
DEBUG - 2014-02-28 03:49:19 --> Session routines successfully run
DEBUG - 2014-02-28 03:49:19 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 03:49:19 --> User Agent Class Initialized
DEBUG - 2014-02-28 03:49:19 --> Controller Class Initialized
DEBUG - 2014-02-28 03:49:19 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 03:49:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-02-28 03:49:24 --> Config Class Initialized
DEBUG - 2014-02-28 03:49:24 --> Hooks Class Initialized
DEBUG - 2014-02-28 03:49:24 --> Utf8 Class Initialized
DEBUG - 2014-02-28 03:49:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 03:49:24 --> URI Class Initialized
DEBUG - 2014-02-28 03:49:24 --> Router Class Initialized
DEBUG - 2014-02-28 03:49:24 --> No URI present. Default controller set.
DEBUG - 2014-02-28 03:49:24 --> Output Class Initialized
DEBUG - 2014-02-28 03:49:24 --> Security Class Initialized
DEBUG - 2014-02-28 03:49:24 --> Input Class Initialized
DEBUG - 2014-02-28 03:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 03:49:25 --> Language Class Initialized
DEBUG - 2014-02-28 03:49:25 --> Loader Class Initialized
DEBUG - 2014-02-28 03:49:25 --> Database Driver Class Initialized
DEBUG - 2014-02-28 03:49:25 --> Session Class Initialized
DEBUG - 2014-02-28 03:49:25 --> Helper loaded: string_helper
DEBUG - 2014-02-28 03:49:25 --> Session routines successfully run
DEBUG - 2014-02-28 03:49:25 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 03:49:25 --> User Agent Class Initialized
DEBUG - 2014-02-28 03:49:25 --> Controller Class Initialized
DEBUG - 2014-02-28 03:49:25 --> Helper loaded: url_helper
DEBUG - 2014-02-28 03:49:25 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 03:49:25 --> Model Class Initialized
DEBUG - 2014-02-28 03:49:25 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 03:49:25 --> Final output sent to browser
DEBUG - 2014-02-28 03:49:25 --> Total execution time: 0.6057
DEBUG - 2014-02-28 03:49:27 --> Config Class Initialized
DEBUG - 2014-02-28 03:49:27 --> Hooks Class Initialized
DEBUG - 2014-02-28 03:49:27 --> Utf8 Class Initialized
DEBUG - 2014-02-28 03:49:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 03:49:27 --> URI Class Initialized
DEBUG - 2014-02-28 03:49:27 --> Router Class Initialized
DEBUG - 2014-02-28 03:49:27 --> No URI present. Default controller set.
DEBUG - 2014-02-28 03:49:27 --> Output Class Initialized
DEBUG - 2014-02-28 03:49:27 --> Security Class Initialized
DEBUG - 2014-02-28 03:49:27 --> Input Class Initialized
DEBUG - 2014-02-28 03:49:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 03:49:27 --> Language Class Initialized
DEBUG - 2014-02-28 03:49:27 --> Loader Class Initialized
DEBUG - 2014-02-28 03:49:27 --> Database Driver Class Initialized
DEBUG - 2014-02-28 03:49:27 --> Session Class Initialized
DEBUG - 2014-02-28 03:49:27 --> Helper loaded: string_helper
DEBUG - 2014-02-28 03:49:27 --> Session routines successfully run
DEBUG - 2014-02-28 03:49:27 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 03:49:27 --> User Agent Class Initialized
DEBUG - 2014-02-28 03:49:27 --> Controller Class Initialized
DEBUG - 2014-02-28 03:49:27 --> Helper loaded: url_helper
DEBUG - 2014-02-28 03:49:27 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 03:49:27 --> Model Class Initialized
DEBUG - 2014-02-28 03:49:28 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 03:49:28 --> Final output sent to browser
DEBUG - 2014-02-28 03:49:28 --> Total execution time: 0.6051
DEBUG - 2014-02-28 03:49:48 --> Config Class Initialized
DEBUG - 2014-02-28 03:49:48 --> Hooks Class Initialized
DEBUG - 2014-02-28 03:49:48 --> Utf8 Class Initialized
DEBUG - 2014-02-28 03:49:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 03:49:48 --> URI Class Initialized
DEBUG - 2014-02-28 03:49:48 --> Router Class Initialized
DEBUG - 2014-02-28 03:49:48 --> No URI present. Default controller set.
DEBUG - 2014-02-28 03:49:48 --> Output Class Initialized
DEBUG - 2014-02-28 03:49:48 --> Security Class Initialized
DEBUG - 2014-02-28 03:49:48 --> Input Class Initialized
DEBUG - 2014-02-28 03:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 03:49:48 --> Language Class Initialized
DEBUG - 2014-02-28 03:49:48 --> Loader Class Initialized
DEBUG - 2014-02-28 03:49:48 --> Database Driver Class Initialized
DEBUG - 2014-02-28 03:49:48 --> Session Class Initialized
DEBUG - 2014-02-28 03:49:48 --> Helper loaded: string_helper
DEBUG - 2014-02-28 03:49:48 --> Session routines successfully run
DEBUG - 2014-02-28 03:49:48 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 03:49:48 --> User Agent Class Initialized
DEBUG - 2014-02-28 03:49:48 --> Controller Class Initialized
DEBUG - 2014-02-28 03:49:48 --> Helper loaded: url_helper
DEBUG - 2014-02-28 03:49:48 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 03:49:48 --> Model Class Initialized
DEBUG - 2014-02-28 03:49:48 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 03:49:49 --> Final output sent to browser
DEBUG - 2014-02-28 03:49:49 --> Total execution time: 0.6259
DEBUG - 2014-02-28 03:51:44 --> Config Class Initialized
DEBUG - 2014-02-28 03:51:44 --> Hooks Class Initialized
DEBUG - 2014-02-28 03:51:44 --> Utf8 Class Initialized
DEBUG - 2014-02-28 03:51:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 03:51:44 --> URI Class Initialized
DEBUG - 2014-02-28 03:51:44 --> Router Class Initialized
DEBUG - 2014-02-28 03:51:44 --> Output Class Initialized
DEBUG - 2014-02-28 03:51:44 --> Security Class Initialized
DEBUG - 2014-02-28 03:51:44 --> Input Class Initialized
DEBUG - 2014-02-28 03:51:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 03:51:44 --> Language Class Initialized
DEBUG - 2014-02-28 03:51:44 --> Loader Class Initialized
DEBUG - 2014-02-28 03:51:44 --> Database Driver Class Initialized
DEBUG - 2014-02-28 03:51:44 --> Session Class Initialized
DEBUG - 2014-02-28 03:51:44 --> Helper loaded: string_helper
DEBUG - 2014-02-28 03:51:45 --> Session routines successfully run
DEBUG - 2014-02-28 03:51:45 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 03:51:45 --> User Agent Class Initialized
DEBUG - 2014-02-28 03:51:45 --> Controller Class Initialized
DEBUG - 2014-02-28 03:51:45 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 03:51:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-02-28 03:54:31 --> Config Class Initialized
DEBUG - 2014-02-28 03:54:31 --> Hooks Class Initialized
DEBUG - 2014-02-28 03:54:31 --> Utf8 Class Initialized
DEBUG - 2014-02-28 03:54:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 03:54:31 --> URI Class Initialized
DEBUG - 2014-02-28 03:54:31 --> Router Class Initialized
DEBUG - 2014-02-28 03:54:31 --> Output Class Initialized
DEBUG - 2014-02-28 03:54:31 --> Security Class Initialized
DEBUG - 2014-02-28 03:54:31 --> Input Class Initialized
DEBUG - 2014-02-28 03:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 03:54:31 --> Language Class Initialized
DEBUG - 2014-02-28 03:54:31 --> Loader Class Initialized
DEBUG - 2014-02-28 03:54:31 --> Database Driver Class Initialized
DEBUG - 2014-02-28 03:54:31 --> Session Class Initialized
DEBUG - 2014-02-28 03:54:31 --> Helper loaded: string_helper
DEBUG - 2014-02-28 03:54:31 --> Session routines successfully run
DEBUG - 2014-02-28 03:54:31 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 03:54:31 --> User Agent Class Initialized
DEBUG - 2014-02-28 03:54:31 --> Controller Class Initialized
DEBUG - 2014-02-28 03:54:31 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 03:54:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-02-28 03:55:05 --> Config Class Initialized
DEBUG - 2014-02-28 03:55:05 --> Hooks Class Initialized
DEBUG - 2014-02-28 03:55:05 --> Utf8 Class Initialized
DEBUG - 2014-02-28 03:55:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 03:55:05 --> URI Class Initialized
DEBUG - 2014-02-28 03:55:05 --> Router Class Initialized
DEBUG - 2014-02-28 03:55:05 --> Output Class Initialized
DEBUG - 2014-02-28 03:55:06 --> Security Class Initialized
DEBUG - 2014-02-28 03:55:06 --> Input Class Initialized
DEBUG - 2014-02-28 03:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 03:55:06 --> Language Class Initialized
DEBUG - 2014-02-28 03:55:06 --> Loader Class Initialized
DEBUG - 2014-02-28 03:55:06 --> Database Driver Class Initialized
DEBUG - 2014-02-28 03:55:06 --> Session Class Initialized
DEBUG - 2014-02-28 03:55:06 --> Helper loaded: string_helper
DEBUG - 2014-02-28 03:55:06 --> Session routines successfully run
DEBUG - 2014-02-28 03:55:06 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 03:55:06 --> User Agent Class Initialized
DEBUG - 2014-02-28 03:55:06 --> Controller Class Initialized
DEBUG - 2014-02-28 03:55:06 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 03:55:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-02-28 03:55:09 --> Config Class Initialized
DEBUG - 2014-02-28 03:55:09 --> Hooks Class Initialized
DEBUG - 2014-02-28 03:55:09 --> Utf8 Class Initialized
DEBUG - 2014-02-28 03:55:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 03:55:09 --> URI Class Initialized
DEBUG - 2014-02-28 03:55:09 --> Router Class Initialized
DEBUG - 2014-02-28 03:55:09 --> No URI present. Default controller set.
DEBUG - 2014-02-28 03:55:09 --> Output Class Initialized
DEBUG - 2014-02-28 03:55:09 --> Security Class Initialized
DEBUG - 2014-02-28 03:55:09 --> Input Class Initialized
DEBUG - 2014-02-28 03:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 03:55:09 --> Language Class Initialized
DEBUG - 2014-02-28 03:55:09 --> Loader Class Initialized
DEBUG - 2014-02-28 03:55:09 --> Database Driver Class Initialized
DEBUG - 2014-02-28 03:55:09 --> Session Class Initialized
DEBUG - 2014-02-28 03:55:09 --> Helper loaded: string_helper
DEBUG - 2014-02-28 03:55:09 --> Session routines successfully run
DEBUG - 2014-02-28 03:55:09 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 03:55:09 --> User Agent Class Initialized
DEBUG - 2014-02-28 03:55:09 --> Controller Class Initialized
DEBUG - 2014-02-28 03:55:09 --> Helper loaded: url_helper
DEBUG - 2014-02-28 03:55:09 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 03:55:09 --> Model Class Initialized
DEBUG - 2014-02-28 03:55:09 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 03:55:09 --> Final output sent to browser
DEBUG - 2014-02-28 03:55:10 --> Total execution time: 0.6426
DEBUG - 2014-02-28 07:45:33 --> Config Class Initialized
DEBUG - 2014-02-28 07:45:33 --> Hooks Class Initialized
DEBUG - 2014-02-28 07:45:33 --> Utf8 Class Initialized
DEBUG - 2014-02-28 07:45:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 07:45:33 --> URI Class Initialized
DEBUG - 2014-02-28 07:45:33 --> Router Class Initialized
DEBUG - 2014-02-28 07:45:33 --> No URI present. Default controller set.
DEBUG - 2014-02-28 07:45:33 --> Output Class Initialized
DEBUG - 2014-02-28 07:45:33 --> Security Class Initialized
DEBUG - 2014-02-28 07:45:33 --> Input Class Initialized
DEBUG - 2014-02-28 07:45:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 07:45:33 --> Language Class Initialized
DEBUG - 2014-02-28 07:45:33 --> Loader Class Initialized
DEBUG - 2014-02-28 07:45:33 --> Database Driver Class Initialized
ERROR - 2014-02-28 07:45:33 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\apps\career\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-02-28 07:45:34 --> Session Class Initialized
DEBUG - 2014-02-28 07:45:34 --> Helper loaded: string_helper
DEBUG - 2014-02-28 07:45:34 --> Session routines successfully run
DEBUG - 2014-02-28 07:45:34 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 07:45:34 --> User Agent Class Initialized
DEBUG - 2014-02-28 07:45:34 --> Controller Class Initialized
DEBUG - 2014-02-28 07:45:34 --> Helper loaded: url_helper
DEBUG - 2014-02-28 07:45:34 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 07:45:34 --> Model Class Initialized
DEBUG - 2014-02-28 07:45:34 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 07:45:35 --> Final output sent to browser
DEBUG - 2014-02-28 07:45:35 --> Total execution time: 1.5113
DEBUG - 2014-02-28 07:52:21 --> Config Class Initialized
DEBUG - 2014-02-28 07:52:21 --> Hooks Class Initialized
DEBUG - 2014-02-28 07:52:21 --> Utf8 Class Initialized
DEBUG - 2014-02-28 07:52:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 07:52:21 --> URI Class Initialized
DEBUG - 2014-02-28 07:52:21 --> Router Class Initialized
DEBUG - 2014-02-28 07:52:21 --> No URI present. Default controller set.
DEBUG - 2014-02-28 07:52:21 --> Output Class Initialized
DEBUG - 2014-02-28 07:52:21 --> Security Class Initialized
DEBUG - 2014-02-28 07:52:21 --> Input Class Initialized
DEBUG - 2014-02-28 07:52:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 07:52:21 --> Language Class Initialized
DEBUG - 2014-02-28 07:52:21 --> Loader Class Initialized
DEBUG - 2014-02-28 07:52:21 --> Database Driver Class Initialized
DEBUG - 2014-02-28 07:52:21 --> Session Class Initialized
DEBUG - 2014-02-28 07:52:21 --> Helper loaded: string_helper
DEBUG - 2014-02-28 07:52:21 --> Session routines successfully run
DEBUG - 2014-02-28 07:52:21 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 07:52:21 --> User Agent Class Initialized
DEBUG - 2014-02-28 07:52:22 --> Controller Class Initialized
DEBUG - 2014-02-28 07:52:22 --> Helper loaded: url_helper
DEBUG - 2014-02-28 07:52:22 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 07:52:22 --> Model Class Initialized
DEBUG - 2014-02-28 07:52:22 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 07:52:22 --> Final output sent to browser
DEBUG - 2014-02-28 07:52:22 --> Total execution time: 0.6008
DEBUG - 2014-02-28 07:59:13 --> Config Class Initialized
DEBUG - 2014-02-28 07:59:13 --> Hooks Class Initialized
DEBUG - 2014-02-28 07:59:13 --> Utf8 Class Initialized
DEBUG - 2014-02-28 07:59:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 07:59:14 --> URI Class Initialized
DEBUG - 2014-02-28 07:59:14 --> Router Class Initialized
DEBUG - 2014-02-28 07:59:14 --> No URI present. Default controller set.
DEBUG - 2014-02-28 07:59:14 --> Output Class Initialized
DEBUG - 2014-02-28 07:59:14 --> Security Class Initialized
DEBUG - 2014-02-28 07:59:14 --> Input Class Initialized
DEBUG - 2014-02-28 07:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 07:59:14 --> Language Class Initialized
DEBUG - 2014-02-28 07:59:14 --> Loader Class Initialized
DEBUG - 2014-02-28 07:59:14 --> Database Driver Class Initialized
DEBUG - 2014-02-28 07:59:14 --> Session Class Initialized
DEBUG - 2014-02-28 07:59:14 --> Helper loaded: string_helper
DEBUG - 2014-02-28 07:59:14 --> Session routines successfully run
DEBUG - 2014-02-28 07:59:14 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 07:59:14 --> User Agent Class Initialized
DEBUG - 2014-02-28 07:59:14 --> Controller Class Initialized
DEBUG - 2014-02-28 07:59:14 --> Helper loaded: url_helper
DEBUG - 2014-02-28 07:59:14 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 07:59:14 --> Model Class Initialized
DEBUG - 2014-02-28 07:59:14 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 07:59:14 --> Final output sent to browser
DEBUG - 2014-02-28 07:59:14 --> Total execution time: 0.7697
DEBUG - 2014-02-28 08:00:28 --> Config Class Initialized
DEBUG - 2014-02-28 08:00:28 --> Hooks Class Initialized
DEBUG - 2014-02-28 08:00:28 --> Utf8 Class Initialized
DEBUG - 2014-02-28 08:00:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 08:00:28 --> URI Class Initialized
DEBUG - 2014-02-28 08:00:28 --> Router Class Initialized
DEBUG - 2014-02-28 08:00:28 --> No URI present. Default controller set.
DEBUG - 2014-02-28 08:00:28 --> Output Class Initialized
DEBUG - 2014-02-28 08:00:28 --> Security Class Initialized
DEBUG - 2014-02-28 08:00:28 --> Input Class Initialized
DEBUG - 2014-02-28 08:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 08:00:28 --> Language Class Initialized
DEBUG - 2014-02-28 08:00:28 --> Loader Class Initialized
DEBUG - 2014-02-28 08:00:28 --> Database Driver Class Initialized
DEBUG - 2014-02-28 08:00:28 --> Session Class Initialized
DEBUG - 2014-02-28 08:00:28 --> Helper loaded: string_helper
DEBUG - 2014-02-28 08:00:28 --> Session routines successfully run
DEBUG - 2014-02-28 08:00:28 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 08:00:28 --> User Agent Class Initialized
DEBUG - 2014-02-28 08:00:28 --> Controller Class Initialized
DEBUG - 2014-02-28 08:00:28 --> Helper loaded: url_helper
DEBUG - 2014-02-28 08:00:28 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 08:00:28 --> Model Class Initialized
DEBUG - 2014-02-28 08:00:28 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 08:00:28 --> Final output sent to browser
DEBUG - 2014-02-28 08:00:28 --> Total execution time: 0.1469
DEBUG - 2014-02-28 08:08:43 --> Config Class Initialized
DEBUG - 2014-02-28 08:08:43 --> Hooks Class Initialized
DEBUG - 2014-02-28 08:08:43 --> Utf8 Class Initialized
DEBUG - 2014-02-28 08:08:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 08:08:43 --> URI Class Initialized
DEBUG - 2014-02-28 08:08:43 --> Router Class Initialized
DEBUG - 2014-02-28 08:08:43 --> No URI present. Default controller set.
DEBUG - 2014-02-28 08:08:43 --> Output Class Initialized
DEBUG - 2014-02-28 08:08:43 --> Security Class Initialized
DEBUG - 2014-02-28 08:08:43 --> Input Class Initialized
DEBUG - 2014-02-28 08:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 08:08:43 --> Language Class Initialized
DEBUG - 2014-02-28 08:08:43 --> Loader Class Initialized
DEBUG - 2014-02-28 08:08:43 --> Database Driver Class Initialized
DEBUG - 2014-02-28 08:08:44 --> Session Class Initialized
DEBUG - 2014-02-28 08:08:44 --> Helper loaded: string_helper
DEBUG - 2014-02-28 08:08:44 --> Session routines successfully run
DEBUG - 2014-02-28 08:08:44 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 08:08:44 --> User Agent Class Initialized
DEBUG - 2014-02-28 08:08:44 --> Controller Class Initialized
DEBUG - 2014-02-28 08:08:44 --> Helper loaded: url_helper
DEBUG - 2014-02-28 08:08:44 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 08:08:44 --> Model Class Initialized
DEBUG - 2014-02-28 08:08:44 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 08:08:44 --> Final output sent to browser
DEBUG - 2014-02-28 08:08:44 --> Total execution time: 1.5234
DEBUG - 2014-02-28 08:13:44 --> Config Class Initialized
DEBUG - 2014-02-28 08:13:44 --> Hooks Class Initialized
DEBUG - 2014-02-28 08:13:44 --> Utf8 Class Initialized
DEBUG - 2014-02-28 08:13:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 08:13:44 --> URI Class Initialized
DEBUG - 2014-02-28 08:13:44 --> Router Class Initialized
DEBUG - 2014-02-28 08:13:44 --> No URI present. Default controller set.
DEBUG - 2014-02-28 08:13:44 --> Output Class Initialized
DEBUG - 2014-02-28 08:13:44 --> Security Class Initialized
DEBUG - 2014-02-28 08:13:44 --> Input Class Initialized
DEBUG - 2014-02-28 08:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 08:13:44 --> Language Class Initialized
DEBUG - 2014-02-28 08:13:44 --> Loader Class Initialized
DEBUG - 2014-02-28 08:13:44 --> Database Driver Class Initialized
DEBUG - 2014-02-28 08:13:45 --> Session Class Initialized
DEBUG - 2014-02-28 08:13:45 --> Helper loaded: string_helper
DEBUG - 2014-02-28 08:13:45 --> Session routines successfully run
DEBUG - 2014-02-28 08:13:45 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 08:13:45 --> User Agent Class Initialized
DEBUG - 2014-02-28 08:13:45 --> Controller Class Initialized
DEBUG - 2014-02-28 08:13:45 --> Helper loaded: url_helper
DEBUG - 2014-02-28 08:13:45 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 08:13:45 --> Model Class Initialized
DEBUG - 2014-02-28 08:13:45 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 08:13:45 --> Final output sent to browser
DEBUG - 2014-02-28 08:13:45 --> Total execution time: 1.4330
DEBUG - 2014-02-28 08:13:59 --> Config Class Initialized
DEBUG - 2014-02-28 08:13:59 --> Hooks Class Initialized
DEBUG - 2014-02-28 08:13:59 --> Utf8 Class Initialized
DEBUG - 2014-02-28 08:13:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 08:13:59 --> URI Class Initialized
DEBUG - 2014-02-28 08:13:59 --> Router Class Initialized
DEBUG - 2014-02-28 08:13:59 --> No URI present. Default controller set.
DEBUG - 2014-02-28 08:13:59 --> Output Class Initialized
DEBUG - 2014-02-28 08:13:59 --> Security Class Initialized
DEBUG - 2014-02-28 08:13:59 --> Input Class Initialized
DEBUG - 2014-02-28 08:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 08:13:59 --> Language Class Initialized
DEBUG - 2014-02-28 08:13:59 --> Loader Class Initialized
DEBUG - 2014-02-28 08:13:59 --> Database Driver Class Initialized
DEBUG - 2014-02-28 08:13:59 --> Session Class Initialized
DEBUG - 2014-02-28 08:13:59 --> Helper loaded: string_helper
DEBUG - 2014-02-28 08:13:59 --> Session routines successfully run
DEBUG - 2014-02-28 08:13:59 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 08:13:59 --> User Agent Class Initialized
DEBUG - 2014-02-28 08:13:59 --> Controller Class Initialized
DEBUG - 2014-02-28 08:13:59 --> Helper loaded: url_helper
DEBUG - 2014-02-28 08:13:59 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 08:13:59 --> Model Class Initialized
DEBUG - 2014-02-28 08:13:59 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 08:13:59 --> Final output sent to browser
DEBUG - 2014-02-28 08:13:59 --> Total execution time: 0.1982
DEBUG - 2014-02-28 08:14:26 --> Config Class Initialized
DEBUG - 2014-02-28 08:14:26 --> Hooks Class Initialized
DEBUG - 2014-02-28 08:14:26 --> Utf8 Class Initialized
DEBUG - 2014-02-28 08:14:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 08:14:26 --> URI Class Initialized
DEBUG - 2014-02-28 08:14:26 --> Router Class Initialized
DEBUG - 2014-02-28 08:14:26 --> No URI present. Default controller set.
DEBUG - 2014-02-28 08:14:26 --> Output Class Initialized
DEBUG - 2014-02-28 08:14:26 --> Security Class Initialized
DEBUG - 2014-02-28 08:14:27 --> Input Class Initialized
DEBUG - 2014-02-28 08:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 08:14:27 --> Language Class Initialized
DEBUG - 2014-02-28 08:14:27 --> Loader Class Initialized
DEBUG - 2014-02-28 08:14:27 --> Database Driver Class Initialized
DEBUG - 2014-02-28 08:14:27 --> Session Class Initialized
DEBUG - 2014-02-28 08:14:27 --> Helper loaded: string_helper
DEBUG - 2014-02-28 08:14:27 --> Session routines successfully run
DEBUG - 2014-02-28 08:14:27 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 08:14:27 --> User Agent Class Initialized
DEBUG - 2014-02-28 08:14:27 --> Controller Class Initialized
DEBUG - 2014-02-28 08:14:27 --> Helper loaded: url_helper
DEBUG - 2014-02-28 08:14:27 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 08:14:27 --> Model Class Initialized
DEBUG - 2014-02-28 08:14:27 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 08:14:27 --> Final output sent to browser
DEBUG - 2014-02-28 08:14:27 --> Total execution time: 0.5583
DEBUG - 2014-02-28 08:14:38 --> Config Class Initialized
DEBUG - 2014-02-28 08:14:38 --> Hooks Class Initialized
DEBUG - 2014-02-28 08:14:38 --> Utf8 Class Initialized
DEBUG - 2014-02-28 08:14:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 08:14:38 --> URI Class Initialized
DEBUG - 2014-02-28 08:14:38 --> Router Class Initialized
DEBUG - 2014-02-28 08:14:38 --> No URI present. Default controller set.
DEBUG - 2014-02-28 08:14:38 --> Output Class Initialized
DEBUG - 2014-02-28 08:14:38 --> Security Class Initialized
DEBUG - 2014-02-28 08:14:38 --> Input Class Initialized
DEBUG - 2014-02-28 08:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 08:14:38 --> Language Class Initialized
DEBUG - 2014-02-28 08:14:38 --> Loader Class Initialized
DEBUG - 2014-02-28 08:14:38 --> Database Driver Class Initialized
DEBUG - 2014-02-28 08:14:39 --> Session Class Initialized
DEBUG - 2014-02-28 08:14:39 --> Helper loaded: string_helper
DEBUG - 2014-02-28 08:14:39 --> Session routines successfully run
DEBUG - 2014-02-28 08:14:39 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 08:14:39 --> User Agent Class Initialized
DEBUG - 2014-02-28 08:14:39 --> Controller Class Initialized
DEBUG - 2014-02-28 08:14:39 --> Helper loaded: url_helper
DEBUG - 2014-02-28 08:14:39 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 08:14:39 --> Model Class Initialized
DEBUG - 2014-02-28 08:14:39 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 08:14:39 --> Final output sent to browser
DEBUG - 2014-02-28 08:14:39 --> Total execution time: 1.3180
DEBUG - 2014-02-28 08:14:44 --> Config Class Initialized
DEBUG - 2014-02-28 08:14:44 --> Hooks Class Initialized
DEBUG - 2014-02-28 08:14:44 --> Utf8 Class Initialized
DEBUG - 2014-02-28 08:14:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 08:14:44 --> URI Class Initialized
DEBUG - 2014-02-28 08:14:44 --> Router Class Initialized
DEBUG - 2014-02-28 08:14:44 --> No URI present. Default controller set.
DEBUG - 2014-02-28 08:14:44 --> Output Class Initialized
DEBUG - 2014-02-28 08:14:44 --> Security Class Initialized
DEBUG - 2014-02-28 08:14:44 --> Input Class Initialized
DEBUG - 2014-02-28 08:14:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 08:14:44 --> Language Class Initialized
DEBUG - 2014-02-28 08:14:44 --> Loader Class Initialized
DEBUG - 2014-02-28 08:14:44 --> Database Driver Class Initialized
DEBUG - 2014-02-28 08:14:44 --> Session Class Initialized
DEBUG - 2014-02-28 08:14:44 --> Helper loaded: string_helper
DEBUG - 2014-02-28 08:14:44 --> Session routines successfully run
DEBUG - 2014-02-28 08:14:44 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 08:14:44 --> User Agent Class Initialized
DEBUG - 2014-02-28 08:14:44 --> Controller Class Initialized
DEBUG - 2014-02-28 08:14:44 --> Helper loaded: url_helper
DEBUG - 2014-02-28 08:14:44 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 08:14:44 --> Model Class Initialized
DEBUG - 2014-02-28 08:14:44 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 08:14:44 --> Final output sent to browser
DEBUG - 2014-02-28 08:14:44 --> Total execution time: 0.6774
DEBUG - 2014-02-28 08:30:05 --> Config Class Initialized
DEBUG - 2014-02-28 08:30:05 --> Hooks Class Initialized
DEBUG - 2014-02-28 08:30:05 --> Utf8 Class Initialized
DEBUG - 2014-02-28 08:30:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 08:30:05 --> URI Class Initialized
DEBUG - 2014-02-28 08:30:05 --> Router Class Initialized
DEBUG - 2014-02-28 08:30:05 --> No URI present. Default controller set.
DEBUG - 2014-02-28 08:30:05 --> Output Class Initialized
DEBUG - 2014-02-28 08:30:05 --> Security Class Initialized
DEBUG - 2014-02-28 08:30:05 --> Input Class Initialized
DEBUG - 2014-02-28 08:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 08:30:05 --> Language Class Initialized
DEBUG - 2014-02-28 08:30:05 --> Loader Class Initialized
DEBUG - 2014-02-28 08:30:05 --> Database Driver Class Initialized
DEBUG - 2014-02-28 08:30:05 --> Session Class Initialized
DEBUG - 2014-02-28 08:30:05 --> Helper loaded: string_helper
DEBUG - 2014-02-28 08:30:05 --> Session routines successfully run
DEBUG - 2014-02-28 08:30:05 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 08:30:05 --> User Agent Class Initialized
DEBUG - 2014-02-28 08:30:05 --> Controller Class Initialized
DEBUG - 2014-02-28 08:30:05 --> Helper loaded: url_helper
DEBUG - 2014-02-28 08:30:05 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 08:30:05 --> Model Class Initialized
DEBUG - 2014-02-28 08:30:06 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 08:30:06 --> Final output sent to browser
DEBUG - 2014-02-28 08:30:06 --> Total execution time: 0.6020
DEBUG - 2014-02-28 08:32:42 --> Config Class Initialized
DEBUG - 2014-02-28 08:32:42 --> Hooks Class Initialized
DEBUG - 2014-02-28 08:32:42 --> Utf8 Class Initialized
DEBUG - 2014-02-28 08:32:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 08:32:42 --> URI Class Initialized
DEBUG - 2014-02-28 08:32:42 --> Router Class Initialized
DEBUG - 2014-02-28 08:32:42 --> No URI present. Default controller set.
DEBUG - 2014-02-28 08:32:42 --> Output Class Initialized
DEBUG - 2014-02-28 08:32:42 --> Security Class Initialized
DEBUG - 2014-02-28 08:32:42 --> Input Class Initialized
DEBUG - 2014-02-28 08:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 08:32:42 --> Language Class Initialized
DEBUG - 2014-02-28 08:32:56 --> Config Class Initialized
DEBUG - 2014-02-28 08:32:56 --> Hooks Class Initialized
DEBUG - 2014-02-28 08:32:56 --> Utf8 Class Initialized
DEBUG - 2014-02-28 08:32:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 08:32:56 --> URI Class Initialized
DEBUG - 2014-02-28 08:32:56 --> Router Class Initialized
DEBUG - 2014-02-28 08:32:56 --> No URI present. Default controller set.
DEBUG - 2014-02-28 08:32:56 --> Output Class Initialized
DEBUG - 2014-02-28 08:32:56 --> Security Class Initialized
DEBUG - 2014-02-28 08:32:56 --> Input Class Initialized
DEBUG - 2014-02-28 08:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 08:32:56 --> Language Class Initialized
DEBUG - 2014-02-28 08:32:56 --> Loader Class Initialized
DEBUG - 2014-02-28 08:32:56 --> Database Driver Class Initialized
DEBUG - 2014-02-28 08:32:56 --> Session Class Initialized
DEBUG - 2014-02-28 08:32:56 --> Helper loaded: string_helper
DEBUG - 2014-02-28 08:32:56 --> Session routines successfully run
DEBUG - 2014-02-28 08:32:56 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 08:32:56 --> User Agent Class Initialized
DEBUG - 2014-02-28 08:32:56 --> Controller Class Initialized
DEBUG - 2014-02-28 08:32:56 --> Helper loaded: url_helper
DEBUG - 2014-02-28 08:32:56 --> Language file loaded: language/zh_TW/login_lang.php
INFO  - 2014-02-28 08:32:56 --> this->setMessage()
DEBUG - 2014-02-28 08:32:56 --> Model Class Initialized
DEBUG - 2014-02-28 08:32:56 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 08:32:56 --> Final output sent to browser
DEBUG - 2014-02-28 08:32:56 --> Total execution time: 0.6221
DEBUG - 2014-02-28 08:33:27 --> Config Class Initialized
DEBUG - 2014-02-28 08:33:27 --> Hooks Class Initialized
DEBUG - 2014-02-28 08:33:27 --> Utf8 Class Initialized
DEBUG - 2014-02-28 08:33:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 08:33:27 --> URI Class Initialized
DEBUG - 2014-02-28 08:33:27 --> Router Class Initialized
DEBUG - 2014-02-28 08:33:27 --> No URI present. Default controller set.
DEBUG - 2014-02-28 08:33:27 --> Output Class Initialized
DEBUG - 2014-02-28 08:33:27 --> Security Class Initialized
DEBUG - 2014-02-28 08:33:27 --> Input Class Initialized
DEBUG - 2014-02-28 08:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 08:33:27 --> Language Class Initialized
DEBUG - 2014-02-28 08:33:27 --> Loader Class Initialized
DEBUG - 2014-02-28 08:33:27 --> Database Driver Class Initialized
DEBUG - 2014-02-28 08:33:27 --> Session Class Initialized
DEBUG - 2014-02-28 08:33:27 --> Helper loaded: string_helper
DEBUG - 2014-02-28 08:33:28 --> Session routines successfully run
DEBUG - 2014-02-28 08:33:28 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 08:33:28 --> User Agent Class Initialized
DEBUG - 2014-02-28 08:33:28 --> Controller Class Initialized
DEBUG - 2014-02-28 08:33:28 --> Helper loaded: url_helper
DEBUG - 2014-02-28 08:33:28 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 08:33:28 --> this->setMessage()
DEBUG - 2014-02-28 08:33:28 --> Model Class Initialized
DEBUG - 2014-02-28 08:33:28 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 08:33:28 --> Final output sent to browser
DEBUG - 2014-02-28 08:33:28 --> Total execution time: 0.6318
DEBUG - 2014-02-28 08:33:38 --> Config Class Initialized
DEBUG - 2014-02-28 08:33:38 --> Hooks Class Initialized
DEBUG - 2014-02-28 08:33:38 --> Utf8 Class Initialized
DEBUG - 2014-02-28 08:33:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 08:33:38 --> URI Class Initialized
DEBUG - 2014-02-28 08:33:38 --> Router Class Initialized
DEBUG - 2014-02-28 08:33:38 --> No URI present. Default controller set.
DEBUG - 2014-02-28 08:33:38 --> Output Class Initialized
DEBUG - 2014-02-28 08:33:38 --> Security Class Initialized
DEBUG - 2014-02-28 08:33:38 --> Input Class Initialized
DEBUG - 2014-02-28 08:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 08:33:38 --> Language Class Initialized
DEBUG - 2014-02-28 08:33:38 --> Loader Class Initialized
DEBUG - 2014-02-28 08:33:38 --> Database Driver Class Initialized
DEBUG - 2014-02-28 08:33:38 --> Session Class Initialized
DEBUG - 2014-02-28 08:33:38 --> Helper loaded: string_helper
DEBUG - 2014-02-28 08:33:38 --> Session routines successfully run
DEBUG - 2014-02-28 08:33:38 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 08:33:38 --> User Agent Class Initialized
DEBUG - 2014-02-28 08:33:38 --> Controller Class Initialized
DEBUG - 2014-02-28 08:33:38 --> Helper loaded: url_helper
DEBUG - 2014-02-28 08:33:38 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 08:33:38 --> this->setMessage()
DEBUG - 2014-02-28 08:33:38 --> Model Class Initialized
DEBUG - 2014-02-28 08:33:38 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 08:33:38 --> Final output sent to browser
DEBUG - 2014-02-28 08:33:38 --> Total execution time: 0.3648
DEBUG - 2014-02-28 08:47:22 --> Config Class Initialized
DEBUG - 2014-02-28 08:47:22 --> Hooks Class Initialized
DEBUG - 2014-02-28 08:47:22 --> Utf8 Class Initialized
DEBUG - 2014-02-28 08:47:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 08:47:22 --> URI Class Initialized
DEBUG - 2014-02-28 08:47:22 --> Router Class Initialized
DEBUG - 2014-02-28 08:47:22 --> No URI present. Default controller set.
DEBUG - 2014-02-28 08:47:22 --> Output Class Initialized
DEBUG - 2014-02-28 08:47:22 --> Security Class Initialized
DEBUG - 2014-02-28 08:47:22 --> Input Class Initialized
DEBUG - 2014-02-28 08:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 08:47:22 --> Language Class Initialized
DEBUG - 2014-02-28 08:47:22 --> Loader Class Initialized
DEBUG - 2014-02-28 08:47:22 --> Database Driver Class Initialized
DEBUG - 2014-02-28 08:47:22 --> Session Class Initialized
DEBUG - 2014-02-28 08:47:22 --> Helper loaded: string_helper
DEBUG - 2014-02-28 08:47:22 --> Session routines successfully run
DEBUG - 2014-02-28 08:47:22 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 08:47:22 --> User Agent Class Initialized
DEBUG - 2014-02-28 08:47:22 --> Controller Class Initialized
DEBUG - 2014-02-28 08:47:22 --> Helper loaded: url_helper
DEBUG - 2014-02-28 08:47:22 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 08:47:22 --> this->setMessage()
DEBUG - 2014-02-28 08:47:22 --> Model Class Initialized
DEBUG - 2014-02-28 08:47:22 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 08:47:22 --> Final output sent to browser
DEBUG - 2014-02-28 08:47:22 --> Total execution time: 0.6338
DEBUG - 2014-02-28 08:48:45 --> Config Class Initialized
DEBUG - 2014-02-28 08:48:45 --> Hooks Class Initialized
DEBUG - 2014-02-28 08:48:45 --> Utf8 Class Initialized
DEBUG - 2014-02-28 08:48:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 08:48:45 --> URI Class Initialized
DEBUG - 2014-02-28 08:48:45 --> Router Class Initialized
DEBUG - 2014-02-28 08:48:45 --> Output Class Initialized
DEBUG - 2014-02-28 08:48:45 --> Security Class Initialized
DEBUG - 2014-02-28 08:48:45 --> Input Class Initialized
DEBUG - 2014-02-28 08:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 08:48:45 --> Language Class Initialized
DEBUG - 2014-02-28 08:48:45 --> Loader Class Initialized
DEBUG - 2014-02-28 08:48:45 --> Database Driver Class Initialized
DEBUG - 2014-02-28 08:48:45 --> Session Class Initialized
DEBUG - 2014-02-28 08:48:45 --> Helper loaded: string_helper
DEBUG - 2014-02-28 08:48:45 --> Session routines successfully run
DEBUG - 2014-02-28 08:48:45 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 08:48:45 --> User Agent Class Initialized
DEBUG - 2014-02-28 08:48:45 --> Controller Class Initialized
DEBUG - 2014-02-28 08:48:46 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 08:48:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-02-28 08:53:06 --> Config Class Initialized
DEBUG - 2014-02-28 08:53:06 --> Hooks Class Initialized
DEBUG - 2014-02-28 08:53:06 --> Utf8 Class Initialized
DEBUG - 2014-02-28 08:53:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 08:53:06 --> URI Class Initialized
DEBUG - 2014-02-28 08:53:06 --> Router Class Initialized
DEBUG - 2014-02-28 08:53:06 --> Output Class Initialized
DEBUG - 2014-02-28 08:53:06 --> Security Class Initialized
DEBUG - 2014-02-28 08:53:06 --> Input Class Initialized
DEBUG - 2014-02-28 08:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 08:53:06 --> Language Class Initialized
DEBUG - 2014-02-28 08:53:06 --> Loader Class Initialized
DEBUG - 2014-02-28 08:53:06 --> Database Driver Class Initialized
DEBUG - 2014-02-28 08:53:06 --> Session Class Initialized
DEBUG - 2014-02-28 08:53:06 --> Helper loaded: string_helper
DEBUG - 2014-02-28 08:53:06 --> Session routines successfully run
DEBUG - 2014-02-28 08:53:06 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 08:53:06 --> User Agent Class Initialized
DEBUG - 2014-02-28 08:53:06 --> Controller Class Initialized
DEBUG - 2014-02-28 08:53:06 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 08:53:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-02-28 08:53:06 --> Database Driver Class Initialized
DEBUG - 2014-02-28 08:53:07 --> Session Class Initialized
DEBUG - 2014-02-28 08:53:07 --> Session routines successfully run
DEBUG - 2014-02-28 08:53:07 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 08:53:07 --> User Agent Class Initialized
DEBUG - 2014-02-28 08:53:07 --> Controller Class Initialized
DEBUG - 2014-02-28 08:53:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2014-02-28 08:53:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-02-28 08:53:07 --> Helper loaded: form_helper
DEBUG - 2014-02-28 08:53:07 --> Helper loaded: url_helper
DEBUG - 2014-02-28 08:53:07 --> Model Class Initialized
DEBUG - 2014-02-28 08:53:07 --> Language file loaded: language/zh_TW/main_teacher_lang.php
DEBUG - 2014-02-28 08:53:07 --> File loaded: application/views/teacher/main.php
DEBUG - 2014-02-28 08:53:07 --> Final output sent to browser
DEBUG - 2014-02-28 08:53:07 --> Total execution time: 0.9236
DEBUG - 2014-02-28 08:53:25 --> Config Class Initialized
DEBUG - 2014-02-28 08:53:25 --> Hooks Class Initialized
DEBUG - 2014-02-28 08:53:25 --> Utf8 Class Initialized
DEBUG - 2014-02-28 08:53:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 08:53:25 --> URI Class Initialized
DEBUG - 2014-02-28 08:53:25 --> Router Class Initialized
DEBUG - 2014-02-28 08:53:25 --> Output Class Initialized
DEBUG - 2014-02-28 08:53:25 --> Security Class Initialized
DEBUG - 2014-02-28 08:53:25 --> Input Class Initialized
DEBUG - 2014-02-28 08:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 08:53:25 --> Language Class Initialized
DEBUG - 2014-02-28 08:53:25 --> Loader Class Initialized
DEBUG - 2014-02-28 08:53:25 --> Database Driver Class Initialized
DEBUG - 2014-02-28 08:53:25 --> Session Class Initialized
DEBUG - 2014-02-28 08:53:25 --> Helper loaded: string_helper
DEBUG - 2014-02-28 08:53:25 --> Session routines successfully run
DEBUG - 2014-02-28 08:53:25 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 08:53:25 --> User Agent Class Initialized
DEBUG - 2014-02-28 08:53:25 --> Controller Class Initialized
DEBUG - 2014-02-28 08:53:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2014-02-28 08:53:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-02-28 08:53:25 --> Helper loaded: form_helper
DEBUG - 2014-02-28 08:53:25 --> Helper loaded: url_helper
DEBUG - 2014-02-28 08:53:25 --> Model Class Initialized
DEBUG - 2014-02-28 08:53:25 --> Language file loaded: language/zh_TW/main_teacher_lang.php
DEBUG - 2014-02-28 08:53:25 --> File loaded: application/views/teacher/main.php
DEBUG - 2014-02-28 08:53:26 --> Final output sent to browser
DEBUG - 2014-02-28 08:53:26 --> Total execution time: 0.6201
DEBUG - 2014-02-28 09:01:56 --> Config Class Initialized
DEBUG - 2014-02-28 09:01:56 --> Hooks Class Initialized
DEBUG - 2014-02-28 09:01:56 --> Utf8 Class Initialized
DEBUG - 2014-02-28 09:01:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 09:01:56 --> URI Class Initialized
DEBUG - 2014-02-28 09:01:56 --> Router Class Initialized
DEBUG - 2014-02-28 09:01:57 --> No URI present. Default controller set.
DEBUG - 2014-02-28 09:01:57 --> Output Class Initialized
DEBUG - 2014-02-28 09:01:57 --> Security Class Initialized
DEBUG - 2014-02-28 09:01:57 --> Input Class Initialized
DEBUG - 2014-02-28 09:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 09:01:57 --> Language Class Initialized
DEBUG - 2014-02-28 09:01:57 --> Loader Class Initialized
DEBUG - 2014-02-28 09:01:57 --> Database Driver Class Initialized
DEBUG - 2014-02-28 09:01:57 --> Session Class Initialized
DEBUG - 2014-02-28 09:01:57 --> Helper loaded: string_helper
DEBUG - 2014-02-28 09:01:57 --> Session routines successfully run
DEBUG - 2014-02-28 09:01:57 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 09:01:57 --> User Agent Class Initialized
DEBUG - 2014-02-28 09:01:57 --> Controller Class Initialized
DEBUG - 2014-02-28 09:01:57 --> Helper loaded: url_helper
DEBUG - 2014-02-28 09:01:57 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 09:01:57 --> this->setMessage()
DEBUG - 2014-02-28 09:01:57 --> Model Class Initialized
DEBUG - 2014-02-28 09:01:57 --> this->setMessage()
DEBUG - 2014-02-28 09:01:57 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 09:01:57 --> Final output sent to browser
DEBUG - 2014-02-28 09:01:57 --> Total execution time: 0.7159
DEBUG - 2014-02-28 09:02:03 --> Config Class Initialized
DEBUG - 2014-02-28 09:02:03 --> Hooks Class Initialized
DEBUG - 2014-02-28 09:02:03 --> Utf8 Class Initialized
DEBUG - 2014-02-28 09:02:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 09:02:03 --> URI Class Initialized
DEBUG - 2014-02-28 09:02:03 --> Router Class Initialized
DEBUG - 2014-02-28 09:02:03 --> No URI present. Default controller set.
DEBUG - 2014-02-28 09:02:03 --> Output Class Initialized
DEBUG - 2014-02-28 09:02:03 --> Security Class Initialized
DEBUG - 2014-02-28 09:02:03 --> Input Class Initialized
DEBUG - 2014-02-28 09:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 09:02:03 --> Language Class Initialized
DEBUG - 2014-02-28 09:02:03 --> Loader Class Initialized
DEBUG - 2014-02-28 09:02:03 --> Database Driver Class Initialized
DEBUG - 2014-02-28 09:02:03 --> Session Class Initialized
DEBUG - 2014-02-28 09:02:03 --> Helper loaded: string_helper
DEBUG - 2014-02-28 09:02:03 --> Session routines successfully run
DEBUG - 2014-02-28 09:02:03 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 09:02:03 --> User Agent Class Initialized
DEBUG - 2014-02-28 09:02:03 --> Controller Class Initialized
DEBUG - 2014-02-28 09:02:03 --> Helper loaded: url_helper
DEBUG - 2014-02-28 09:02:03 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 09:02:03 --> this->setMessage()
DEBUG - 2014-02-28 09:02:03 --> Model Class Initialized
DEBUG - 2014-02-28 09:02:03 --> this->setMessage()
DEBUG - 2014-02-28 09:02:03 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 09:02:03 --> Final output sent to browser
DEBUG - 2014-02-28 09:02:03 --> Total execution time: 0.5397
DEBUG - 2014-02-28 09:03:06 --> Config Class Initialized
DEBUG - 2014-02-28 09:03:06 --> Hooks Class Initialized
DEBUG - 2014-02-28 09:03:06 --> Utf8 Class Initialized
DEBUG - 2014-02-28 09:03:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 09:03:06 --> URI Class Initialized
DEBUG - 2014-02-28 09:03:06 --> Router Class Initialized
DEBUG - 2014-02-28 09:03:06 --> No URI present. Default controller set.
DEBUG - 2014-02-28 09:03:06 --> Output Class Initialized
DEBUG - 2014-02-28 09:03:06 --> Security Class Initialized
DEBUG - 2014-02-28 09:03:06 --> Input Class Initialized
DEBUG - 2014-02-28 09:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 09:03:06 --> Language Class Initialized
DEBUG - 2014-02-28 09:03:06 --> Loader Class Initialized
DEBUG - 2014-02-28 09:03:06 --> Database Driver Class Initialized
DEBUG - 2014-02-28 09:03:06 --> Session Class Initialized
DEBUG - 2014-02-28 09:03:06 --> Helper loaded: string_helper
DEBUG - 2014-02-28 09:03:06 --> Session routines successfully run
DEBUG - 2014-02-28 09:03:07 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 09:03:07 --> User Agent Class Initialized
DEBUG - 2014-02-28 09:03:07 --> Controller Class Initialized
DEBUG - 2014-02-28 09:03:07 --> Helper loaded: url_helper
DEBUG - 2014-02-28 09:03:07 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 09:03:07 --> this->setMessage()
DEBUG - 2014-02-28 09:03:07 --> Model Class Initialized
DEBUG - 2014-02-28 09:03:07 --> this->setMessage()
DEBUG - 2014-02-28 09:03:07 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 09:03:07 --> Final output sent to browser
DEBUG - 2014-02-28 09:03:07 --> Total execution time: 0.7130
DEBUG - 2014-02-28 09:03:18 --> Config Class Initialized
DEBUG - 2014-02-28 09:03:18 --> Hooks Class Initialized
DEBUG - 2014-02-28 09:03:18 --> Utf8 Class Initialized
DEBUG - 2014-02-28 09:03:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 09:03:18 --> URI Class Initialized
DEBUG - 2014-02-28 09:03:18 --> Router Class Initialized
DEBUG - 2014-02-28 09:03:18 --> No URI present. Default controller set.
DEBUG - 2014-02-28 09:03:18 --> Output Class Initialized
DEBUG - 2014-02-28 09:03:18 --> Security Class Initialized
DEBUG - 2014-02-28 09:03:18 --> Input Class Initialized
DEBUG - 2014-02-28 09:03:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 09:03:18 --> Language Class Initialized
DEBUG - 2014-02-28 09:03:18 --> Loader Class Initialized
DEBUG - 2014-02-28 09:03:18 --> Database Driver Class Initialized
DEBUG - 2014-02-28 09:03:18 --> Session Class Initialized
DEBUG - 2014-02-28 09:03:18 --> Helper loaded: string_helper
DEBUG - 2014-02-28 09:03:18 --> Session routines successfully run
DEBUG - 2014-02-28 09:03:18 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 09:03:18 --> User Agent Class Initialized
DEBUG - 2014-02-28 09:03:18 --> Controller Class Initialized
DEBUG - 2014-02-28 09:03:18 --> Helper loaded: url_helper
DEBUG - 2014-02-28 09:03:18 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 09:03:18 --> this->setMessage()
DEBUG - 2014-02-28 09:03:18 --> Model Class Initialized
DEBUG - 2014-02-28 09:03:18 --> this->setMessage()
DEBUG - 2014-02-28 09:03:18 --> File loaded: application/views/login.php
DEBUG - 2014-02-28 09:03:18 --> Final output sent to browser
DEBUG - 2014-02-28 09:03:18 --> Total execution time: 0.6405
DEBUG - 2014-02-28 09:03:38 --> Config Class Initialized
DEBUG - 2014-02-28 09:03:38 --> Hooks Class Initialized
DEBUG - 2014-02-28 09:03:38 --> Utf8 Class Initialized
DEBUG - 2014-02-28 09:03:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-28 09:03:38 --> URI Class Initialized
DEBUG - 2014-02-28 09:03:38 --> Router Class Initialized
DEBUG - 2014-02-28 09:03:38 --> Output Class Initialized
DEBUG - 2014-02-28 09:03:38 --> Security Class Initialized
DEBUG - 2014-02-28 09:03:38 --> Input Class Initialized
DEBUG - 2014-02-28 09:03:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-28 09:03:38 --> Language Class Initialized
DEBUG - 2014-02-28 09:03:38 --> Loader Class Initialized
DEBUG - 2014-02-28 09:03:38 --> Database Driver Class Initialized
DEBUG - 2014-02-28 09:03:38 --> Session Class Initialized
DEBUG - 2014-02-28 09:03:38 --> Helper loaded: string_helper
DEBUG - 2014-02-28 09:03:38 --> Session routines successfully run
DEBUG - 2014-02-28 09:03:38 --> XML-RPC Class Initialized
DEBUG - 2014-02-28 09:03:38 --> User Agent Class Initialized
DEBUG - 2014-02-28 09:03:38 --> Controller Class Initialized
DEBUG - 2014-02-28 09:03:38 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-28 09:03:38 --> Session class already loaded. Second attempt ignored.
