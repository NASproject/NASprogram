<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-24 05:39:08 --> Config Class Initialized
DEBUG - 2014-02-24 05:39:08 --> Hooks Class Initialized
DEBUG - 2014-02-24 05:39:08 --> Utf8 Class Initialized
DEBUG - 2014-02-24 05:39:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-24 05:39:08 --> URI Class Initialized
DEBUG - 2014-02-24 05:39:08 --> Router Class Initialized
DEBUG - 2014-02-24 05:39:08 --> No URI present. Default controller set.
DEBUG - 2014-02-24 05:39:08 --> Output Class Initialized
DEBUG - 2014-02-24 05:39:08 --> Security Class Initialized
DEBUG - 2014-02-24 05:39:08 --> Input Class Initialized
DEBUG - 2014-02-24 05:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-24 05:39:08 --> Language Class Initialized
DEBUG - 2014-02-24 05:39:08 --> Loader Class Initialized
DEBUG - 2014-02-24 05:39:08 --> Controller Class Initialized
DEBUG - 2014-02-24 05:39:08 --> Helper loaded: url_helper
DEBUG - 2014-02-24 05:39:08 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-24 05:39:08 --> Model Class Initialized
DEBUG - 2014-02-24 05:39:08 --> Database Driver Class Initialized
ERROR - 2014-02-24 05:39:08 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\apps\career\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-24 05:39:09 --> File loaded: application/views/login.php
DEBUG - 2014-02-24 05:39:09 --> Final output sent to browser
DEBUG - 2014-02-24 05:39:09 --> Total execution time: 1.7474
DEBUG - 2014-02-24 06:12:52 --> Config Class Initialized
DEBUG - 2014-02-24 06:23:11 --> Config Class Initialized
ERROR - 2014-02-24 06:23:11 --> Severity: Notice  --> Undefined property: MY_Log::$load C:\wamp\apps\career\application\libraries\MY_Log.php 12
DEBUG - 2014-02-24 06:23:38 --> Config Class Initialized
DEBUG - 2014-02-24 06:23:38 --> Hooks Class Initialized
DEBUG - 2014-02-24 06:23:38 --> Utf8 Class Initialized
DEBUG - 2014-02-24 06:23:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-24 06:23:38 --> URI Class Initialized
DEBUG - 2014-02-24 06:23:38 --> Router Class Initialized
DEBUG - 2014-02-24 06:23:38 --> No URI present. Default controller set.
DEBUG - 2014-02-24 06:23:38 --> Output Class Initialized
DEBUG - 2014-02-24 06:23:38 --> Security Class Initialized
DEBUG - 2014-02-24 06:23:38 --> Input Class Initialized
DEBUG - 2014-02-24 06:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-24 06:23:38 --> Language Class Initialized
DEBUG - 2014-02-24 06:23:38 --> Loader Class Initialized
DEBUG - 2014-02-24 06:23:38 --> Database Driver Class Initialized
ERROR - 2014-02-24 06:23:38 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\apps\career\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-24 06:23:41 --> Config Class Initialized
DEBUG - 2014-02-24 06:23:41 --> Hooks Class Initialized
DEBUG - 2014-02-24 06:23:41 --> Utf8 Class Initialized
DEBUG - 2014-02-24 06:23:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-24 06:23:41 --> URI Class Initialized
DEBUG - 2014-02-24 06:23:41 --> Router Class Initialized
DEBUG - 2014-02-24 06:23:41 --> No URI present. Default controller set.
DEBUG - 2014-02-24 06:23:41 --> Output Class Initialized
DEBUG - 2014-02-24 06:23:41 --> Security Class Initialized
DEBUG - 2014-02-24 06:23:41 --> Input Class Initialized
DEBUG - 2014-02-24 06:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-24 06:23:41 --> Language Class Initialized
DEBUG - 2014-02-24 06:23:41 --> Loader Class Initialized
DEBUG - 2014-02-24 06:23:41 --> Database Driver Class Initialized
ERROR - 2014-02-24 06:23:41 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\apps\career\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-24 06:23:43 --> Config Class Initialized
DEBUG - 2014-02-24 06:23:43 --> Hooks Class Initialized
DEBUG - 2014-02-24 06:23:43 --> Utf8 Class Initialized
DEBUG - 2014-02-24 06:23:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-24 06:23:43 --> URI Class Initialized
DEBUG - 2014-02-24 06:23:43 --> Router Class Initialized
DEBUG - 2014-02-24 06:23:43 --> No URI present. Default controller set.
DEBUG - 2014-02-24 06:23:43 --> Output Class Initialized
DEBUG - 2014-02-24 06:23:43 --> Security Class Initialized
DEBUG - 2014-02-24 06:23:43 --> Input Class Initialized
DEBUG - 2014-02-24 06:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-24 06:23:43 --> Language Class Initialized
DEBUG - 2014-02-24 06:23:43 --> Loader Class Initialized
DEBUG - 2014-02-24 06:23:43 --> Database Driver Class Initialized
ERROR - 2014-02-24 06:23:43 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\apps\career\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-24 06:30:54 --> Config Class Initialized
DEBUG - 2014-02-24 06:30:54 --> Hooks Class Initialized
DEBUG - 2014-02-24 06:30:54 --> Utf8 Class Initialized
DEBUG - 2014-02-24 06:30:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-24 06:30:54 --> URI Class Initialized
DEBUG - 2014-02-24 06:30:54 --> Router Class Initialized
DEBUG - 2014-02-24 06:30:54 --> No URI present. Default controller set.
DEBUG - 2014-02-24 06:30:54 --> Output Class Initialized
DEBUG - 2014-02-24 06:30:54 --> Security Class Initialized
DEBUG - 2014-02-24 06:30:54 --> Input Class Initialized
DEBUG - 2014-02-24 06:30:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-24 06:30:54 --> Language Class Initialized
DEBUG - 2014-02-24 06:30:54 --> Loader Class Initialized
DEBUG - 2014-02-24 06:30:54 --> Database Driver Class Initialized
DEBUG - 2014-02-24 06:30:54 --> localhostjeffjeff0115
ERROR - 2014-02-24 06:30:55 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\apps\career\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-02-24 06:35:26 --> Config Class Initialized
DEBUG - 2014-02-24 06:35:26 --> Hooks Class Initialized
DEBUG - 2014-02-24 06:35:26 --> Utf8 Class Initialized
DEBUG - 2014-02-24 06:35:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-24 06:35:26 --> URI Class Initialized
DEBUG - 2014-02-24 06:35:26 --> Router Class Initialized
DEBUG - 2014-02-24 06:35:26 --> No URI present. Default controller set.
DEBUG - 2014-02-24 06:35:26 --> Output Class Initialized
DEBUG - 2014-02-24 06:35:26 --> Security Class Initialized
DEBUG - 2014-02-24 06:35:26 --> Input Class Initialized
DEBUG - 2014-02-24 06:35:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-24 06:35:26 --> Language Class Initialized
DEBUG - 2014-02-24 06:35:26 --> Loader Class Initialized
DEBUG - 2014-02-24 06:35:26 --> Database Driver Class Initialized
DEBUG - 2014-02-24 06:35:26 --> localhostjeffjeff0115
DEBUG - 2014-02-24 06:35:27 --> Session Class Initialized
DEBUG - 2014-02-24 06:35:27 --> Helper loaded: string_helper
DEBUG - 2014-02-24 06:35:27 --> A session cookie was not found.
DEBUG - 2014-02-24 06:35:27 --> Session routines successfully run
DEBUG - 2014-02-24 06:35:28 --> XML-RPC Class Initialized
DEBUG - 2014-02-24 06:35:28 --> User Agent Class Initialized
DEBUG - 2014-02-24 06:35:28 --> Controller Class Initialized
DEBUG - 2014-02-24 06:35:28 --> Helper loaded: url_helper
DEBUG - 2014-02-24 06:35:28 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-24 06:35:28 --> Model Class Initialized
DEBUG - 2014-02-24 06:35:28 --> File loaded: application/views/login.php
DEBUG - 2014-02-24 06:35:28 --> Final output sent to browser
DEBUG - 2014-02-24 06:35:28 --> Total execution time: 1.4873
DEBUG - 2014-02-24 06:37:17 --> Config Class Initialized
DEBUG - 2014-02-24 06:37:17 --> Hooks Class Initialized
DEBUG - 2014-02-24 06:37:17 --> Utf8 Class Initialized
DEBUG - 2014-02-24 06:37:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-24 06:37:17 --> URI Class Initialized
DEBUG - 2014-02-24 06:37:17 --> Router Class Initialized
DEBUG - 2014-02-24 06:37:17 --> No URI present. Default controller set.
DEBUG - 2014-02-24 06:37:17 --> Output Class Initialized
DEBUG - 2014-02-24 06:37:17 --> Security Class Initialized
DEBUG - 2014-02-24 06:37:17 --> Input Class Initialized
DEBUG - 2014-02-24 06:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-24 06:37:17 --> Language Class Initialized
DEBUG - 2014-02-24 06:37:17 --> Loader Class Initialized
DEBUG - 2014-02-24 06:37:17 --> Database Driver Class Initialized
ERROR - 2014-02-24 06:37:17 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\apps\career\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-02-24 06:37:18 --> Session Class Initialized
DEBUG - 2014-02-24 06:37:18 --> Helper loaded: string_helper
DEBUG - 2014-02-24 06:37:18 --> Session routines successfully run
DEBUG - 2014-02-24 06:37:18 --> XML-RPC Class Initialized
DEBUG - 2014-02-24 06:37:18 --> User Agent Class Initialized
DEBUG - 2014-02-24 06:37:18 --> Controller Class Initialized
DEBUG - 2014-02-24 06:37:18 --> Helper loaded: url_helper
DEBUG - 2014-02-24 06:37:18 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-24 06:37:18 --> Model Class Initialized
DEBUG - 2014-02-24 06:37:18 --> File loaded: application/views/login.php
DEBUG - 2014-02-24 06:37:18 --> Final output sent to browser
DEBUG - 2014-02-24 06:37:18 --> Total execution time: 1.1399
DEBUG - 2014-02-24 06:38:04 --> Config Class Initialized
ERROR - 2014-02-24 06:38:04 --> Severity: Notice  --> Undefined property: MY_Log::$input C:\wamp\apps\career\application\libraries\MY_Log.php 20
DEBUG - 2014-02-24 06:39:09 --> Config Class Initialized
DEBUG - 2014-02-24 07:08:16 --> Config Class Initialized
DEBUG - 2014-02-24 07:08:51 --> Config Class Initialized
ERROR - 2014-02-24 07:08:51 --> Severity: Notice  --> Undefined property: MY_Log::$input C:\wamp\apps\career\application\libraries\MY_Log.php 21
DEBUG - 2014-02-24 07:11:28 --> Config Class Initialized
ERROR - 2014-02-24 07:11:28 --> Severity: Notice  --> Undefined property: MY_Log::$load C:\wamp\apps\career\application\libraries\MY_Log.php 13
DEBUG - 2014-02-24 07:13:12 --> Config Class Initialized
ERROR - 2014-02-24 07:13:12 --> Severity: Notice  --> Undefined property: MY_Log::$agent C:\wamp\apps\career\application\libraries\MY_Log.php 22
DEBUG - 2014-02-24 07:13:41 --> Config Class Initialized
ERROR - 2014-02-24 07:13:41 --> Severity: Notice  --> Undefined property: MY_Log::$db C:\wamp\apps\career\application\libraries\MY_Log.php 26
DEBUG - 2014-02-24 07:13:45 --> Config Class Initialized
ERROR - 2014-02-24 07:13:45 --> Severity: Notice  --> Undefined property: MY_Log::$db C:\wamp\apps\career\application\libraries\MY_Log.php 26
DEBUG - 2014-02-24 07:14:49 --> Config Class Initialized
ERROR - 2014-02-24 07:14:49 --> Severity: Notice  --> Undefined property: MY_Log::$db C:\wamp\apps\career\application\libraries\MY_Log.php 26
DEBUG - 2014-02-24 07:14:50 --> Config Class Initialized
ERROR - 2014-02-24 07:14:50 --> Severity: Notice  --> Undefined property: MY_Log::$db C:\wamp\apps\career\application\libraries\MY_Log.php 26
DEBUG - 2014-02-24 07:14:51 --> Config Class Initialized
ERROR - 2014-02-24 07:14:51 --> Severity: Notice  --> Undefined property: MY_Log::$db C:\wamp\apps\career\application\libraries\MY_Log.php 26
DEBUG - 2014-02-24 07:14:51 --> Config Class Initialized
ERROR - 2014-02-24 07:14:51 --> Severity: Notice  --> Undefined property: MY_Log::$db C:\wamp\apps\career\application\libraries\MY_Log.php 26
DEBUG - 2014-02-24 07:17:56 --> Config Class Initialized
ERROR - 2014-02-24 07:17:56 --> Severity: Notice  --> Undefined property: MY_Log::$db C:\wamp\apps\career\application\libraries\MY_Log.php 29
DEBUG - 2014-02-24 07:18:20 --> Config Class Initialized
DEBUG - 2014-02-24 07:18:20 --> Hooks Class Initialized
DEBUG - 2014-02-24 07:18:20 --> Utf8 Class Initialized
DEBUG - 2014-02-24 07:18:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-24 07:18:20 --> URI Class Initialized
DEBUG - 2014-02-24 07:18:20 --> Router Class Initialized
DEBUG - 2014-02-24 07:18:20 --> No URI present. Default controller set.
DEBUG - 2014-02-24 07:18:20 --> Output Class Initialized
DEBUG - 2014-02-24 07:18:20 --> Security Class Initialized
DEBUG - 2014-02-24 07:18:21 --> Input Class Initialized
DEBUG - 2014-02-24 07:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-24 07:18:21 --> Language Class Initialized
DEBUG - 2014-02-24 07:18:21 --> Loader Class Initialized
DEBUG - 2014-02-24 07:18:21 --> Database Driver Class Initialized
DEBUG - 2014-02-24 07:18:21 --> Session Class Initialized
DEBUG - 2014-02-24 07:18:21 --> Helper loaded: string_helper
DEBUG - 2014-02-24 07:18:21 --> Session routines successfully run
DEBUG - 2014-02-24 07:18:21 --> XML-RPC Class Initialized
DEBUG - 2014-02-24 07:18:21 --> User Agent Class Initialized
DEBUG - 2014-02-24 07:18:21 --> Controller Class Initialized
DEBUG - 2014-02-24 07:18:21 --> Helper loaded: url_helper
DEBUG - 2014-02-24 07:18:21 --> Language file loaded: language/zh_TW/login_lang.php
DEBUG - 2014-02-24 07:18:21 --> Model Class Initialized
DEBUG - 2014-02-24 07:18:21 --> File loaded: application/views/login.php
DEBUG - 2014-02-24 07:18:21 --> Final output sent to browser
DEBUG - 2014-02-24 07:18:21 --> Total execution time: 0.4599
