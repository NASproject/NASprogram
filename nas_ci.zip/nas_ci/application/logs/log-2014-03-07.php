<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-03-07 00:37:35 --> Config Class Initialized
DEBUG - 2014-03-07 00:37:35 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:37:35 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:37:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:37:35 --> URI Class Initialized
DEBUG - 2014-03-07 00:37:35 --> Router Class Initialized
DEBUG - 2014-03-07 00:37:35 --> Output Class Initialized
DEBUG - 2014-03-07 00:37:36 --> Security Class Initialized
DEBUG - 2014-03-07 00:37:36 --> Input Class Initialized
DEBUG - 2014-03-07 00:37:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:37:36 --> Language Class Initialized
ERROR - 2014-03-07 00:37:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\nas\application\hooks\LogHook.php 19
DEBUG - 2014-03-07 00:38:23 --> Config Class Initialized
DEBUG - 2014-03-07 00:38:23 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:38:23 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:38:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:38:23 --> URI Class Initialized
DEBUG - 2014-03-07 00:38:23 --> Router Class Initialized
DEBUG - 2014-03-07 00:38:23 --> Output Class Initialized
DEBUG - 2014-03-07 00:38:23 --> Security Class Initialized
DEBUG - 2014-03-07 00:38:23 --> Input Class Initialized
DEBUG - 2014-03-07 00:38:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:38:23 --> Language Class Initialized
DEBUG - 2014-03-07 00:38:23 --> Loader Class Initialized
DEBUG - 2014-03-07 00:38:23 --> Database Driver Class Initialized
ERROR - 2014-03-07 00:38:23 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\www\nas\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-03-07 00:38:24 --> Session Class Initialized
DEBUG - 2014-03-07 00:38:24 --> Helper loaded: string_helper
DEBUG - 2014-03-07 00:38:24 --> A session cookie was not found.
DEBUG - 2014-03-07 00:38:24 --> Session routines successfully run
DEBUG - 2014-03-07 00:38:24 --> XML-RPC Class Initialized
DEBUG - 2014-03-07 00:38:24 --> User Agent Class Initialized
DEBUG - 2014-03-07 00:38:24 --> Controller Class Initialized
DEBUG - 2014-03-07 08:38:25 --> File loaded: application/views/logView.php
DEBUG - 2014-03-07 08:38:25 --> Final output sent to browser
DEBUG - 2014-03-07 08:38:25 --> Total execution time: 1.6282
DEBUG - 2014-03-07 00:38:25 --> Config Class Initialized
DEBUG - 2014-03-07 00:38:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:38:25 --> Config Class Initialized
DEBUG - 2014-03-07 00:38:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:38:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:38:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:38:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:38:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:38:25 --> URI Class Initialized
DEBUG - 2014-03-07 00:38:25 --> URI Class Initialized
DEBUG - 2014-03-07 00:38:25 --> Router Class Initialized
DEBUG - 2014-03-07 00:38:25 --> Router Class Initialized
ERROR - 2014-03-07 00:38:25 --> 404 Page Not Found --> %7BbaseURL%7Dpublic
ERROR - 2014-03-07 00:38:25 --> 404 Page Not Found --> %7BbaseURL%7Dpublic
DEBUG - 2014-03-07 00:39:46 --> Config Class Initialized
DEBUG - 2014-03-07 00:39:46 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:39:46 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:39:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:39:46 --> URI Class Initialized
DEBUG - 2014-03-07 00:39:46 --> Router Class Initialized
DEBUG - 2014-03-07 00:39:46 --> Output Class Initialized
DEBUG - 2014-03-07 00:39:46 --> Security Class Initialized
DEBUG - 2014-03-07 00:39:46 --> Input Class Initialized
DEBUG - 2014-03-07 00:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:39:46 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:15 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:15 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:15 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:15 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:15 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:15 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:15 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:15 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:15 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:15 --> Loader Class Initialized
DEBUG - 2014-03-07 00:40:15 --> Database Driver Class Initialized
ERROR - 2014-03-07 00:40:15 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\www\nas\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-03-07 00:40:16 --> Session Class Initialized
DEBUG - 2014-03-07 00:40:16 --> Helper loaded: string_helper
DEBUG - 2014-03-07 00:40:16 --> Session routines successfully run
DEBUG - 2014-03-07 00:40:16 --> XML-RPC Class Initialized
DEBUG - 2014-03-07 00:40:16 --> User Agent Class Initialized
DEBUG - 2014-03-07 00:40:16 --> Controller Class Initialized
DEBUG - 2014-03-07 00:40:16 --> Helper loaded: url_helper
DEBUG - 2014-03-07 08:40:16 --> File loaded: application/views/logView.php
DEBUG - 2014-03-07 08:40:16 --> Final output sent to browser
DEBUG - 2014-03-07 08:40:16 --> Total execution time: 1.2278
DEBUG - 2014-03-07 00:40:16 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:16 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:16 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:16 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:16 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:16 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:16 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:16 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:16 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:17 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:17 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:17 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:17 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:17 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:17 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:17 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:17 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:17 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:18 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:18 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:18 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:18 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:18 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:18 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:18 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:18 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:18 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:19 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:19 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:19 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:19 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:20 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:20 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:20 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:20 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:20 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:21 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:21 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:21 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:21 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:21 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:21 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:21 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:21 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:21 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:22 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:22 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:22 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:22 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:22 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:22 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:22 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:22 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:22 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:23 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:23 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:23 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:23 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:23 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:23 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:23 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:23 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:23 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:25 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:25 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:25 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:25 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:25 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:25 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:25 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:27 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:27 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:27 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:27 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:27 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:27 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:27 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:27 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:27 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:29 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:29 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:29 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:29 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:29 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:29 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:29 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:29 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:29 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:31 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:31 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:31 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:31 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:31 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:31 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:31 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:33 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:33 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:33 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:33 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:33 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:33 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:33 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:33 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:33 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:35 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:35 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:35 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:35 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:35 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:35 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:35 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:35 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:35 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:37 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:37 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:37 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:37 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:37 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:37 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:37 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:37 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:37 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:39 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:39 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:39 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:39 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:39 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:39 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:39 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:41 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:41 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:41 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:41 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:41 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:41 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:41 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:43 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:43 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:43 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:43 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:43 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:43 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:43 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:45 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:45 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:45 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:45 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:45 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:45 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:45 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:45 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:45 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:47 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:47 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:47 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:47 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:47 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:47 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:47 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:49 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:49 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:49 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:49 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:49 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:49 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:49 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:49 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:49 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:51 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:51 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:51 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:51 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:51 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:51 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:51 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:51 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:51 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:53 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:53 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:53 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:53 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:53 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:53 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:53 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:54 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:54 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:54 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:55 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:55 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:55 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:55 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:56 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:56 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:56 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:56 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:56 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:56 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:56 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:56 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:56 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:57 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:57 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:57 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:57 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:57 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:57 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:57 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:57 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:57 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:58 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:58 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:58 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:58 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:58 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:58 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:58 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:58 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:58 --> Language Class Initialized
DEBUG - 2014-03-07 00:40:59 --> Config Class Initialized
DEBUG - 2014-03-07 00:40:59 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:40:59 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:40:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:40:59 --> URI Class Initialized
DEBUG - 2014-03-07 00:40:59 --> Router Class Initialized
DEBUG - 2014-03-07 00:40:59 --> Output Class Initialized
DEBUG - 2014-03-07 00:40:59 --> Security Class Initialized
DEBUG - 2014-03-07 00:40:59 --> Input Class Initialized
DEBUG - 2014-03-07 00:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:40:59 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:00 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:00 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:00 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:00 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:00 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:00 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:00 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:00 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:00 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:01 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:01 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:01 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:01 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:01 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:01 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:01 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:03 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:03 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:03 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:03 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:03 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:03 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:03 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:03 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:03 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:05 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:05 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:05 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:05 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:05 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:05 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:05 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:05 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:05 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:07 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:07 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:07 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:07 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:07 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:07 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:07 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:07 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:07 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:09 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:09 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:09 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:09 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:09 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:09 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:09 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:11 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:11 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:11 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:11 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:11 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:11 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:11 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:13 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:13 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:13 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:13 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:13 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:13 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:13 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:13 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:13 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:15 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:15 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:15 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:15 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:15 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:15 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:15 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:15 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:15 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:17 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:17 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:17 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:17 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:17 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:17 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:17 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:17 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:17 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:19 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:19 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:19 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:19 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:19 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:19 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:19 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:19 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:19 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:21 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:21 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:21 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:21 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:21 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:21 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:21 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:21 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:21 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:23 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:23 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:23 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:23 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:23 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:23 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:23 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:23 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:23 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:25 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:25 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:25 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:25 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:25 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:25 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:25 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:27 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:27 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:27 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:27 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:27 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:27 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:27 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:27 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:27 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:28 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:28 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:28 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:28 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:28 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:28 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:28 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:29 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:29 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:29 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:29 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:29 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:29 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:29 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:29 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:30 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:31 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:31 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:31 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:31 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:31 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:31 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:31 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:32 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:32 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:32 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:32 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:32 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:32 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:32 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:33 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:33 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:33 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:33 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:33 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:33 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:33 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:33 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:33 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:34 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:34 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:34 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:34 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:34 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:34 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:34 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:35 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:35 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:35 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:35 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:35 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:35 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:35 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:35 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:35 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:37 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:37 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:37 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:37 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:37 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:37 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:37 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:37 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:37 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:38 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:38 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:38 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:38 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:38 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:38 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:38 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:39 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:39 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:39 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:39 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:39 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:39 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:39 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:40 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:40 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:40 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:40 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:40 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:40 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:40 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:40 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:40 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:41 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:41 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:41 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:41 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:41 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:41 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:41 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:42 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:42 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:42 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:42 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:42 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:42 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:42 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:43 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:43 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:43 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:43 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:43 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:43 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:43 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:44 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:44 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:44 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:44 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:44 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:44 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:44 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:44 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:44 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:45 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:45 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:45 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:45 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:45 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:45 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:45 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:45 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:45 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:46 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:46 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:46 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:46 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:46 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:46 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:46 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:46 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:46 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:47 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:47 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:47 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:47 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:47 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:47 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:47 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:49 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:49 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:49 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:49 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:49 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:49 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:49 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:49 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:49 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:50 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:50 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:50 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:50 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:50 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:50 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:50 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:50 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:50 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:51 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:51 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:51 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:51 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:51 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:51 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:51 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:51 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:51 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:52 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:52 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:52 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:52 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:52 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:52 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:52 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:52 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:52 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:53 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:53 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Loader Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Session Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 00:41:53 --> Session routines successfully run
DEBUG - 2014-03-07 00:41:53 --> XML-RPC Class Initialized
DEBUG - 2014-03-07 00:41:53 --> User Agent Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Controller Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 08:41:53 --> File loaded: application/views/logView.php
DEBUG - 2014-03-07 08:41:53 --> Final output sent to browser
DEBUG - 2014-03-07 08:41:53 --> Total execution time: 0.4398
DEBUG - 2014-03-07 00:41:53 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:53 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:53 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:55 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:55 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:55 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:55 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:55 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:55 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:55 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:55 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:55 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:56 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:56 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:56 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:56 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:56 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:56 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:56 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:56 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:56 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:57 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:57 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:57 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:57 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:57 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:57 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:57 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:57 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:57 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:58 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:58 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:58 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:58 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:58 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:58 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:58 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:58 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:58 --> Language Class Initialized
DEBUG - 2014-03-07 00:41:59 --> Config Class Initialized
DEBUG - 2014-03-07 00:41:59 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:41:59 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:41:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:41:59 --> URI Class Initialized
DEBUG - 2014-03-07 00:41:59 --> Router Class Initialized
DEBUG - 2014-03-07 00:41:59 --> Output Class Initialized
DEBUG - 2014-03-07 00:41:59 --> Security Class Initialized
DEBUG - 2014-03-07 00:41:59 --> Input Class Initialized
DEBUG - 2014-03-07 00:41:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:41:59 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:00 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:00 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:00 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:00 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:00 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:00 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:00 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:00 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:00 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:01 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:01 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:02 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:02 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:02 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:02 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:02 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:03 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:03 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:03 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:03 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:03 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:03 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:03 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:03 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:03 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:04 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:04 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:04 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:04 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:04 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:04 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:04 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:04 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:04 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:05 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:05 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:05 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:05 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:05 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:05 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:05 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:05 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:05 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:06 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:06 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:06 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:06 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:06 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:06 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:06 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:06 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:06 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:07 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:07 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:07 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:07 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:07 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:07 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:07 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:07 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:07 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:08 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:08 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:08 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:08 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:08 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:08 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:08 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:08 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:08 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:09 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:09 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:09 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:09 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:09 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:09 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:09 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:10 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:10 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:11 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:11 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:11 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:11 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:11 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:11 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:12 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:12 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:12 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:12 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:12 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:12 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:12 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:13 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:13 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:13 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:13 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:13 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:13 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:13 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:13 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:13 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:14 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:14 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:14 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:14 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:14 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:14 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:14 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:15 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:15 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:15 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:15 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:15 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:15 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:15 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:15 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:15 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:16 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:16 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:16 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:16 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:16 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:16 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:16 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:16 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:16 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:17 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:17 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:17 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:17 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:17 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:17 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:17 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:17 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:17 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:18 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:18 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:18 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:18 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:18 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:18 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:18 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:18 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:18 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:19 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:19 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:19 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:19 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:19 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:19 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:19 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:19 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:20 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:21 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:21 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:21 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:21 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:21 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:21 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:21 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:21 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:21 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:22 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:22 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:22 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:22 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:22 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:22 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:22 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:22 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:22 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:26 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:26 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:26 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:26 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:26 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:26 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:26 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:26 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:26 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:27 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:27 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:27 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:27 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:27 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:27 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:27 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:27 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:27 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:28 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:28 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:28 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:28 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:28 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:28 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:28 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:29 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:29 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:29 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:29 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:29 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:29 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:29 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:29 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:29 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:30 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:30 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:30 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:30 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:30 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:30 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:30 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:31 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:31 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:31 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:31 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:31 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:31 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:31 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:32 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:32 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:32 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:32 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:32 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:32 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:32 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:33 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:33 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:33 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:33 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:33 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:33 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:33 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:33 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:33 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:35 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:35 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:35 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:35 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:35 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:35 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:35 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:35 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:35 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:36 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:36 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:36 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:36 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:36 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:36 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:36 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:36 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:36 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:37 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:37 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:37 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:37 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:37 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:37 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:37 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:37 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:37 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:38 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:38 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:38 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:38 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:38 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:38 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:38 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:39 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:39 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:39 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:39 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:39 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:39 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:39 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:40 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:40 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:40 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:40 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:40 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:40 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:40 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:40 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:40 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:41 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:41 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:41 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:41 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:41 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:41 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:41 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:42 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:42 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:42 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:42 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:42 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:42 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:42 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:43 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:43 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:43 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:43 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:43 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:43 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:43 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:45 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:45 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:45 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:45 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:45 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:45 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:45 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:45 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:45 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:46 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:46 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:46 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:46 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:46 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:46 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:46 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:46 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:46 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:47 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:47 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:47 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:47 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:47 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:47 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:47 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:48 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:48 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:48 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:48 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:48 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:48 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:48 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:48 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:48 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:49 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:49 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:49 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:49 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:49 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:49 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:49 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:49 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:49 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:50 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:50 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:50 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:50 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:50 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:50 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:50 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:50 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:50 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:51 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:51 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:51 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:51 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:51 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:51 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:51 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:51 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:51 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:53 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:53 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:53 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:53 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:53 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:53 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:53 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:54 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:54 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:54 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:54 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:54 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:54 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:54 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:55 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:55 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:55 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:55 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:55 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:55 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:55 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:55 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:55 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:56 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:56 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:56 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:56 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:56 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:56 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:56 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:56 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:56 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:57 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:57 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:57 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:57 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:57 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:57 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:57 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:57 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:57 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:58 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:58 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:58 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:58 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:58 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:58 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:58 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:58 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:58 --> Language Class Initialized
DEBUG - 2014-03-07 00:42:59 --> Config Class Initialized
DEBUG - 2014-03-07 00:42:59 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:42:59 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:42:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:42:59 --> URI Class Initialized
DEBUG - 2014-03-07 00:42:59 --> Router Class Initialized
DEBUG - 2014-03-07 00:42:59 --> Output Class Initialized
DEBUG - 2014-03-07 00:42:59 --> Security Class Initialized
DEBUG - 2014-03-07 00:42:59 --> Input Class Initialized
DEBUG - 2014-03-07 00:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:42:59 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:00 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:00 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:00 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:00 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:00 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:00 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:00 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:00 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:00 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:01 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:01 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:01 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:01 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:01 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:01 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:01 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:02 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:02 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:02 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:02 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:02 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:02 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:02 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:02 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:02 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:03 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:03 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:03 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:03 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:03 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:03 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:03 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:03 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:03 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:04 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:04 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:04 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:04 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:04 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:04 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:04 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:04 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:04 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:05 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:05 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:05 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:05 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:05 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:05 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:05 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:05 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:05 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:06 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:06 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:06 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:06 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:06 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:06 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:06 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:06 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:06 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:07 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:07 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:07 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:07 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:07 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:07 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:07 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:07 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:07 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:08 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:08 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:08 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:08 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:08 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:08 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:08 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:08 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:08 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:09 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:09 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:09 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:09 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:09 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:09 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:09 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:10 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:10 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:10 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:10 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:10 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:10 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:10 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:10 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:10 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:12 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:12 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:12 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:12 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:12 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:12 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:12 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:13 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:13 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:13 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:13 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:13 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:13 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:13 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:13 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:13 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:14 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:14 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:14 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:14 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:14 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:14 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:14 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:15 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:15 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:15 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:15 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:15 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:15 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:15 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:15 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:15 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:16 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:16 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:16 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:16 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:16 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:16 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:16 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:16 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:16 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:17 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:17 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:17 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:17 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:17 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:17 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:17 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:17 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:17 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:18 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:18 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:18 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:18 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:18 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:18 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:18 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:18 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:18 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:19 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:19 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:19 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:19 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:19 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:19 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:19 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:19 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:19 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:20 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:20 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:20 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:21 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:21 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:21 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:21 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:21 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:21 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:22 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:22 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:22 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:22 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:22 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:22 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:22 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:22 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:22 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:23 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:23 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:23 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:23 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:23 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:23 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:23 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:23 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:23 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:24 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:24 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:24 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:24 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:24 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:24 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:24 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:24 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:24 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:25 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:25 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:25 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:25 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:25 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:25 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:25 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:26 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:26 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:26 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:26 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:26 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:26 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:26 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:26 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:26 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:27 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:27 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:27 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:27 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:27 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:27 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:27 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:27 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:27 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:28 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:28 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:28 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:28 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:28 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:29 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:29 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:30 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:30 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:30 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:30 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:30 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:30 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:30 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:31 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:31 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:31 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:31 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:31 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:31 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:31 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:32 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:32 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:32 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:32 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:32 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:32 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:32 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:33 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:33 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:33 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:33 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:33 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:33 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:33 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:33 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:33 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:34 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:34 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:34 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:34 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:34 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:34 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:34 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:35 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:35 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:35 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:35 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:35 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:35 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:35 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:36 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:36 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:37 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:37 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:37 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:37 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:37 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:37 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:37 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:37 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:37 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:38 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:38 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:38 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:38 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:38 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:38 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:38 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:39 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:39 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:39 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:39 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:39 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:39 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:39 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:40 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:40 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:40 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:40 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:40 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:40 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:40 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:40 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:40 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:41 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:41 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:41 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:41 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:41 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:41 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:41 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:42 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:42 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:42 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:42 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:42 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:42 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:42 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:43 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:43 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:43 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:43 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:43 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:43 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:43 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:44 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:44 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:44 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:44 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:44 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:44 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:44 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:44 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:45 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:46 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:46 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:46 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:46 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:46 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:46 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:46 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:46 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:46 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:47 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:47 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:47 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:47 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:47 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:47 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:47 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:48 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:48 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:48 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:48 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:48 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:48 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:48 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:48 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:48 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:49 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:49 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:49 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:49 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:49 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:49 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:49 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:49 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:49 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:50 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:50 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:50 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:50 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:50 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:50 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:50 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:50 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:50 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:51 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:51 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:51 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:51 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:51 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:51 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:51 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:51 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:51 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:52 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:52 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:52 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:52 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:52 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:52 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:52 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:52 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:52 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:53 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:53 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:53 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:53 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:53 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:53 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:53 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:54 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:54 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:54 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:54 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:54 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:54 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:54 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:55 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:55 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:56 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:56 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:56 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:56 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:56 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:56 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:56 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:57 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:57 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:57 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:57 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:57 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:57 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:57 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:57 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:57 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:58 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:58 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:58 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:58 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:58 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:58 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:58 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:58 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:58 --> Language Class Initialized
DEBUG - 2014-03-07 00:43:59 --> Config Class Initialized
DEBUG - 2014-03-07 00:43:59 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:43:59 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:43:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:43:59 --> URI Class Initialized
DEBUG - 2014-03-07 00:43:59 --> Router Class Initialized
DEBUG - 2014-03-07 00:43:59 --> Output Class Initialized
DEBUG - 2014-03-07 00:43:59 --> Security Class Initialized
DEBUG - 2014-03-07 00:43:59 --> Input Class Initialized
DEBUG - 2014-03-07 00:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:43:59 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:00 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:00 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:00 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:00 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:00 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:00 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:00 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:00 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:00 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:01 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:01 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:01 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:01 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:01 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:01 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:01 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:02 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:02 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:02 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:02 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:02 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:02 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:02 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:02 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:03 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:04 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:04 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:04 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:04 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:04 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:04 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:04 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:04 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:04 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:05 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:05 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:05 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:05 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:05 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:05 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:05 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:05 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:05 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:06 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:06 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:06 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:06 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:06 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:06 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:06 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:06 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:06 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:07 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:07 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:07 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:07 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:07 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:07 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:07 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:07 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:07 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:08 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:08 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:08 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:08 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:08 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:08 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:08 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:08 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:08 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:09 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:09 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:09 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:09 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:09 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:09 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:09 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:10 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:10 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:10 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:10 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:10 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:10 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:10 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:10 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:11 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:12 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:12 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:12 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:12 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:12 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:12 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:12 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:13 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:13 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:13 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:13 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:13 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:13 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:13 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:13 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:13 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:14 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:14 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:14 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:14 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:14 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:14 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:14 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:15 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:15 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:15 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:15 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:15 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:15 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:15 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:15 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:15 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:16 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:16 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:16 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:16 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:16 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:16 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:16 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:16 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:16 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:17 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:17 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:17 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:17 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:17 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:17 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:17 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:17 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:17 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:18 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:18 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:18 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:18 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:18 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:18 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:18 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:18 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:18 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:19 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:19 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:19 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:19 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:19 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:19 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:19 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:19 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:19 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:20 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:20 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:20 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:20 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:20 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:20 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:20 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:20 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:21 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:22 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:22 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:22 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:22 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:22 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:22 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:22 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:22 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:22 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:23 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:23 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:23 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:23 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:23 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:23 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:23 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:23 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:23 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:24 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:24 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:24 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:24 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:24 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:24 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:24 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:24 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:24 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:25 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:25 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:25 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:25 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:25 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:25 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:25 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:26 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:26 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:26 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:26 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:26 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:26 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:26 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:26 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:26 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:27 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:27 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:27 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:27 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:27 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:27 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:27 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:27 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:27 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:28 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:28 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:28 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:28 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:28 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:28 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:28 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:30 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:30 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:30 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:30 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:30 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:30 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:30 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:31 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:31 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:31 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:31 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:31 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:31 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:31 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:32 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:32 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:32 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:32 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:32 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:32 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:32 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:33 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:33 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:33 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:33 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:33 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:33 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:33 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:33 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:33 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:34 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:34 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:34 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:34 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:34 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:34 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:34 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:35 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:35 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:35 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:35 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:35 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:35 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:35 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:35 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:35 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:36 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:36 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:36 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:36 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:36 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:36 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:36 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:36 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:36 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:37 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:37 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:37 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:37 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:37 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:37 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:37 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:37 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:38 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:39 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:39 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:39 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:39 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:39 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:39 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:39 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:40 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:40 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:40 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:40 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:40 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:40 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:40 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:40 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:40 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:41 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:41 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:41 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:41 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:41 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:41 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:41 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:42 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:42 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:42 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:42 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:42 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:42 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:42 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:43 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:43 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:43 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:43 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:43 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:43 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:43 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:44 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:44 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:44 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:44 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:44 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:44 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:44 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:44 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:44 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:45 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:45 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:45 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:45 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:45 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:45 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:45 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:45 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:45 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:46 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:46 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:46 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:46 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:46 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:46 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:46 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:46 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:46 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:47 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:47 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:47 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:47 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:47 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:47 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:47 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:48 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:48 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:48 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:48 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:48 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:48 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:48 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:48 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:48 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:50 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:50 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:50 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:50 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:50 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:50 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:50 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:50 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:50 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:51 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:51 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:51 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:51 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:51 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:51 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:51 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:51 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:51 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:52 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:52 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:52 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:52 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:52 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:52 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:52 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:52 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:52 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:53 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:53 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:53 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:53 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:53 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:53 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:53 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:54 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:54 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:54 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:54 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:54 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:54 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:54 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:55 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:55 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:55 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:55 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:55 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:55 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:55 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:55 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:55 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:56 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:56 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:56 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:56 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:56 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:56 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:56 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:56 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:56 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:57 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:57 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:57 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:57 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:57 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:57 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:57 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:57 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:57 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:58 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:58 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:58 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:58 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:58 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:58 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:58 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:58 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:58 --> Language Class Initialized
DEBUG - 2014-03-07 00:44:59 --> Config Class Initialized
DEBUG - 2014-03-07 00:44:59 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:44:59 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:44:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:44:59 --> URI Class Initialized
DEBUG - 2014-03-07 00:44:59 --> Router Class Initialized
DEBUG - 2014-03-07 00:44:59 --> Output Class Initialized
DEBUG - 2014-03-07 00:44:59 --> Security Class Initialized
DEBUG - 2014-03-07 00:44:59 --> Input Class Initialized
DEBUG - 2014-03-07 00:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:44:59 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:00 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:00 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:00 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:00 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:00 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:00 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:00 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:00 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:00 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:02 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:02 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:02 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:02 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:02 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:02 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:02 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:02 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:02 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:03 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:03 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:03 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:03 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:03 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:03 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:03 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:03 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:03 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:04 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:04 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:04 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:04 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:04 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:04 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:04 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:04 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:04 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:05 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:05 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:05 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:05 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:05 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:05 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:05 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:05 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:05 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:06 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:06 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:06 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:06 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:06 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:06 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:06 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:06 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:06 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:07 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:07 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:07 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:07 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:07 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:07 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:07 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:07 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:07 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:08 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:08 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:08 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:08 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:08 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:08 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:08 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:08 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:08 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:09 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:09 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:09 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:09 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:09 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:09 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:09 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:11 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:11 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:11 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:11 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:11 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:11 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:11 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:12 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:12 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:12 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:12 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:12 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:12 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:12 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:13 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:13 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:13 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:13 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:13 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:13 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:13 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:13 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:13 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:14 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:14 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:14 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:14 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:14 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:14 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:14 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:15 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:15 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:15 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:15 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:15 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:15 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:15 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:15 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:15 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:16 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:16 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:16 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:16 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:16 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:16 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:16 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:16 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:16 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:17 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:17 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:17 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:17 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:17 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:17 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:17 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:17 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:17 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:19 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:19 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:19 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:19 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:19 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:19 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:19 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:19 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:19 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:20 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:20 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:20 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:20 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:20 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:20 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:20 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:20 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:20 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:21 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:21 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:21 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:21 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:21 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:21 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:21 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:21 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:21 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:22 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:22 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:22 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:22 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:22 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:22 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:22 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:22 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:22 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:23 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:23 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:23 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:23 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:23 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:23 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:23 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:23 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:23 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:24 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:24 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:24 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:24 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:24 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:24 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:24 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:24 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:24 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:25 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:25 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:25 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:25 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:25 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:25 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:25 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:26 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:26 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:26 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:26 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:26 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:26 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:26 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:26 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:26 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:27 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:27 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:27 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:27 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:27 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:27 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:27 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:27 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:27 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:28 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:28 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:28 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:28 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:28 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:28 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:28 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:30 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:30 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:30 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:30 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:30 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:30 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:30 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:31 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:31 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:31 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:31 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:31 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:31 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:31 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:32 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:32 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:32 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:32 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:32 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:32 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:32 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:33 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:33 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:33 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:33 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:33 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:33 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:33 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:33 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:33 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:34 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:34 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:34 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:34 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:34 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:34 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:34 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:35 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:35 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:35 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:35 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:35 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:35 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:35 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:35 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:35 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:36 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:36 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:36 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:36 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:36 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:36 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:36 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:36 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:36 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:37 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:37 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:37 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:37 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:37 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:37 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:37 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:37 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:37 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:38 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:38 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:38 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:38 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:38 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:38 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:38 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:39 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:39 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:39 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:39 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:39 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:39 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:39 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:40 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:40 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:40 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:40 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:40 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:41 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:41 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:41 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:41 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:42 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:42 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:42 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:42 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:42 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:42 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:42 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:43 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:43 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:43 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:43 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:43 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:43 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:43 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:44 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:44 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:44 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:44 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:44 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:44 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:44 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:44 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:44 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:45 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:45 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:45 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:45 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:45 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:45 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:45 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:45 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:45 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:46 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:46 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:46 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:46 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:46 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:46 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:46 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:46 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:46 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:47 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:47 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:47 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:47 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:47 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:47 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:48 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:49 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:49 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:49 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:49 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:49 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:49 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:49 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:49 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:49 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:50 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:50 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:50 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:50 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:50 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:50 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:50 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:50 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:50 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:51 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:51 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:51 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:51 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:51 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:51 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:51 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:51 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:51 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:52 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:52 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:52 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:52 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:52 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:52 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:52 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:52 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:52 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:53 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:53 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:53 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:53 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:53 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:53 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:53 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:55 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:55 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:55 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:55 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:55 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:55 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:55 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:55 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:55 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:56 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:56 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:56 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:56 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:56 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:56 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:56 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:56 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:56 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:57 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:57 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:57 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:57 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:57 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:57 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:57 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:57 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:57 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:58 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:58 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:58 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:58 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:58 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:58 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:58 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:58 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:58 --> Language Class Initialized
DEBUG - 2014-03-07 00:45:59 --> Config Class Initialized
DEBUG - 2014-03-07 00:45:59 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:45:59 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:45:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:45:59 --> URI Class Initialized
DEBUG - 2014-03-07 00:45:59 --> Router Class Initialized
DEBUG - 2014-03-07 00:45:59 --> Output Class Initialized
DEBUG - 2014-03-07 00:45:59 --> Security Class Initialized
DEBUG - 2014-03-07 00:45:59 --> Input Class Initialized
DEBUG - 2014-03-07 00:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:45:59 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:00 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:00 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:00 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:00 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:00 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:00 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:00 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:00 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:01 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:02 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:02 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:02 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:02 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:02 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:02 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:02 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:02 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:02 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:03 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:03 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:03 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:03 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:03 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:03 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:03 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:03 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:03 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:04 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:04 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:04 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:04 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:04 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:04 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:04 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:04 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:04 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:05 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:05 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:05 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:05 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:05 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:05 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:05 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:05 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:05 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:06 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:06 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:06 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:06 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:06 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:06 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:06 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:06 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:06 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:07 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:07 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:07 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:07 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:07 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:07 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:07 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:07 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:07 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:08 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:08 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:08 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:08 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:08 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:08 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:08 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:08 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:08 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:09 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:09 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:09 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:09 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:09 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:09 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:09 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:10 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:10 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:10 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:10 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:10 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:10 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:10 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:10 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:10 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:11 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:11 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:11 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:11 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:11 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:11 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:11 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:12 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:12 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:12 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:12 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:12 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:13 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:13 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:14 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:14 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:14 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:14 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:14 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:14 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:14 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:15 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:15 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:15 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:15 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:15 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:15 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:15 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:15 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:15 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:16 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:16 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:16 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:16 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:16 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:16 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:16 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:16 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:16 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:17 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:17 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:17 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:17 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:17 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:17 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:17 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:17 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:17 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:18 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:18 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:18 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:18 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:18 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:18 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:18 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:18 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:18 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:19 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:19 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:19 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:19 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:19 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:19 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:19 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:19 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:19 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:20 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:20 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:20 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:20 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:20 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:20 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:20 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:20 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:20 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:21 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:21 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:21 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:21 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:21 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:21 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:21 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:21 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:21 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:22 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:22 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:22 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:22 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:22 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:22 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:22 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:22 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:22 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:24 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:24 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:24 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:24 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:24 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:24 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:24 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:24 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:24 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:25 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:25 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:25 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:25 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:25 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:25 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:25 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:26 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:26 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:26 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:26 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:26 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:26 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:26 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:26 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:26 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:27 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:27 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:27 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:27 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:27 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:27 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:27 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:27 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:27 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:28 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:28 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:28 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:28 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:28 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:28 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:28 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:29 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:29 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:29 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:29 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:29 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:29 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:29 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:29 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:29 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:30 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:30 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:30 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:30 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:30 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:30 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:30 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:31 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:31 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:31 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:31 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:31 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:31 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:31 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:32 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:32 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:32 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:32 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:32 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:32 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:32 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:33 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:33 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:34 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:34 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:34 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:34 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:34 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:34 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:35 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:35 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:35 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:35 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:35 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:35 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:35 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:35 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:35 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:36 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:36 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:36 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:36 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:36 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:36 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:36 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:36 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:36 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:37 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:37 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:37 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:37 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:37 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:37 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:37 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:37 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:37 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:38 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:38 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:38 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:38 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:38 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:38 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:38 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:39 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:39 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:39 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:39 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:39 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:39 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:39 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:40 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:40 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:40 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:40 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:40 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:40 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:40 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:40 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:40 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:41 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:41 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:41 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:41 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:41 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:41 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:42 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:43 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:43 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:43 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:43 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:43 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:43 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:43 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:44 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:44 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:44 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:44 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:44 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:44 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:44 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:44 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:44 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:45 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:45 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:45 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:45 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:45 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:45 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:45 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:45 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:45 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:46 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:46 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:46 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:46 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:46 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:46 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:46 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:46 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:46 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:47 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:47 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:47 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:47 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:47 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:47 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:47 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:48 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:48 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:48 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:48 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:48 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:48 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:48 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:48 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:48 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:49 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:49 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:49 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:49 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:49 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:49 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:49 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:49 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:49 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:51 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:51 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:51 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:51 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:51 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:51 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:51 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:51 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:51 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:52 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:52 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:52 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:52 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:52 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:52 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:52 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:52 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:52 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:53 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:53 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:53 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:53 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:53 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:53 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:53 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:54 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:54 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:54 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:54 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:54 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:54 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:54 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:55 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:55 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:55 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:55 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:55 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:55 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:55 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:55 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:55 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:56 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:56 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:56 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:56 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:56 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:56 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:56 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:56 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:56 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:57 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:57 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:57 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:57 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:57 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:57 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:57 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:57 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:57 --> Language Class Initialized
DEBUG - 2014-03-07 00:46:58 --> Config Class Initialized
DEBUG - 2014-03-07 00:46:58 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:46:58 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:46:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:46:58 --> URI Class Initialized
DEBUG - 2014-03-07 00:46:58 --> Router Class Initialized
DEBUG - 2014-03-07 00:46:58 --> Output Class Initialized
DEBUG - 2014-03-07 00:46:58 --> Security Class Initialized
DEBUG - 2014-03-07 00:46:58 --> Input Class Initialized
DEBUG - 2014-03-07 00:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:46:59 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:00 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:00 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:00 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:00 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:00 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:00 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:00 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:00 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:00 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:01 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:01 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:01 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:01 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:01 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:01 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:01 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:02 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:02 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:02 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:02 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:02 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:02 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:02 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:02 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:02 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:03 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:03 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:03 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:03 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:03 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:03 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:03 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:03 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:03 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:04 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:04 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:04 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:04 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:04 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:04 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:04 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:04 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:04 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:05 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:05 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:05 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:05 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:05 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:05 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:05 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:05 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:05 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:06 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:06 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:06 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:06 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:06 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:06 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:06 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:06 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:06 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:07 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:07 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:07 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:07 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:07 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:07 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:07 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:07 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:07 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:08 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:08 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:08 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:08 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:08 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:08 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:08 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:08 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:09 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:10 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:10 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:10 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:10 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:10 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:10 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:10 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:10 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:10 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:11 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:11 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:11 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:11 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:11 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:11 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:11 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:12 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:12 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:12 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:12 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:12 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:12 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:12 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:13 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:13 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:13 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:13 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:13 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:13 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:13 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:13 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:13 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:14 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:14 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:14 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:14 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:14 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:14 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:14 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:15 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:15 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:15 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:15 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:15 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:15 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:15 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:15 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:15 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:15 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:15 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:15 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:15 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:15 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:15 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:15 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:15 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:16 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:16 --> Loader Class Initialized
DEBUG - 2014-03-07 00:47:16 --> Database Driver Class Initialized
ERROR - 2014-03-07 00:47:16 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\www\nas\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-03-07 00:47:17 --> Session Class Initialized
DEBUG - 2014-03-07 00:47:17 --> Helper loaded: string_helper
DEBUG - 2014-03-07 00:47:17 --> Session routines successfully run
DEBUG - 2014-03-07 00:47:17 --> XML-RPC Class Initialized
DEBUG - 2014-03-07 00:47:17 --> User Agent Class Initialized
DEBUG - 2014-03-07 00:47:17 --> Controller Class Initialized
DEBUG - 2014-03-07 00:47:17 --> Helper loaded: url_helper
DEBUG - 2014-03-07 08:47:17 --> File loaded: application/views/logView.php
DEBUG - 2014-03-07 08:47:17 --> Final output sent to browser
DEBUG - 2014-03-07 08:47:17 --> Total execution time: 1.3092
DEBUG - 2014-03-07 00:47:17 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:17 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:17 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:17 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:17 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:17 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:17 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:17 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:17 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:18 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:18 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:18 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:18 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:18 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:18 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:18 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:18 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:18 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:19 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:19 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:19 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:19 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:19 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:19 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:19 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:19 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:19 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:20 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:20 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:20 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:20 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:20 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:20 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:20 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:20 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:20 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:21 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:21 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:21 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:21 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:21 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:21 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:21 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:21 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:21 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:22 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:22 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:22 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:22 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:22 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:22 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:22 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:22 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:22 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:23 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:23 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:23 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:23 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:23 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:24 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:24 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:24 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:24 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:25 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:25 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:25 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:25 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:25 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:25 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:25 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:26 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:26 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:26 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:26 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:26 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:26 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:26 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:26 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:26 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:27 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:27 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:27 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:27 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:27 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:27 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:27 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:27 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:27 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:28 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:28 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:28 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:28 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:28 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:28 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:28 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:29 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:29 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:29 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:29 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:29 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:29 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:29 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:29 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:29 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:31 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:31 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:31 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:31 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:31 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:31 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:31 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:32 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:32 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:32 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:32 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:32 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:32 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:32 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:33 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:33 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:33 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:33 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:33 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:33 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:33 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:33 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:33 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:34 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:34 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:34 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:34 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:34 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:34 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:34 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:35 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:35 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:35 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:35 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:35 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:35 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:35 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:35 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:36 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:37 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:37 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:37 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:37 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:37 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:37 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:37 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:37 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:37 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:38 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:38 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:38 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:38 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:38 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:38 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:38 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:39 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:39 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:39 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:39 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:39 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:39 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:39 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:40 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:40 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:40 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:40 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:40 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:40 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:40 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:40 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:40 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:41 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:41 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:41 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:41 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:41 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:41 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:41 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:42 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:42 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:42 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:43 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:43 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:43 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:43 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:43 --> Config Class Initialized
DEBUG - 2014-03-07 00:47:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:47:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:47:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:47:43 --> URI Class Initialized
DEBUG - 2014-03-07 00:47:43 --> Router Class Initialized
DEBUG - 2014-03-07 00:47:43 --> Output Class Initialized
DEBUG - 2014-03-07 00:47:43 --> Security Class Initialized
DEBUG - 2014-03-07 00:47:43 --> Input Class Initialized
DEBUG - 2014-03-07 00:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:47:43 --> Language Class Initialized
DEBUG - 2014-03-07 00:47:43 --> Loader Class Initialized
DEBUG - 2014-03-07 00:47:44 --> Database Driver Class Initialized
DEBUG - 2014-03-07 00:47:44 --> Session Class Initialized
DEBUG - 2014-03-07 00:47:44 --> Helper loaded: string_helper
DEBUG - 2014-03-07 00:47:44 --> Session routines successfully run
DEBUG - 2014-03-07 00:47:44 --> XML-RPC Class Initialized
DEBUG - 2014-03-07 00:47:44 --> User Agent Class Initialized
DEBUG - 2014-03-07 00:47:44 --> Controller Class Initialized
DEBUG - 2014-03-07 00:47:44 --> Helper loaded: url_helper
DEBUG - 2014-03-07 00:47:44 --> Model Class Initialized
DEBUG - 2014-03-07 08:47:44 --> [{"id":"1","name":"\u738b\u8cb4\u6c11"},{"id":"2","name":"\u5f35\u5609\u9298"},{"id":"3","name":"\u6d2a\u6e05\u6587"},{"id":"4","name":"\u9673\u4ec1\u7965"},{"id":"5","name":"\u8449\u671f\u8ca1"},{"id":"6","name":"\u9805\u52e4\u6821"},{"id":"7","name":"\u5f35\u826f\u653f"},{"id":"8","name":"\u97d3\u6167\u6797"},{"id":"9","name":"\u7f85\u5efa\u9298"},{"id":"10","name":"\u6881\u514b\u65b0"},{"id":"11","name":"\u6d2a\u570b\u8208"}]
DEBUG - 2014-03-07 08:47:44 --> Final output sent to browser
DEBUG - 2014-03-07 08:47:44 --> Total execution time: 0.7689
DEBUG - 2014-03-07 00:49:25 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:25 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:25 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:25 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:25 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:25 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:26 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:26 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:26 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:26 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:26 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:26 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:26 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:26 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:26 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:26 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:26 --> Loader Class Initialized
DEBUG - 2014-03-07 00:49:26 --> Database Driver Class Initialized
DEBUG - 2014-03-07 00:49:27 --> Session Class Initialized
DEBUG - 2014-03-07 00:49:27 --> Helper loaded: string_helper
DEBUG - 2014-03-07 00:49:27 --> Session routines successfully run
DEBUG - 2014-03-07 00:49:27 --> XML-RPC Class Initialized
DEBUG - 2014-03-07 00:49:27 --> User Agent Class Initialized
DEBUG - 2014-03-07 00:49:27 --> Controller Class Initialized
DEBUG - 2014-03-07 00:49:27 --> Helper loaded: url_helper
DEBUG - 2014-03-07 08:49:27 --> File loaded: application/views/logView.php
DEBUG - 2014-03-07 08:49:27 --> Final output sent to browser
DEBUG - 2014-03-07 08:49:27 --> Total execution time: 0.4733
DEBUG - 2014-03-07 00:49:27 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:27 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:27 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:27 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:27 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:27 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:27 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:27 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:27 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:28 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:28 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:28 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:28 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:28 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:28 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:28 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:29 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:29 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:29 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:29 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:29 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:29 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:29 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:29 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:29 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:30 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:30 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:31 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:31 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:31 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:31 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:31 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:32 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:32 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:32 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:32 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:32 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:32 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:32 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:33 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:33 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:33 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:33 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:33 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:33 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:33 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:33 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:33 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:34 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:34 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:34 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:34 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:34 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:34 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:34 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:34 --> Loader Class Initialized
DEBUG - 2014-03-07 00:49:35 --> Database Driver Class Initialized
DEBUG - 2014-03-07 00:49:35 --> Session Class Initialized
DEBUG - 2014-03-07 00:49:35 --> Helper loaded: string_helper
DEBUG - 2014-03-07 00:49:35 --> Session routines successfully run
DEBUG - 2014-03-07 00:49:35 --> XML-RPC Class Initialized
DEBUG - 2014-03-07 00:49:35 --> User Agent Class Initialized
DEBUG - 2014-03-07 00:49:35 --> Controller Class Initialized
DEBUG - 2014-03-07 00:49:35 --> Helper loaded: url_helper
DEBUG - 2014-03-07 00:49:35 --> Model Class Initialized
DEBUG - 2014-03-07 08:49:35 --> [{"id":"1","name":"\u738b\u8cb4\u6c11"},{"id":"2","name":"\u5f35\u5609\u9298"},{"id":"3","name":"\u6d2a\u6e05\u6587"},{"id":"4","name":"\u9673\u4ec1\u7965"},{"id":"5","name":"\u8449\u671f\u8ca1"},{"id":"6","name":"\u9805\u52e4\u6821"},{"id":"7","name":"\u5f35\u826f\u653f"},{"id":"8","name":"\u97d3\u6167\u6797"},{"id":"9","name":"\u7f85\u5efa\u9298"},{"id":"10","name":"\u6881\u514b\u65b0"},{"id":"11","name":"\u6d2a\u570b\u8208"}]
DEBUG - 2014-03-07 08:49:35 --> Final output sent to browser
DEBUG - 2014-03-07 08:49:35 --> Total execution time: 0.5306
DEBUG - 2014-03-07 00:49:37 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:37 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:37 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:37 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:37 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:37 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:37 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:37 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:37 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:38 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:38 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:38 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:38 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:38 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:38 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:38 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:39 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:39 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:39 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:39 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:39 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:39 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:39 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:40 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:40 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:40 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:40 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:40 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:40 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:40 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:40 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:40 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:41 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:41 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:41 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:41 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:41 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:41 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:41 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:42 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:43 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:43 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:43 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:43 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:43 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:43 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:44 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:44 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:44 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:44 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:44 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:44 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:44 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:44 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:44 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:46 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:46 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:46 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:46 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:46 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:46 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:46 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:47 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:47 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:48 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:48 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:48 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:48 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:48 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:48 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:48 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:48 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:48 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:49 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:49 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:49 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:49 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:49 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:49 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:49 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:49 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:49 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:50 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:50 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:50 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:50 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:50 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:50 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:50 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:50 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:50 --> Language Class Initialized
DEBUG - 2014-03-07 00:49:50 --> Loader Class Initialized
DEBUG - 2014-03-07 00:49:50 --> Database Driver Class Initialized
DEBUG - 2014-03-07 00:49:50 --> Session Class Initialized
DEBUG - 2014-03-07 00:49:50 --> Helper loaded: string_helper
DEBUG - 2014-03-07 00:49:50 --> Session routines successfully run
DEBUG - 2014-03-07 00:49:50 --> XML-RPC Class Initialized
DEBUG - 2014-03-07 00:49:51 --> User Agent Class Initialized
DEBUG - 2014-03-07 00:49:51 --> Controller Class Initialized
DEBUG - 2014-03-07 00:49:51 --> Helper loaded: url_helper
DEBUG - 2014-03-07 00:49:51 --> Model Class Initialized
DEBUG - 2014-03-07 08:49:51 --> [{"id":"1","name":"\u738b\u8cb4\u6c11"},{"id":"2","name":"\u5f35\u5609\u9298"},{"id":"3","name":"\u6d2a\u6e05\u6587"},{"id":"4","name":"\u9673\u4ec1\u7965"},{"id":"5","name":"\u8449\u671f\u8ca1"},{"id":"6","name":"\u9805\u52e4\u6821"},{"id":"7","name":"\u5f35\u826f\u653f"},{"id":"8","name":"\u97d3\u6167\u6797"},{"id":"9","name":"\u7f85\u5efa\u9298"},{"id":"10","name":"\u6881\u514b\u65b0"},{"id":"11","name":"\u6d2a\u570b\u8208"}]
DEBUG - 2014-03-07 08:49:51 --> Final output sent to browser
DEBUG - 2014-03-07 08:49:51 --> Total execution time: 0.6548
DEBUG - 2014-03-07 00:49:55 --> Config Class Initialized
DEBUG - 2014-03-07 00:49:55 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:49:55 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:49:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:49:56 --> URI Class Initialized
DEBUG - 2014-03-07 00:49:56 --> Router Class Initialized
DEBUG - 2014-03-07 00:49:56 --> Output Class Initialized
DEBUG - 2014-03-07 00:49:56 --> Security Class Initialized
DEBUG - 2014-03-07 00:49:56 --> Input Class Initialized
DEBUG - 2014-03-07 00:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:49:56 --> Language Class Initialized
DEBUG - 2014-03-07 00:55:38 --> Config Class Initialized
DEBUG - 2014-03-07 00:55:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:55:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:55:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:55:38 --> URI Class Initialized
DEBUG - 2014-03-07 00:55:38 --> Router Class Initialized
DEBUG - 2014-03-07 00:55:38 --> Output Class Initialized
DEBUG - 2014-03-07 00:55:38 --> Security Class Initialized
DEBUG - 2014-03-07 00:55:38 --> Input Class Initialized
DEBUG - 2014-03-07 00:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:55:38 --> Language Class Initialized
DEBUG - 2014-03-07 00:55:38 --> Loader Class Initialized
DEBUG - 2014-03-07 00:55:38 --> Database Driver Class Initialized
ERROR - 2014-03-07 00:55:38 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\www\nas\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-03-07 00:55:39 --> Session Class Initialized
DEBUG - 2014-03-07 00:55:39 --> Helper loaded: string_helper
DEBUG - 2014-03-07 00:55:39 --> Session routines successfully run
DEBUG - 2014-03-07 00:55:39 --> XML-RPC Class Initialized
DEBUG - 2014-03-07 00:55:39 --> User Agent Class Initialized
DEBUG - 2014-03-07 00:55:39 --> Controller Class Initialized
DEBUG - 2014-03-07 00:55:39 --> Helper loaded: url_helper
DEBUG - 2014-03-07 00:55:46 --> Config Class Initialized
DEBUG - 2014-03-07 00:55:46 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:55:46 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:55:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:55:46 --> URI Class Initialized
DEBUG - 2014-03-07 00:55:46 --> Router Class Initialized
DEBUG - 2014-03-07 00:55:46 --> Output Class Initialized
DEBUG - 2014-03-07 00:55:46 --> Security Class Initialized
DEBUG - 2014-03-07 00:55:46 --> Input Class Initialized
DEBUG - 2014-03-07 00:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:55:46 --> Language Class Initialized
DEBUG - 2014-03-07 00:55:46 --> Loader Class Initialized
DEBUG - 2014-03-07 00:55:46 --> Database Driver Class Initialized
DEBUG - 2014-03-07 00:55:46 --> Session Class Initialized
DEBUG - 2014-03-07 00:55:46 --> Helper loaded: string_helper
DEBUG - 2014-03-07 00:55:46 --> Session routines successfully run
DEBUG - 2014-03-07 00:55:46 --> XML-RPC Class Initialized
DEBUG - 2014-03-07 00:55:47 --> User Agent Class Initialized
DEBUG - 2014-03-07 00:55:47 --> Controller Class Initialized
DEBUG - 2014-03-07 00:55:47 --> Helper loaded: url_helper
DEBUG - 2014-03-07 00:56:34 --> Config Class Initialized
DEBUG - 2014-03-07 00:56:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:56:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:56:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:56:34 --> URI Class Initialized
DEBUG - 2014-03-07 00:56:34 --> Router Class Initialized
DEBUG - 2014-03-07 00:56:34 --> No URI present. Default controller set.
DEBUG - 2014-03-07 00:56:34 --> Output Class Initialized
DEBUG - 2014-03-07 00:56:34 --> Security Class Initialized
DEBUG - 2014-03-07 00:56:34 --> Input Class Initialized
DEBUG - 2014-03-07 00:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:56:34 --> Language Class Initialized
DEBUG - 2014-03-07 00:56:34 --> Loader Class Initialized
DEBUG - 2014-03-07 00:56:34 --> Database Driver Class Initialized
ERROR - 2014-03-07 00:56:34 --> Severity: Notice  --> mysql_pconnect():  C:\wamp\www\nas\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2014-03-07 00:56:35 --> Session Class Initialized
DEBUG - 2014-03-07 00:56:35 --> Helper loaded: string_helper
DEBUG - 2014-03-07 00:56:35 --> Session routines successfully run
DEBUG - 2014-03-07 00:56:35 --> XML-RPC Class Initialized
DEBUG - 2014-03-07 00:56:35 --> User Agent Class Initialized
DEBUG - 2014-03-07 00:56:35 --> Controller Class Initialized
DEBUG - 2014-03-07 00:56:35 --> Helper loaded: url_helper
DEBUG - 2014-03-07 00:56:35 --> this->setMessage()
DEBUG - 2014-03-07 08:56:35 --> File loaded: application/views/query.php
DEBUG - 2014-03-07 08:56:35 --> File loaded: application/views/master.php
DEBUG - 2014-03-07 08:56:35 --> Final output sent to browser
DEBUG - 2014-03-07 08:56:35 --> Total execution time: 1.2054
DEBUG - 2014-03-07 00:56:37 --> Config Class Initialized
DEBUG - 2014-03-07 00:56:37 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:56:37 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:56:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:56:37 --> URI Class Initialized
DEBUG - 2014-03-07 00:56:37 --> Router Class Initialized
DEBUG - 2014-03-07 00:56:37 --> Output Class Initialized
DEBUG - 2014-03-07 00:56:37 --> Security Class Initialized
DEBUG - 2014-03-07 00:56:37 --> Input Class Initialized
DEBUG - 2014-03-07 00:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:56:37 --> Language Class Initialized
DEBUG - 2014-03-07 00:56:37 --> Loader Class Initialized
DEBUG - 2014-03-07 00:56:37 --> Database Driver Class Initialized
DEBUG - 2014-03-07 00:56:37 --> Session Class Initialized
DEBUG - 2014-03-07 00:56:37 --> Helper loaded: string_helper
DEBUG - 2014-03-07 00:56:37 --> Session routines successfully run
DEBUG - 2014-03-07 00:56:37 --> XML-RPC Class Initialized
DEBUG - 2014-03-07 00:56:37 --> User Agent Class Initialized
DEBUG - 2014-03-07 00:56:37 --> Controller Class Initialized
DEBUG - 2014-03-07 00:56:37 --> Helper loaded: url_helper
DEBUG - 2014-03-07 00:57:06 --> Config Class Initialized
DEBUG - 2014-03-07 00:57:06 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:57:06 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:57:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:57:06 --> URI Class Initialized
DEBUG - 2014-03-07 00:57:06 --> Router Class Initialized
DEBUG - 2014-03-07 00:57:07 --> Output Class Initialized
DEBUG - 2014-03-07 00:57:07 --> Security Class Initialized
DEBUG - 2014-03-07 00:57:07 --> Input Class Initialized
DEBUG - 2014-03-07 00:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:57:07 --> Language Class Initialized
DEBUG - 2014-03-07 00:57:07 --> Loader Class Initialized
DEBUG - 2014-03-07 00:57:07 --> Database Driver Class Initialized
DEBUG - 2014-03-07 00:57:07 --> Session Class Initialized
DEBUG - 2014-03-07 00:57:07 --> Helper loaded: string_helper
DEBUG - 2014-03-07 00:57:07 --> Session routines successfully run
DEBUG - 2014-03-07 00:57:07 --> XML-RPC Class Initialized
DEBUG - 2014-03-07 00:57:07 --> User Agent Class Initialized
DEBUG - 2014-03-07 00:57:07 --> Controller Class Initialized
DEBUG - 2014-03-07 00:57:07 --> Helper loaded: url_helper
DEBUG - 2014-03-07 08:57:07 --> Model Class Initialized
DEBUG - 2014-03-07 08:57:07 --> Final output sent to browser
DEBUG - 2014-03-07 08:57:07 --> Total execution time: 0.5479
DEBUG - 2014-03-07 00:57:08 --> Config Class Initialized
DEBUG - 2014-03-07 00:57:08 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:57:08 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:57:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:57:08 --> URI Class Initialized
DEBUG - 2014-03-07 00:57:08 --> Router Class Initialized
DEBUG - 2014-03-07 00:57:08 --> Output Class Initialized
DEBUG - 2014-03-07 00:57:08 --> Security Class Initialized
DEBUG - 2014-03-07 00:57:08 --> Input Class Initialized
DEBUG - 2014-03-07 00:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:57:08 --> Language Class Initialized
DEBUG - 2014-03-07 00:57:08 --> Loader Class Initialized
DEBUG - 2014-03-07 00:57:08 --> Database Driver Class Initialized
DEBUG - 2014-03-07 00:57:08 --> Session Class Initialized
DEBUG - 2014-03-07 00:57:08 --> Helper loaded: string_helper
DEBUG - 2014-03-07 00:57:08 --> Session routines successfully run
DEBUG - 2014-03-07 00:57:08 --> XML-RPC Class Initialized
DEBUG - 2014-03-07 00:57:08 --> User Agent Class Initialized
DEBUG - 2014-03-07 00:57:08 --> Controller Class Initialized
DEBUG - 2014-03-07 00:57:08 --> Helper loaded: url_helper
DEBUG - 2014-03-07 00:57:26 --> Config Class Initialized
DEBUG - 2014-03-07 00:57:26 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:57:26 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:57:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:57:26 --> URI Class Initialized
DEBUG - 2014-03-07 00:57:26 --> Router Class Initialized
DEBUG - 2014-03-07 00:57:26 --> Output Class Initialized
DEBUG - 2014-03-07 00:57:26 --> Security Class Initialized
DEBUG - 2014-03-07 00:57:26 --> Input Class Initialized
DEBUG - 2014-03-07 00:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:57:26 --> Language Class Initialized
DEBUG - 2014-03-07 00:57:26 --> Loader Class Initialized
DEBUG - 2014-03-07 00:57:27 --> Database Driver Class Initialized
DEBUG - 2014-03-07 00:57:27 --> Session Class Initialized
DEBUG - 2014-03-07 00:57:27 --> Helper loaded: string_helper
DEBUG - 2014-03-07 00:57:27 --> Session routines successfully run
DEBUG - 2014-03-07 00:57:27 --> XML-RPC Class Initialized
DEBUG - 2014-03-07 00:57:27 --> User Agent Class Initialized
DEBUG - 2014-03-07 00:57:27 --> Controller Class Initialized
DEBUG - 2014-03-07 00:57:27 --> Helper loaded: url_helper
DEBUG - 2014-03-07 08:57:27 --> Model Class Initialized
DEBUG - 2014-03-07 08:57:27 --> Final output sent to browser
DEBUG - 2014-03-07 08:57:27 --> Total execution time: 0.3313
DEBUG - 2014-03-07 00:57:29 --> Config Class Initialized
DEBUG - 2014-03-07 00:57:29 --> Hooks Class Initialized
DEBUG - 2014-03-07 00:57:29 --> Utf8 Class Initialized
DEBUG - 2014-03-07 00:57:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 00:57:29 --> URI Class Initialized
DEBUG - 2014-03-07 00:57:29 --> Router Class Initialized
DEBUG - 2014-03-07 00:57:29 --> Output Class Initialized
DEBUG - 2014-03-07 00:57:29 --> Security Class Initialized
DEBUG - 2014-03-07 00:57:29 --> Input Class Initialized
DEBUG - 2014-03-07 00:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 00:57:29 --> Language Class Initialized
DEBUG - 2014-03-07 00:57:29 --> Loader Class Initialized
DEBUG - 2014-03-07 00:57:29 --> Database Driver Class Initialized
DEBUG - 2014-03-07 00:57:29 --> Session Class Initialized
DEBUG - 2014-03-07 00:57:29 --> Helper loaded: string_helper
DEBUG - 2014-03-07 00:57:29 --> Session routines successfully run
DEBUG - 2014-03-07 00:57:29 --> XML-RPC Class Initialized
DEBUG - 2014-03-07 00:57:29 --> User Agent Class Initialized
DEBUG - 2014-03-07 00:57:29 --> Controller Class Initialized
DEBUG - 2014-03-07 00:57:29 --> Helper loaded: url_helper
