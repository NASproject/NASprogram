<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-03-04 01:46:32 --> Config Class Initialized
DEBUG - 2014-03-04 01:46:32 --> Hooks Class Initialized
DEBUG - 2014-03-04 01:46:32 --> Utf8 Class Initialized
DEBUG - 2014-03-04 01:46:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 01:46:33 --> URI Class Initialized
DEBUG - 2014-03-04 01:46:33 --> Router Class Initialized
DEBUG - 2014-03-04 01:46:33 --> No URI present. Default controller set.
DEBUG - 2014-03-04 01:46:33 --> Output Class Initialized
DEBUG - 2014-03-04 01:46:33 --> Security Class Initialized
DEBUG - 2014-03-04 01:46:33 --> Input Class Initialized
DEBUG - 2014-03-04 01:46:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 01:46:33 --> Language Class Initialized
DEBUG - 2014-03-04 01:46:34 --> Loader Class Initialized
DEBUG - 2014-03-04 01:46:34 --> Database Driver Class Initialized
DEBUG - 2014-03-04 01:46:35 --> Session Class Initialized
DEBUG - 2014-03-04 01:46:35 --> Helper loaded: string_helper
DEBUG - 2014-03-04 01:46:35 --> A session cookie was not found.
DEBUG - 2014-03-04 01:46:35 --> Session routines successfully run
DEBUG - 2014-03-04 01:46:36 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 01:46:36 --> User Agent Class Initialized
DEBUG - 2014-03-04 01:46:36 --> Controller Class Initialized
DEBUG - 2014-03-04 01:46:36 --> this->setMessage()
DEBUG - 2014-03-04 01:51:28 --> Config Class Initialized
DEBUG - 2014-03-04 01:51:28 --> Hooks Class Initialized
DEBUG - 2014-03-04 01:51:28 --> Utf8 Class Initialized
DEBUG - 2014-03-04 01:51:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 01:51:28 --> URI Class Initialized
DEBUG - 2014-03-04 01:51:28 --> Router Class Initialized
DEBUG - 2014-03-04 01:51:28 --> No URI present. Default controller set.
DEBUG - 2014-03-04 01:51:28 --> Output Class Initialized
DEBUG - 2014-03-04 01:51:28 --> Security Class Initialized
DEBUG - 2014-03-04 01:51:28 --> Input Class Initialized
DEBUG - 2014-03-04 01:51:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 01:51:28 --> Language Class Initialized
DEBUG - 2014-03-04 01:51:28 --> Loader Class Initialized
DEBUG - 2014-03-04 01:51:28 --> Database Driver Class Initialized
DEBUG - 2014-03-04 01:51:28 --> Session Class Initialized
DEBUG - 2014-03-04 01:51:28 --> Helper loaded: string_helper
DEBUG - 2014-03-04 01:51:28 --> Session routines successfully run
DEBUG - 2014-03-04 01:51:28 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 01:51:28 --> User Agent Class Initialized
DEBUG - 2014-03-04 01:51:28 --> Controller Class Initialized
DEBUG - 2014-03-04 01:51:28 --> this->setMessage()
DEBUG - 2014-03-04 01:51:28 --> this->setMessage()
DEBUG - 2014-03-04 01:51:29 --> File loaded: application/views/master.php
DEBUG - 2014-03-04 01:51:29 --> Final output sent to browser
DEBUG - 2014-03-04 01:51:29 --> Total execution time: 1.0329
DEBUG - 2014-03-04 01:55:22 --> Config Class Initialized
DEBUG - 2014-03-04 01:55:22 --> Hooks Class Initialized
DEBUG - 2014-03-04 01:55:22 --> Utf8 Class Initialized
DEBUG - 2014-03-04 01:55:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 01:55:22 --> URI Class Initialized
DEBUG - 2014-03-04 01:55:22 --> Router Class Initialized
DEBUG - 2014-03-04 01:55:22 --> No URI present. Default controller set.
DEBUG - 2014-03-04 01:55:23 --> Output Class Initialized
DEBUG - 2014-03-04 01:55:23 --> Security Class Initialized
DEBUG - 2014-03-04 01:55:23 --> Input Class Initialized
DEBUG - 2014-03-04 01:55:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 01:55:23 --> Language Class Initialized
DEBUG - 2014-03-04 01:55:23 --> Loader Class Initialized
DEBUG - 2014-03-04 01:55:24 --> Database Driver Class Initialized
DEBUG - 2014-03-04 01:55:25 --> Session Class Initialized
DEBUG - 2014-03-04 01:55:25 --> Helper loaded: string_helper
DEBUG - 2014-03-04 01:55:25 --> Session routines successfully run
DEBUG - 2014-03-04 01:55:25 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 01:55:25 --> User Agent Class Initialized
DEBUG - 2014-03-04 01:55:25 --> Controller Class Initialized
DEBUG - 2014-03-04 01:55:25 --> this->setMessage()
DEBUG - 2014-03-04 01:55:26 --> this->setMessage()
DEBUG - 2014-03-04 01:55:26 --> File loaded: application/views/master.php
DEBUG - 2014-03-04 01:55:26 --> Final output sent to browser
DEBUG - 2014-03-04 01:55:26 --> Total execution time: 4.4681
DEBUG - 2014-03-04 01:58:34 --> Config Class Initialized
DEBUG - 2014-03-04 01:58:34 --> Hooks Class Initialized
DEBUG - 2014-03-04 01:58:34 --> Utf8 Class Initialized
DEBUG - 2014-03-04 01:58:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 01:58:34 --> URI Class Initialized
DEBUG - 2014-03-04 01:58:34 --> Router Class Initialized
DEBUG - 2014-03-04 01:58:34 --> No URI present. Default controller set.
DEBUG - 2014-03-04 01:58:35 --> Output Class Initialized
DEBUG - 2014-03-04 01:58:35 --> Security Class Initialized
DEBUG - 2014-03-04 01:58:35 --> Input Class Initialized
DEBUG - 2014-03-04 01:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 01:58:35 --> Language Class Initialized
DEBUG - 2014-03-04 01:58:35 --> Loader Class Initialized
DEBUG - 2014-03-04 01:58:35 --> Database Driver Class Initialized
DEBUG - 2014-03-04 01:58:35 --> Session Class Initialized
DEBUG - 2014-03-04 01:58:35 --> Helper loaded: string_helper
DEBUG - 2014-03-04 01:58:36 --> Session routines successfully run
DEBUG - 2014-03-04 01:58:36 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 01:58:36 --> User Agent Class Initialized
DEBUG - 2014-03-04 01:58:36 --> Controller Class Initialized
DEBUG - 2014-03-04 01:58:36 --> this->setMessage()
DEBUG - 2014-03-04 01:58:36 --> this->setMessage()
DEBUG - 2014-03-04 01:58:36 --> File loaded: application/views/master.php
DEBUG - 2014-03-04 01:58:36 --> Final output sent to browser
DEBUG - 2014-03-04 01:58:37 --> Total execution time: 2.6959
DEBUG - 2014-03-04 02:29:57 --> Config Class Initialized
DEBUG - 2014-03-04 02:29:57 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:29:58 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:29:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:29:58 --> URI Class Initialized
DEBUG - 2014-03-04 02:29:58 --> Router Class Initialized
DEBUG - 2014-03-04 02:29:58 --> No URI present. Default controller set.
DEBUG - 2014-03-04 02:29:58 --> Output Class Initialized
DEBUG - 2014-03-04 02:29:58 --> Security Class Initialized
DEBUG - 2014-03-04 02:29:58 --> Input Class Initialized
DEBUG - 2014-03-04 02:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:29:59 --> Language Class Initialized
DEBUG - 2014-03-04 02:29:59 --> Loader Class Initialized
DEBUG - 2014-03-04 02:29:59 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:29:59 --> Session Class Initialized
DEBUG - 2014-03-04 02:29:59 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:29:59 --> Session routines successfully run
DEBUG - 2014-03-04 02:29:59 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:30:00 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:30:00 --> Controller Class Initialized
DEBUG - 2014-03-04 02:30:00 --> this->setMessage()
DEBUG - 2014-03-04 02:30:00 --> this->setMessage()
DEBUG - 2014-03-04 02:30:00 --> File loaded: application/views/master.php
DEBUG - 2014-03-04 02:30:00 --> Final output sent to browser
DEBUG - 2014-03-04 02:30:00 --> Total execution time: 2.6876
DEBUG - 2014-03-04 02:35:03 --> Config Class Initialized
DEBUG - 2014-03-04 02:35:04 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:35:04 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:35:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:35:04 --> URI Class Initialized
DEBUG - 2014-03-04 02:35:04 --> Router Class Initialized
ERROR - 2014-03-04 02:35:04 --> 404 Page Not Found --> query
DEBUG - 2014-03-04 02:35:57 --> Config Class Initialized
DEBUG - 2014-03-04 02:35:57 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:35:57 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:35:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:35:57 --> URI Class Initialized
DEBUG - 2014-03-04 02:35:57 --> Router Class Initialized
ERROR - 2014-03-04 02:35:57 --> 404 Page Not Found --> query
DEBUG - 2014-03-04 02:36:26 --> Config Class Initialized
DEBUG - 2014-03-04 02:36:26 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:36:26 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:36:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:36:26 --> URI Class Initialized
DEBUG - 2014-03-04 02:36:26 --> Router Class Initialized
ERROR - 2014-03-04 02:36:27 --> 404 Page Not Found --> query
DEBUG - 2014-03-04 02:36:29 --> Config Class Initialized
DEBUG - 2014-03-04 02:36:29 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:36:29 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:36:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:36:29 --> URI Class Initialized
DEBUG - 2014-03-04 02:36:29 --> Router Class Initialized
ERROR - 2014-03-04 02:36:29 --> 404 Page Not Found --> query
DEBUG - 2014-03-04 02:36:44 --> Config Class Initialized
DEBUG - 2014-03-04 02:36:44 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:36:45 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:36:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:36:45 --> URI Class Initialized
DEBUG - 2014-03-04 02:36:45 --> Router Class Initialized
DEBUG - 2014-03-04 02:36:45 --> No URI present. Default controller set.
DEBUG - 2014-03-04 02:36:45 --> Output Class Initialized
DEBUG - 2014-03-04 02:36:45 --> Security Class Initialized
DEBUG - 2014-03-04 02:36:45 --> Input Class Initialized
DEBUG - 2014-03-04 02:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:36:45 --> Language Class Initialized
DEBUG - 2014-03-04 02:36:45 --> Loader Class Initialized
DEBUG - 2014-03-04 02:36:45 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:36:46 --> Session Class Initialized
DEBUG - 2014-03-04 02:36:46 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:36:46 --> Session routines successfully run
DEBUG - 2014-03-04 02:36:46 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:36:47 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:36:47 --> Controller Class Initialized
DEBUG - 2014-03-04 02:36:47 --> this->setMessage()
DEBUG - 2014-03-04 02:36:47 --> this->setMessage()
DEBUG - 2014-03-04 02:36:47 --> File loaded: application/views/master.php
DEBUG - 2014-03-04 02:36:47 --> Final output sent to browser
DEBUG - 2014-03-04 02:36:47 --> Total execution time: 2.9446
DEBUG - 2014-03-04 02:40:43 --> Config Class Initialized
DEBUG - 2014-03-04 02:40:43 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:40:43 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:40:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:40:43 --> URI Class Initialized
DEBUG - 2014-03-04 02:40:43 --> Router Class Initialized
DEBUG - 2014-03-04 02:40:43 --> Output Class Initialized
DEBUG - 2014-03-04 02:40:44 --> Security Class Initialized
DEBUG - 2014-03-04 02:40:44 --> Input Class Initialized
DEBUG - 2014-03-04 02:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:40:44 --> Language Class Initialized
DEBUG - 2014-03-04 02:40:44 --> Loader Class Initialized
DEBUG - 2014-03-04 02:40:44 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:40:44 --> Session Class Initialized
DEBUG - 2014-03-04 02:40:44 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:40:44 --> Session routines successfully run
DEBUG - 2014-03-04 02:40:44 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:40:45 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:40:45 --> Controller Class Initialized
DEBUG - 2014-03-04 02:40:45 --> this->setMessage()
DEBUG - 2014-03-04 02:40:45 --> Final output sent to browser
DEBUG - 2014-03-04 02:40:45 --> Total execution time: 1.7601
DEBUG - 2014-03-04 02:42:08 --> Config Class Initialized
DEBUG - 2014-03-04 02:42:08 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:42:08 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:42:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:42:09 --> URI Class Initialized
DEBUG - 2014-03-04 02:42:09 --> Router Class Initialized
DEBUG - 2014-03-04 02:42:09 --> Output Class Initialized
DEBUG - 2014-03-04 02:42:09 --> Security Class Initialized
DEBUG - 2014-03-04 02:42:09 --> Input Class Initialized
DEBUG - 2014-03-04 02:42:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:42:09 --> Language Class Initialized
DEBUG - 2014-03-04 02:42:09 --> Loader Class Initialized
DEBUG - 2014-03-04 02:42:09 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:42:09 --> Session Class Initialized
DEBUG - 2014-03-04 02:42:10 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:42:10 --> Session routines successfully run
DEBUG - 2014-03-04 02:42:10 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:42:10 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:42:10 --> Controller Class Initialized
DEBUG - 2014-03-04 02:42:10 --> this->setMessage()
DEBUG - 2014-03-04 02:42:10 --> File loaded: application/views/query.php
DEBUG - 2014-03-04 02:42:10 --> File loaded: application/views/master.php
DEBUG - 2014-03-04 02:42:10 --> Final output sent to browser
DEBUG - 2014-03-04 02:42:10 --> Total execution time: 1.9091
DEBUG - 2014-03-04 02:42:11 --> Config Class Initialized
DEBUG - 2014-03-04 02:42:11 --> Config Class Initialized
DEBUG - 2014-03-04 02:42:11 --> Config Class Initialized
DEBUG - 2014-03-04 02:42:11 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:42:11 --> Config Class Initialized
DEBUG - 2014-03-04 02:42:11 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:42:11 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:42:11 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:42:11 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:42:11 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:42:11 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:42:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:42:11 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:42:11 --> URI Class Initialized
DEBUG - 2014-03-04 02:42:11 --> Router Class Initialized
DEBUG - 2014-03-04 02:42:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:42:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:42:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:42:12 --> Output Class Initialized
DEBUG - 2014-03-04 02:42:12 --> URI Class Initialized
DEBUG - 2014-03-04 02:42:12 --> URI Class Initialized
DEBUG - 2014-03-04 02:42:12 --> URI Class Initialized
DEBUG - 2014-03-04 02:42:12 --> Security Class Initialized
DEBUG - 2014-03-04 02:42:12 --> Router Class Initialized
DEBUG - 2014-03-04 02:42:12 --> Router Class Initialized
DEBUG - 2014-03-04 02:42:12 --> Router Class Initialized
DEBUG - 2014-03-04 02:42:12 --> Input Class Initialized
DEBUG - 2014-03-04 02:42:12 --> Output Class Initialized
DEBUG - 2014-03-04 02:42:12 --> Security Class Initialized
DEBUG - 2014-03-04 02:42:12 --> Output Class Initialized
DEBUG - 2014-03-04 02:42:12 --> Output Class Initialized
DEBUG - 2014-03-04 02:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:42:12 --> Input Class Initialized
DEBUG - 2014-03-04 02:42:12 --> Security Class Initialized
DEBUG - 2014-03-04 02:42:12 --> Security Class Initialized
DEBUG - 2014-03-04 02:42:12 --> Language Class Initialized
DEBUG - 2014-03-04 02:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:42:13 --> Input Class Initialized
DEBUG - 2014-03-04 02:42:13 --> Input Class Initialized
DEBUG - 2014-03-04 02:42:13 --> Loader Class Initialized
DEBUG - 2014-03-04 02:42:13 --> Language Class Initialized
DEBUG - 2014-03-04 02:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:42:13 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:42:13 --> Loader Class Initialized
DEBUG - 2014-03-04 02:42:13 --> Language Class Initialized
DEBUG - 2014-03-04 02:42:13 --> Language Class Initialized
DEBUG - 2014-03-04 02:42:13 --> Session Class Initialized
DEBUG - 2014-03-04 02:42:13 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:42:13 --> Loader Class Initialized
DEBUG - 2014-03-04 02:42:13 --> Loader Class Initialized
DEBUG - 2014-03-04 02:42:13 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:42:13 --> Session Class Initialized
DEBUG - 2014-03-04 02:42:13 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:42:13 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:42:13 --> Session routines successfully run
DEBUG - 2014-03-04 02:42:13 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:42:13 --> Session Class Initialized
DEBUG - 2014-03-04 02:42:14 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:42:14 --> Session routines successfully run
DEBUG - 2014-03-04 02:42:14 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:42:14 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:42:14 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:42:14 --> Session routines successfully run
DEBUG - 2014-03-04 02:42:14 --> Controller Class Initialized
DEBUG - 2014-03-04 02:42:14 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:42:14 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:42:14 --> this->setMessage()
DEBUG - 2014-03-04 02:42:14 --> Controller Class Initialized
DEBUG - 2014-03-04 02:42:14 --> User Agent Class Initialized
ERROR - 2014-03-04 02:42:14 --> 404 Page Not Found --> welcome/public
DEBUG - 2014-03-04 02:42:14 --> this->setMessage()
DEBUG - 2014-03-04 02:42:14 --> Controller Class Initialized
DEBUG - 2014-03-04 02:42:14 --> this->setMessage()
ERROR - 2014-03-04 02:42:14 --> 404 Page Not Found --> welcome/public
ERROR - 2014-03-04 02:42:14 --> 404 Page Not Found --> welcome/public
DEBUG - 2014-03-04 02:42:14 --> Session Class Initialized
DEBUG - 2014-03-04 02:42:15 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:42:15 --> Session routines successfully run
DEBUG - 2014-03-04 02:42:15 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:42:15 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:42:15 --> Controller Class Initialized
DEBUG - 2014-03-04 02:42:15 --> this->setMessage()
ERROR - 2014-03-04 02:42:15 --> 404 Page Not Found --> welcome/public
DEBUG - 2014-03-04 02:47:29 --> Config Class Initialized
DEBUG - 2014-03-04 02:47:29 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:47:29 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:47:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:47:29 --> URI Class Initialized
DEBUG - 2014-03-04 02:47:30 --> Router Class Initialized
DEBUG - 2014-03-04 02:47:30 --> Output Class Initialized
DEBUG - 2014-03-04 02:47:30 --> Security Class Initialized
DEBUG - 2014-03-04 02:47:30 --> Input Class Initialized
DEBUG - 2014-03-04 02:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:47:30 --> Language Class Initialized
DEBUG - 2014-03-04 02:47:30 --> Loader Class Initialized
DEBUG - 2014-03-04 02:47:30 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:47:30 --> Session Class Initialized
DEBUG - 2014-03-04 02:47:30 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:47:31 --> Session routines successfully run
DEBUG - 2014-03-04 02:47:31 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:47:31 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:47:31 --> Controller Class Initialized
DEBUG - 2014-03-04 02:47:31 --> this->setMessage()
DEBUG - 2014-03-04 02:47:31 --> File loaded: application/views/query.php
DEBUG - 2014-03-04 02:47:31 --> File loaded: application/views/master.php
DEBUG - 2014-03-04 02:47:31 --> Final output sent to browser
DEBUG - 2014-03-04 02:47:31 --> Total execution time: 2.0863
DEBUG - 2014-03-04 02:47:32 --> Config Class Initialized
DEBUG - 2014-03-04 02:47:32 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:47:32 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:47:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:47:32 --> Config Class Initialized
DEBUG - 2014-03-04 02:47:32 --> URI Class Initialized
DEBUG - 2014-03-04 02:47:32 --> Router Class Initialized
DEBUG - 2014-03-04 02:47:32 --> Config Class Initialized
DEBUG - 2014-03-04 02:47:32 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:47:32 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:47:32 --> Config Class Initialized
DEBUG - 2014-03-04 02:47:32 --> Output Class Initialized
DEBUG - 2014-03-04 02:47:32 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:47:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:47:32 --> Security Class Initialized
DEBUG - 2014-03-04 02:47:32 --> URI Class Initialized
DEBUG - 2014-03-04 02:47:32 --> Router Class Initialized
DEBUG - 2014-03-04 02:47:32 --> Output Class Initialized
DEBUG - 2014-03-04 02:47:32 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:47:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:47:32 --> Security Class Initialized
DEBUG - 2014-03-04 02:47:32 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:47:32 --> Input Class Initialized
DEBUG - 2014-03-04 02:47:32 --> URI Class Initialized
DEBUG - 2014-03-04 02:47:32 --> Input Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Router Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:47:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:47:33 --> Language Class Initialized
DEBUG - 2014-03-04 02:47:33 --> URI Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Output Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Router Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Security Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Loader Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Input Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Output Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:47:33 --> Language Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Security Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Loader Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Language Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Input Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Session Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:47:33 --> Session routines successfully run
DEBUG - 2014-03-04 02:47:33 --> Loader Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:47:33 --> Language Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Session Class Initialized
DEBUG - 2014-03-04 02:47:33 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Loader Class Initialized
DEBUG - 2014-03-04 02:47:33 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:47:34 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:47:34 --> Session Class Initialized
DEBUG - 2014-03-04 02:47:34 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:47:34 --> Session Class Initialized
DEBUG - 2014-03-04 02:47:34 --> Controller Class Initialized
DEBUG - 2014-03-04 02:47:34 --> Session routines successfully run
DEBUG - 2014-03-04 02:47:34 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:47:34 --> Session routines successfully run
DEBUG - 2014-03-04 02:47:34 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:47:34 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:47:34 --> this->setMessage()
DEBUG - 2014-03-04 02:47:34 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:47:34 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:47:34 --> Session routines successfully run
ERROR - 2014-03-04 02:47:34 --> 404 Page Not Found --> welcome/public
DEBUG - 2014-03-04 02:47:34 --> Controller Class Initialized
DEBUG - 2014-03-04 02:47:34 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:47:34 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:47:34 --> this->setMessage()
DEBUG - 2014-03-04 02:47:34 --> Controller Class Initialized
DEBUG - 2014-03-04 02:47:34 --> User Agent Class Initialized
ERROR - 2014-03-04 02:47:34 --> 404 Page Not Found --> welcome/public
DEBUG - 2014-03-04 02:47:35 --> this->setMessage()
DEBUG - 2014-03-04 02:47:35 --> Controller Class Initialized
ERROR - 2014-03-04 02:47:35 --> 404 Page Not Found --> welcome/public
DEBUG - 2014-03-04 02:47:35 --> this->setMessage()
ERROR - 2014-03-04 02:47:35 --> 404 Page Not Found --> welcome/public
DEBUG - 2014-03-04 02:48:09 --> Config Class Initialized
DEBUG - 2014-03-04 02:48:09 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:48:09 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:48:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:48:10 --> URI Class Initialized
DEBUG - 2014-03-04 02:48:10 --> Router Class Initialized
DEBUG - 2014-03-04 02:48:10 --> Output Class Initialized
DEBUG - 2014-03-04 02:48:10 --> Security Class Initialized
DEBUG - 2014-03-04 02:48:10 --> Input Class Initialized
DEBUG - 2014-03-04 02:48:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:48:10 --> Language Class Initialized
DEBUG - 2014-03-04 02:48:10 --> Loader Class Initialized
DEBUG - 2014-03-04 02:48:10 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:48:10 --> Session Class Initialized
DEBUG - 2014-03-04 02:48:11 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:48:11 --> Session routines successfully run
DEBUG - 2014-03-04 02:48:11 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:48:11 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:48:11 --> Controller Class Initialized
DEBUG - 2014-03-04 02:48:11 --> this->setMessage()
DEBUG - 2014-03-04 02:48:11 --> File loaded: application/views/master.php
DEBUG - 2014-03-04 02:48:11 --> Final output sent to browser
DEBUG - 2014-03-04 02:48:11 --> Total execution time: 1.8300
DEBUG - 2014-03-04 02:48:12 --> Config Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:48:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:48:12 --> URI Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Config Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Router Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:48:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:48:12 --> URI Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Output Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Router Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Security Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Output Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Input Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:48:12 --> Language Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Security Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Config Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Config Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Input Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Loader Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:48:12 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Language Class Initialized
DEBUG - 2014-03-04 02:48:12 --> Session Class Initialized
DEBUG - 2014-03-04 02:48:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:48:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:48:13 --> Loader Class Initialized
DEBUG - 2014-03-04 02:48:13 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:48:13 --> Session routines successfully run
DEBUG - 2014-03-04 02:48:13 --> URI Class Initialized
DEBUG - 2014-03-04 02:48:13 --> URI Class Initialized
DEBUG - 2014-03-04 02:48:13 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:48:13 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:48:13 --> Router Class Initialized
DEBUG - 2014-03-04 02:48:13 --> Router Class Initialized
DEBUG - 2014-03-04 02:48:13 --> Output Class Initialized
DEBUG - 2014-03-04 02:48:13 --> Session Class Initialized
DEBUG - 2014-03-04 02:48:13 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:48:13 --> Output Class Initialized
DEBUG - 2014-03-04 02:48:13 --> Security Class Initialized
DEBUG - 2014-03-04 02:48:13 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:48:13 --> Controller Class Initialized
DEBUG - 2014-03-04 02:48:13 --> Security Class Initialized
DEBUG - 2014-03-04 02:48:13 --> Input Class Initialized
DEBUG - 2014-03-04 02:48:13 --> Session routines successfully run
DEBUG - 2014-03-04 02:48:13 --> this->setMessage()
DEBUG - 2014-03-04 02:48:13 --> Input Class Initialized
DEBUG - 2014-03-04 02:48:13 --> Global POST and COOKIE data sanitized
ERROR - 2014-03-04 02:48:13 --> 404 Page Not Found --> welcome/public
DEBUG - 2014-03-04 02:48:13 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:48:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:48:14 --> Language Class Initialized
DEBUG - 2014-03-04 02:48:14 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:48:14 --> Language Class Initialized
DEBUG - 2014-03-04 02:48:14 --> Loader Class Initialized
DEBUG - 2014-03-04 02:48:14 --> Controller Class Initialized
DEBUG - 2014-03-04 02:48:14 --> Loader Class Initialized
DEBUG - 2014-03-04 02:48:14 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:48:14 --> this->setMessage()
DEBUG - 2014-03-04 02:48:14 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:48:14 --> Session Class Initialized
DEBUG - 2014-03-04 02:48:14 --> Session Class Initialized
ERROR - 2014-03-04 02:48:14 --> 404 Page Not Found --> welcome/public
DEBUG - 2014-03-04 02:48:14 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:48:14 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:48:14 --> Session routines successfully run
DEBUG - 2014-03-04 02:48:14 --> Session routines successfully run
DEBUG - 2014-03-04 02:48:14 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:48:14 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:48:14 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:48:14 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:48:15 --> Controller Class Initialized
DEBUG - 2014-03-04 02:48:15 --> Controller Class Initialized
DEBUG - 2014-03-04 02:48:15 --> this->setMessage()
DEBUG - 2014-03-04 02:48:15 --> this->setMessage()
ERROR - 2014-03-04 02:48:15 --> 404 Page Not Found --> welcome/public
ERROR - 2014-03-04 02:48:15 --> 404 Page Not Found --> welcome/public
DEBUG - 2014-03-04 02:50:06 --> Config Class Initialized
DEBUG - 2014-03-04 02:50:06 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:50:06 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:50:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:50:06 --> URI Class Initialized
DEBUG - 2014-03-04 02:50:06 --> Router Class Initialized
DEBUG - 2014-03-04 02:50:06 --> Output Class Initialized
DEBUG - 2014-03-04 02:50:06 --> Security Class Initialized
DEBUG - 2014-03-04 02:50:06 --> Input Class Initialized
DEBUG - 2014-03-04 02:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:50:06 --> Language Class Initialized
DEBUG - 2014-03-04 02:50:35 --> Config Class Initialized
DEBUG - 2014-03-04 02:50:35 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:50:35 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:50:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:50:35 --> URI Class Initialized
DEBUG - 2014-03-04 02:50:35 --> Router Class Initialized
DEBUG - 2014-03-04 02:50:35 --> Output Class Initialized
DEBUG - 2014-03-04 02:50:35 --> Security Class Initialized
DEBUG - 2014-03-04 02:50:35 --> Input Class Initialized
DEBUG - 2014-03-04 02:50:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:50:36 --> Language Class Initialized
DEBUG - 2014-03-04 02:50:36 --> Loader Class Initialized
DEBUG - 2014-03-04 02:50:36 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:50:36 --> Session Class Initialized
DEBUG - 2014-03-04 02:50:36 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:50:36 --> Session routines successfully run
DEBUG - 2014-03-04 02:50:36 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:50:36 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:50:36 --> Controller Class Initialized
DEBUG - 2014-03-04 02:50:37 --> this->setMessage()
DEBUG - 2014-03-04 02:50:37 --> File loaded: application/views/query.php
DEBUG - 2014-03-04 02:50:37 --> File loaded: application/views/master.php
DEBUG - 2014-03-04 02:50:37 --> Final output sent to browser
DEBUG - 2014-03-04 02:50:37 --> Total execution time: 2.0442
DEBUG - 2014-03-04 02:50:37 --> Config Class Initialized
DEBUG - 2014-03-04 02:50:37 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:50:37 --> Config Class Initialized
DEBUG - 2014-03-04 02:50:37 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:50:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:50:37 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:50:37 --> Config Class Initialized
DEBUG - 2014-03-04 02:50:37 --> Config Class Initialized
DEBUG - 2014-03-04 02:50:37 --> URI Class Initialized
DEBUG - 2014-03-04 02:50:37 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:50:37 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:50:37 --> Router Class Initialized
DEBUG - 2014-03-04 02:50:37 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:50:37 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:50:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:50:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:50:37 --> URI Class Initialized
DEBUG - 2014-03-04 02:50:37 --> URI Class Initialized
DEBUG - 2014-03-04 02:50:37 --> Router Class Initialized
DEBUG - 2014-03-04 02:50:37 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:50:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:50:37 --> Output Class Initialized
DEBUG - 2014-03-04 02:50:37 --> Security Class Initialized
DEBUG - 2014-03-04 02:50:37 --> Output Class Initialized
DEBUG - 2014-03-04 02:50:38 --> Router Class Initialized
DEBUG - 2014-03-04 02:50:38 --> URI Class Initialized
DEBUG - 2014-03-04 02:50:38 --> Input Class Initialized
DEBUG - 2014-03-04 02:50:38 --> Security Class Initialized
DEBUG - 2014-03-04 02:50:38 --> Output Class Initialized
DEBUG - 2014-03-04 02:50:38 --> Router Class Initialized
DEBUG - 2014-03-04 02:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:50:38 --> Input Class Initialized
DEBUG - 2014-03-04 02:50:38 --> Security Class Initialized
DEBUG - 2014-03-04 02:50:38 --> Output Class Initialized
DEBUG - 2014-03-04 02:50:38 --> Language Class Initialized
DEBUG - 2014-03-04 02:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:50:38 --> Input Class Initialized
DEBUG - 2014-03-04 02:50:38 --> Security Class Initialized
DEBUG - 2014-03-04 02:50:38 --> Input Class Initialized
DEBUG - 2014-03-04 02:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:50:38 --> Loader Class Initialized
DEBUG - 2014-03-04 02:50:39 --> Language Class Initialized
DEBUG - 2014-03-04 02:50:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:50:39 --> Language Class Initialized
DEBUG - 2014-03-04 02:50:39 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:50:39 --> Loader Class Initialized
DEBUG - 2014-03-04 02:50:39 --> Language Class Initialized
DEBUG - 2014-03-04 02:50:39 --> Loader Class Initialized
DEBUG - 2014-03-04 02:50:39 --> Session Class Initialized
DEBUG - 2014-03-04 02:50:39 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:50:39 --> Loader Class Initialized
DEBUG - 2014-03-04 02:50:39 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:50:39 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:50:39 --> Session Class Initialized
DEBUG - 2014-03-04 02:50:39 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:50:40 --> Session Class Initialized
DEBUG - 2014-03-04 02:50:40 --> Session routines successfully run
DEBUG - 2014-03-04 02:50:40 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:50:40 --> Session Class Initialized
DEBUG - 2014-03-04 02:50:40 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:50:40 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:50:40 --> Session routines successfully run
DEBUG - 2014-03-04 02:50:40 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:50:40 --> Session routines successfully run
DEBUG - 2014-03-04 02:50:40 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:50:40 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:50:40 --> Session routines successfully run
DEBUG - 2014-03-04 02:50:40 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:50:40 --> Controller Class Initialized
DEBUG - 2014-03-04 02:50:40 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:50:40 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:50:40 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:50:40 --> this->setMessage()
DEBUG - 2014-03-04 02:50:40 --> Controller Class Initialized
DEBUG - 2014-03-04 02:50:41 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:50:41 --> Controller Class Initialized
DEBUG - 2014-03-04 02:50:41 --> this->setMessage()
ERROR - 2014-03-04 02:50:41 --> 404 Page Not Found --> welcome/public
DEBUG - 2014-03-04 02:50:41 --> Controller Class Initialized
DEBUG - 2014-03-04 02:50:41 --> this->setMessage()
ERROR - 2014-03-04 02:50:41 --> 404 Page Not Found --> welcome/public
DEBUG - 2014-03-04 02:50:41 --> this->setMessage()
ERROR - 2014-03-04 02:50:41 --> 404 Page Not Found --> welcome/public
ERROR - 2014-03-04 02:50:41 --> 404 Page Not Found --> welcome/public
DEBUG - 2014-03-04 02:52:37 --> Config Class Initialized
DEBUG - 2014-03-04 02:52:37 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:52:38 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:52:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:52:38 --> URI Class Initialized
DEBUG - 2014-03-04 02:52:38 --> Router Class Initialized
DEBUG - 2014-03-04 02:52:38 --> Output Class Initialized
DEBUG - 2014-03-04 02:52:38 --> Security Class Initialized
DEBUG - 2014-03-04 02:52:38 --> Input Class Initialized
DEBUG - 2014-03-04 02:52:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:52:38 --> Language Class Initialized
DEBUG - 2014-03-04 02:52:38 --> Loader Class Initialized
DEBUG - 2014-03-04 02:52:39 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:52:39 --> Session Class Initialized
DEBUG - 2014-03-04 02:52:39 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:52:39 --> Session routines successfully run
DEBUG - 2014-03-04 02:52:39 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:52:39 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:52:39 --> Controller Class Initialized
DEBUG - 2014-03-04 02:52:39 --> this->setMessage()
DEBUG - 2014-03-04 02:52:39 --> File loaded: application/views/query.php
DEBUG - 2014-03-04 02:52:39 --> File loaded: application/views/master.php
DEBUG - 2014-03-04 02:52:39 --> Final output sent to browser
DEBUG - 2014-03-04 02:52:40 --> Total execution time: 1.9719
DEBUG - 2014-03-04 02:52:40 --> Config Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Config Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Config Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Config Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:52:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:52:40 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:52:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:52:40 --> URI Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:52:40 --> URI Class Initialized
DEBUG - 2014-03-04 02:52:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:52:40 --> Router Class Initialized
DEBUG - 2014-03-04 02:52:40 --> URI Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Output Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Config Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Router Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Router Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:52:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:52:40 --> Output Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Security Class Initialized
DEBUG - 2014-03-04 02:52:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:52:40 --> URI Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Security Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Router Class Initialized
DEBUG - 2014-03-04 02:52:40 --> URI Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Input Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:52:40 --> Output Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Config Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Language Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Output Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Router Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Security Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:52:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:52:40 --> Input Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:52:40 --> Output Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Loader Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Security Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Language Class Initialized
DEBUG - 2014-03-04 02:52:40 --> URI Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Input Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Input Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Router Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Security Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:52:40 --> Loader Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Input Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Language Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:52:40 --> Language Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Output Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Security Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:52:40 --> Input Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:52:40 --> Language Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Language Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Loader Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Loader Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Loader Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Loader Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Session Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Session Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:52:40 --> Session routines successfully run
DEBUG - 2014-03-04 02:52:40 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Session Class Initialized
DEBUG - 2014-03-04 02:52:40 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:52:40 --> Session routines successfully run
DEBUG - 2014-03-04 02:52:40 --> Session Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:52:40 --> Session routines successfully run
DEBUG - 2014-03-04 02:52:40 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:52:40 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:52:40 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:52:40 --> Controller Class Initialized
DEBUG - 2014-03-04 02:52:40 --> this->setMessage()
DEBUG - 2014-03-04 02:52:41 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:52:41 --> Controller Class Initialized
DEBUG - 2014-03-04 02:52:41 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:52:41 --> this->setMessage()
DEBUG - 2014-03-04 02:52:41 --> Controller Class Initialized
DEBUG - 2014-03-04 02:52:41 --> this->setMessage()
DEBUG - 2014-03-04 02:52:41 --> Helper loaded: string_helper
ERROR - 2014-03-04 02:52:41 --> 404 Page Not Found --> welcome/public
DEBUG - 2014-03-04 02:52:41 --> Session routines successfully run
DEBUG - 2014-03-04 02:52:41 --> Database Driver Class Initialized
ERROR - 2014-03-04 02:52:41 --> 404 Page Not Found --> welcome/public
ERROR - 2014-03-04 02:52:41 --> 404 Page Not Found --> welcome/public
DEBUG - 2014-03-04 02:52:41 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:52:41 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:52:41 --> Controller Class Initialized
DEBUG - 2014-03-04 02:52:41 --> this->setMessage()
DEBUG - 2014-03-04 02:52:41 --> Session Class Initialized
ERROR - 2014-03-04 02:52:41 --> 404 Page Not Found --> welcome/public
DEBUG - 2014-03-04 02:52:42 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:52:42 --> Session routines successfully run
DEBUG - 2014-03-04 02:52:42 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:52:42 --> Session Class Initialized
DEBUG - 2014-03-04 02:52:42 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:52:42 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:52:42 --> Controller Class Initialized
DEBUG - 2014-03-04 02:52:42 --> Session routines successfully run
DEBUG - 2014-03-04 02:52:42 --> this->setMessage()
DEBUG - 2014-03-04 02:52:42 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:52:42 --> User Agent Class Initialized
ERROR - 2014-03-04 02:52:42 --> 404 Page Not Found --> welcome/public
DEBUG - 2014-03-04 02:52:42 --> Controller Class Initialized
DEBUG - 2014-03-04 02:52:43 --> this->setMessage()
ERROR - 2014-03-04 02:52:43 --> 404 Page Not Found --> welcome/public
DEBUG - 2014-03-04 02:54:59 --> Config Class Initialized
DEBUG - 2014-03-04 02:54:59 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:54:59 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:54:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:54:59 --> URI Class Initialized
DEBUG - 2014-03-04 02:54:59 --> Router Class Initialized
DEBUG - 2014-03-04 02:54:59 --> Output Class Initialized
DEBUG - 2014-03-04 02:54:59 --> Security Class Initialized
DEBUG - 2014-03-04 02:54:59 --> Input Class Initialized
DEBUG - 2014-03-04 02:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:55:00 --> Language Class Initialized
ERROR - 2014-03-04 02:55:00 --> Severity: Notice  --> Undefined property: Welcome::$load C:\wamp\www\nas\application\controllers\welcome.php 8
DEBUG - 2014-03-04 02:55:36 --> Config Class Initialized
DEBUG - 2014-03-04 02:55:36 --> Hooks Class Initialized
DEBUG - 2014-03-04 02:55:36 --> Utf8 Class Initialized
DEBUG - 2014-03-04 02:55:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 02:55:36 --> URI Class Initialized
DEBUG - 2014-03-04 02:55:36 --> Router Class Initialized
DEBUG - 2014-03-04 02:55:37 --> Output Class Initialized
DEBUG - 2014-03-04 02:55:37 --> Security Class Initialized
DEBUG - 2014-03-04 02:55:37 --> Input Class Initialized
DEBUG - 2014-03-04 02:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 02:55:37 --> Language Class Initialized
DEBUG - 2014-03-04 02:55:37 --> Loader Class Initialized
DEBUG - 2014-03-04 02:55:37 --> Database Driver Class Initialized
DEBUG - 2014-03-04 02:55:37 --> Session Class Initialized
DEBUG - 2014-03-04 02:55:37 --> Helper loaded: string_helper
DEBUG - 2014-03-04 02:55:37 --> Session routines successfully run
DEBUG - 2014-03-04 02:55:38 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 02:55:38 --> User Agent Class Initialized
DEBUG - 2014-03-04 02:55:38 --> Controller Class Initialized
DEBUG - 2014-03-04 02:55:38 --> Helper loaded: url_helper
DEBUG - 2014-03-04 02:55:38 --> this->setMessage()
DEBUG - 2014-03-04 02:55:38 --> File loaded: application/views/query.php
DEBUG - 2014-03-04 02:55:38 --> File loaded: application/views/master.php
DEBUG - 2014-03-04 02:55:38 --> Final output sent to browser
DEBUG - 2014-03-04 02:55:38 --> Total execution time: 2.0696
DEBUG - 2014-03-04 05:56:24 --> Config Class Initialized
DEBUG - 2014-03-04 05:56:24 --> Hooks Class Initialized
DEBUG - 2014-03-04 05:56:24 --> Utf8 Class Initialized
DEBUG - 2014-03-04 05:56:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 05:56:24 --> URI Class Initialized
DEBUG - 2014-03-04 05:56:24 --> Router Class Initialized
DEBUG - 2014-03-04 05:56:24 --> Output Class Initialized
DEBUG - 2014-03-04 05:56:24 --> Security Class Initialized
DEBUG - 2014-03-04 05:56:24 --> Input Class Initialized
DEBUG - 2014-03-04 05:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 05:56:24 --> Language Class Initialized
DEBUG - 2014-03-04 05:56:24 --> Loader Class Initialized
DEBUG - 2014-03-04 05:56:24 --> Database Driver Class Initialized
DEBUG - 2014-03-04 05:56:24 --> Session Class Initialized
DEBUG - 2014-03-04 05:56:24 --> Helper loaded: string_helper
DEBUG - 2014-03-04 05:56:24 --> A session cookie was not found.
DEBUG - 2014-03-04 05:56:24 --> Session routines successfully run
DEBUG - 2014-03-04 05:56:24 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 05:56:24 --> User Agent Class Initialized
DEBUG - 2014-03-04 05:56:24 --> Controller Class Initialized
DEBUG - 2014-03-04 05:56:24 --> Helper loaded: url_helper
DEBUG - 2014-03-04 05:56:24 --> this->setMessage()
DEBUG - 2014-03-04 05:56:25 --> File loaded: application/views/query.php
DEBUG - 2014-03-04 05:56:25 --> File loaded: application/views/master.php
DEBUG - 2014-03-04 05:56:25 --> Final output sent to browser
DEBUG - 2014-03-04 05:56:25 --> Total execution time: 0.7460
DEBUG - 2014-03-04 05:56:45 --> Config Class Initialized
DEBUG - 2014-03-04 05:56:45 --> Hooks Class Initialized
DEBUG - 2014-03-04 05:56:45 --> Utf8 Class Initialized
DEBUG - 2014-03-04 05:56:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 05:56:45 --> URI Class Initialized
DEBUG - 2014-03-04 05:56:45 --> Router Class Initialized
DEBUG - 2014-03-04 05:56:45 --> Output Class Initialized
DEBUG - 2014-03-04 05:56:45 --> Security Class Initialized
DEBUG - 2014-03-04 05:56:45 --> Input Class Initialized
DEBUG - 2014-03-04 05:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 05:56:45 --> Language Class Initialized
DEBUG - 2014-03-04 05:56:45 --> Loader Class Initialized
DEBUG - 2014-03-04 05:56:45 --> Database Driver Class Initialized
DEBUG - 2014-03-04 05:56:45 --> Session Class Initialized
DEBUG - 2014-03-04 05:56:45 --> Helper loaded: string_helper
DEBUG - 2014-03-04 05:56:45 --> Session routines successfully run
DEBUG - 2014-03-04 05:56:45 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 05:56:45 --> User Agent Class Initialized
DEBUG - 2014-03-04 05:56:45 --> Controller Class Initialized
DEBUG - 2014-03-04 05:56:45 --> Helper loaded: url_helper
DEBUG - 2014-03-04 05:56:45 --> this->setMessage()
ERROR - 2014-03-04 05:56:45 --> 404 Page Not Found --> welcome/Controls
DEBUG - 2014-03-04 05:59:59 --> Config Class Initialized
DEBUG - 2014-03-04 05:59:59 --> Hooks Class Initialized
DEBUG - 2014-03-04 05:59:59 --> Utf8 Class Initialized
DEBUG - 2014-03-04 05:59:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 05:59:59 --> URI Class Initialized
DEBUG - 2014-03-04 05:59:59 --> Router Class Initialized
DEBUG - 2014-03-04 05:59:59 --> Output Class Initialized
DEBUG - 2014-03-04 05:59:59 --> Security Class Initialized
DEBUG - 2014-03-04 05:59:59 --> Input Class Initialized
DEBUG - 2014-03-04 05:59:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 05:59:59 --> Language Class Initialized
DEBUG - 2014-03-04 05:59:59 --> Loader Class Initialized
DEBUG - 2014-03-04 05:59:59 --> Database Driver Class Initialized
DEBUG - 2014-03-04 05:59:59 --> Session Class Initialized
DEBUG - 2014-03-04 05:59:59 --> Helper loaded: string_helper
DEBUG - 2014-03-04 05:59:59 --> Session routines successfully run
DEBUG - 2014-03-04 05:59:59 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 05:59:59 --> User Agent Class Initialized
DEBUG - 2014-03-04 05:59:59 --> Controller Class Initialized
DEBUG - 2014-03-04 05:59:59 --> Helper loaded: url_helper
DEBUG - 2014-03-04 05:59:59 --> this->setMessage()
DEBUG - 2014-03-04 05:59:59 --> File loaded: application/views/query.php
DEBUG - 2014-03-04 05:59:59 --> File loaded: application/views/master.php
DEBUG - 2014-03-04 05:59:59 --> Final output sent to browser
DEBUG - 2014-03-04 06:00:00 --> Total execution time: 0.6623
DEBUG - 2014-03-04 06:01:30 --> Config Class Initialized
DEBUG - 2014-03-04 06:01:30 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:01:30 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:01:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:01:30 --> URI Class Initialized
DEBUG - 2014-03-04 06:01:30 --> Router Class Initialized
DEBUG - 2014-03-04 06:01:30 --> Output Class Initialized
DEBUG - 2014-03-04 06:01:30 --> Security Class Initialized
DEBUG - 2014-03-04 06:01:30 --> Input Class Initialized
DEBUG - 2014-03-04 06:01:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:01:30 --> Language Class Initialized
DEBUG - 2014-03-04 06:01:30 --> Loader Class Initialized
DEBUG - 2014-03-04 06:01:30 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:01:30 --> Session Class Initialized
DEBUG - 2014-03-04 06:01:30 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:01:30 --> Session routines successfully run
DEBUG - 2014-03-04 06:01:30 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:01:30 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:01:30 --> Controller Class Initialized
DEBUG - 2014-03-04 06:01:30 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:01:30 --> this->setMessage()
DEBUG - 2014-03-04 06:01:30 --> File loaded: application/views/query.php
DEBUG - 2014-03-04 06:01:30 --> File loaded: application/views/master.php
DEBUG - 2014-03-04 06:01:30 --> Final output sent to browser
DEBUG - 2014-03-04 06:01:30 --> Total execution time: 0.6291
DEBUG - 2014-03-04 06:03:32 --> Config Class Initialized
DEBUG - 2014-03-04 06:03:32 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:03:32 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:03:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:03:32 --> URI Class Initialized
DEBUG - 2014-03-04 06:03:32 --> Router Class Initialized
DEBUG - 2014-03-04 06:03:32 --> Output Class Initialized
DEBUG - 2014-03-04 06:03:32 --> Security Class Initialized
DEBUG - 2014-03-04 06:03:32 --> Input Class Initialized
DEBUG - 2014-03-04 06:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:03:32 --> Language Class Initialized
DEBUG - 2014-03-04 06:04:01 --> Config Class Initialized
DEBUG - 2014-03-04 06:04:01 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:04:01 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:04:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:04:01 --> URI Class Initialized
DEBUG - 2014-03-04 06:04:01 --> Router Class Initialized
DEBUG - 2014-03-04 06:04:01 --> Output Class Initialized
DEBUG - 2014-03-04 06:04:01 --> Security Class Initialized
DEBUG - 2014-03-04 06:04:01 --> Input Class Initialized
DEBUG - 2014-03-04 06:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:04:01 --> Language Class Initialized
DEBUG - 2014-03-04 06:04:01 --> Loader Class Initialized
DEBUG - 2014-03-04 06:04:01 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:04:01 --> Session Class Initialized
DEBUG - 2014-03-04 06:04:01 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:04:01 --> Session routines successfully run
DEBUG - 2014-03-04 06:04:01 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:04:01 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:04:01 --> Controller Class Initialized
DEBUG - 2014-03-04 06:04:01 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:04:01 --> Model Class Initialized
DEBUG - 2014-03-04 06:04:01 --> Final output sent to browser
DEBUG - 2014-03-04 06:04:01 --> Total execution time: 0.4091
DEBUG - 2014-03-04 06:04:41 --> Config Class Initialized
DEBUG - 2014-03-04 06:04:41 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:04:41 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:04:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:04:41 --> URI Class Initialized
DEBUG - 2014-03-04 06:04:41 --> Router Class Initialized
DEBUG - 2014-03-04 06:04:41 --> Output Class Initialized
DEBUG - 2014-03-04 06:04:41 --> Security Class Initialized
DEBUG - 2014-03-04 06:04:41 --> Input Class Initialized
DEBUG - 2014-03-04 06:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:04:42 --> Language Class Initialized
DEBUG - 2014-03-04 06:04:42 --> Loader Class Initialized
DEBUG - 2014-03-04 06:04:42 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:04:42 --> Session Class Initialized
DEBUG - 2014-03-04 06:04:42 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:04:42 --> Session routines successfully run
DEBUG - 2014-03-04 06:04:42 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:04:42 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:04:42 --> Controller Class Initialized
DEBUG - 2014-03-04 06:04:42 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:04:42 --> Model Class Initialized
DEBUG - 2014-03-04 06:04:42 --> Final output sent to browser
DEBUG - 2014-03-04 06:04:42 --> Total execution time: 0.5319
DEBUG - 2014-03-04 06:04:50 --> Config Class Initialized
DEBUG - 2014-03-04 06:04:50 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:04:50 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:04:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:04:50 --> URI Class Initialized
DEBUG - 2014-03-04 06:04:50 --> Router Class Initialized
DEBUG - 2014-03-04 06:04:50 --> Output Class Initialized
DEBUG - 2014-03-04 06:04:50 --> Security Class Initialized
DEBUG - 2014-03-04 06:04:50 --> Input Class Initialized
DEBUG - 2014-03-04 06:04:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:04:50 --> Language Class Initialized
DEBUG - 2014-03-04 06:04:50 --> Loader Class Initialized
DEBUG - 2014-03-04 06:04:50 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:04:50 --> Session Class Initialized
DEBUG - 2014-03-04 06:04:50 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:04:50 --> Session routines successfully run
DEBUG - 2014-03-04 06:04:50 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:04:50 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:04:50 --> Controller Class Initialized
DEBUG - 2014-03-04 06:04:50 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:04:50 --> this->setMessage()
DEBUG - 2014-03-04 06:04:50 --> File loaded: application/views/query.php
DEBUG - 2014-03-04 06:04:50 --> File loaded: application/views/master.php
DEBUG - 2014-03-04 06:04:51 --> Final output sent to browser
DEBUG - 2014-03-04 06:04:51 --> Total execution time: 0.6948
DEBUG - 2014-03-04 06:05:03 --> Config Class Initialized
DEBUG - 2014-03-04 06:05:03 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:05:03 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:05:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:05:03 --> URI Class Initialized
DEBUG - 2014-03-04 06:05:03 --> Router Class Initialized
DEBUG - 2014-03-04 06:05:03 --> Output Class Initialized
DEBUG - 2014-03-04 06:05:03 --> Security Class Initialized
DEBUG - 2014-03-04 06:05:03 --> Input Class Initialized
DEBUG - 2014-03-04 06:05:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:05:03 --> Language Class Initialized
DEBUG - 2014-03-04 06:05:03 --> Loader Class Initialized
DEBUG - 2014-03-04 06:05:03 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:05:03 --> Session Class Initialized
DEBUG - 2014-03-04 06:05:03 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:05:03 --> Session routines successfully run
DEBUG - 2014-03-04 06:05:03 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:05:03 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:05:03 --> Controller Class Initialized
DEBUG - 2014-03-04 06:05:03 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:05:03 --> Model Class Initialized
DEBUG - 2014-03-04 06:26:51 --> Config Class Initialized
DEBUG - 2014-03-04 06:26:51 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:26:51 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:26:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:26:51 --> URI Class Initialized
DEBUG - 2014-03-04 06:26:51 --> Router Class Initialized
DEBUG - 2014-03-04 06:26:51 --> Output Class Initialized
DEBUG - 2014-03-04 06:26:51 --> Security Class Initialized
DEBUG - 2014-03-04 06:26:51 --> Input Class Initialized
DEBUG - 2014-03-04 06:26:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:26:51 --> Language Class Initialized
DEBUG - 2014-03-04 06:26:51 --> Loader Class Initialized
DEBUG - 2014-03-04 06:26:51 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:26:51 --> Session Class Initialized
DEBUG - 2014-03-04 06:26:51 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:26:51 --> Session routines successfully run
DEBUG - 2014-03-04 06:26:51 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:26:51 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:26:51 --> Controller Class Initialized
DEBUG - 2014-03-04 06:26:51 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:26:51 --> Model Class Initialized
DEBUG - 2014-03-04 06:26:57 --> Config Class Initialized
DEBUG - 2014-03-04 06:26:57 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:26:57 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:26:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:26:57 --> URI Class Initialized
DEBUG - 2014-03-04 06:26:57 --> Router Class Initialized
DEBUG - 2014-03-04 06:26:57 --> Output Class Initialized
DEBUG - 2014-03-04 06:26:57 --> Security Class Initialized
DEBUG - 2014-03-04 06:26:57 --> Input Class Initialized
DEBUG - 2014-03-04 06:26:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:26:57 --> Language Class Initialized
DEBUG - 2014-03-04 06:26:58 --> Loader Class Initialized
DEBUG - 2014-03-04 06:26:58 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:26:58 --> Session Class Initialized
DEBUG - 2014-03-04 06:26:58 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:26:58 --> Session routines successfully run
DEBUG - 2014-03-04 06:26:58 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:26:58 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:26:58 --> Controller Class Initialized
DEBUG - 2014-03-04 06:26:58 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:26:58 --> this->setMessage()
DEBUG - 2014-03-04 06:26:58 --> File loaded: application/views/query.php
DEBUG - 2014-03-04 06:26:58 --> File loaded: application/views/master.php
DEBUG - 2014-03-04 06:26:58 --> Final output sent to browser
DEBUG - 2014-03-04 06:26:58 --> Total execution time: 0.5714
DEBUG - 2014-03-04 06:27:03 --> Config Class Initialized
DEBUG - 2014-03-04 06:27:03 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:27:03 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:27:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:27:03 --> URI Class Initialized
DEBUG - 2014-03-04 06:27:03 --> Router Class Initialized
DEBUG - 2014-03-04 06:27:03 --> Output Class Initialized
DEBUG - 2014-03-04 06:27:03 --> Security Class Initialized
DEBUG - 2014-03-04 06:27:03 --> Input Class Initialized
DEBUG - 2014-03-04 06:27:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:27:03 --> Language Class Initialized
DEBUG - 2014-03-04 06:27:03 --> Loader Class Initialized
DEBUG - 2014-03-04 06:27:03 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:27:03 --> Session Class Initialized
DEBUG - 2014-03-04 06:27:03 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:27:03 --> Session routines successfully run
DEBUG - 2014-03-04 06:27:03 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:27:03 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:27:03 --> Controller Class Initialized
DEBUG - 2014-03-04 06:27:03 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:27:03 --> Model Class Initialized
DEBUG - 2014-03-04 06:27:56 --> Config Class Initialized
DEBUG - 2014-03-04 06:27:56 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:27:56 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:27:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:27:56 --> URI Class Initialized
DEBUG - 2014-03-04 06:27:56 --> Router Class Initialized
DEBUG - 2014-03-04 06:27:56 --> Output Class Initialized
DEBUG - 2014-03-04 06:27:56 --> Security Class Initialized
DEBUG - 2014-03-04 06:27:56 --> Input Class Initialized
DEBUG - 2014-03-04 06:27:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:27:56 --> Language Class Initialized
DEBUG - 2014-03-04 06:27:56 --> Loader Class Initialized
DEBUG - 2014-03-04 06:27:56 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:27:56 --> Session Class Initialized
DEBUG - 2014-03-04 06:27:56 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:27:56 --> Session routines successfully run
DEBUG - 2014-03-04 06:27:56 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:27:56 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:27:56 --> Controller Class Initialized
DEBUG - 2014-03-04 06:27:56 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:27:57 --> Model Class Initialized
DEBUG - 2014-03-04 06:28:03 --> Config Class Initialized
DEBUG - 2014-03-04 06:28:03 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:28:03 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:28:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:28:03 --> URI Class Initialized
DEBUG - 2014-03-04 06:28:03 --> Router Class Initialized
DEBUG - 2014-03-04 06:28:03 --> Output Class Initialized
DEBUG - 2014-03-04 06:28:03 --> Security Class Initialized
DEBUG - 2014-03-04 06:28:03 --> Input Class Initialized
DEBUG - 2014-03-04 06:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:28:03 --> Language Class Initialized
DEBUG - 2014-03-04 06:28:03 --> Loader Class Initialized
DEBUG - 2014-03-04 06:28:03 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:28:03 --> Session Class Initialized
DEBUG - 2014-03-04 06:28:03 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:28:03 --> Session routines successfully run
DEBUG - 2014-03-04 06:28:03 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:28:03 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:28:03 --> Controller Class Initialized
DEBUG - 2014-03-04 06:28:03 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:28:03 --> Model Class Initialized
DEBUG - 2014-03-04 06:28:36 --> Config Class Initialized
DEBUG - 2014-03-04 06:28:36 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:28:36 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:28:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:28:36 --> URI Class Initialized
DEBUG - 2014-03-04 06:28:36 --> Router Class Initialized
DEBUG - 2014-03-04 06:28:37 --> Output Class Initialized
DEBUG - 2014-03-04 06:28:37 --> Security Class Initialized
DEBUG - 2014-03-04 06:28:37 --> Input Class Initialized
DEBUG - 2014-03-04 06:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:28:37 --> Language Class Initialized
DEBUG - 2014-03-04 06:28:37 --> Loader Class Initialized
DEBUG - 2014-03-04 06:28:37 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:28:37 --> Session Class Initialized
DEBUG - 2014-03-04 06:28:37 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:28:37 --> Session routines successfully run
DEBUG - 2014-03-04 06:28:37 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:28:37 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:28:37 --> Controller Class Initialized
DEBUG - 2014-03-04 06:28:37 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:28:37 --> Model Class Initialized
ERROR - 2014-03-04 06:28:37 --> Severity: Warning  --> Missing argument 1 for Project_model::get_project_teacher(), called in C:\wamp\www\nas\application\controllers\query.php on line 40 and defined C:\wamp\www\nas\application\models\Project_model.php 8
DEBUG - 2014-03-04 06:28:37 --> DB Transaction Failure
ERROR - 2014-03-04 06:28:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE '%葉%'' at line 1
DEBUG - 2014-03-04 06:28:37 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-04 06:29:20 --> Config Class Initialized
DEBUG - 2014-03-04 06:29:20 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:29:20 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:29:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:29:20 --> URI Class Initialized
DEBUG - 2014-03-04 06:29:20 --> Router Class Initialized
DEBUG - 2014-03-04 06:29:20 --> Output Class Initialized
DEBUG - 2014-03-04 06:29:20 --> Security Class Initialized
DEBUG - 2014-03-04 06:29:20 --> Input Class Initialized
DEBUG - 2014-03-04 06:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:29:20 --> Language Class Initialized
DEBUG - 2014-03-04 06:29:20 --> Loader Class Initialized
DEBUG - 2014-03-04 06:29:21 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:29:21 --> Session Class Initialized
DEBUG - 2014-03-04 06:29:21 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:29:21 --> Session routines successfully run
DEBUG - 2014-03-04 06:29:21 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:29:21 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:29:21 --> Controller Class Initialized
DEBUG - 2014-03-04 06:29:21 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:29:21 --> Model Class Initialized
DEBUG - 2014-03-04 06:29:21 --> Final output sent to browser
DEBUG - 2014-03-04 06:29:21 --> Total execution time: 0.3392
DEBUG - 2014-03-04 06:31:00 --> Config Class Initialized
DEBUG - 2014-03-04 06:31:00 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:31:00 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:31:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:31:00 --> URI Class Initialized
DEBUG - 2014-03-04 06:31:00 --> Router Class Initialized
DEBUG - 2014-03-04 06:31:00 --> Output Class Initialized
DEBUG - 2014-03-04 06:31:00 --> Security Class Initialized
DEBUG - 2014-03-04 06:31:00 --> Input Class Initialized
DEBUG - 2014-03-04 06:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:31:00 --> Language Class Initialized
DEBUG - 2014-03-04 06:31:00 --> Loader Class Initialized
DEBUG - 2014-03-04 06:31:00 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:31:00 --> Session Class Initialized
DEBUG - 2014-03-04 06:31:00 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:31:00 --> Session routines successfully run
DEBUG - 2014-03-04 06:31:00 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:31:00 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:31:00 --> Controller Class Initialized
DEBUG - 2014-03-04 06:31:00 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:31:00 --> Model Class Initialized
ERROR - 2014-03-04 06:31:00 --> Severity: Warning  --> Missing argument 1 for Project_model::get_project_teacher(), called in C:\wamp\www\nas\application\controllers\query.php on line 41 and defined C:\wamp\www\nas\application\models\Project_model.php 8
DEBUG - 2014-03-04 06:31:00 --> Final output sent to browser
DEBUG - 2014-03-04 06:31:00 --> Total execution time: 0.4074
DEBUG - 2014-03-04 06:31:38 --> Config Class Initialized
DEBUG - 2014-03-04 06:31:38 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:31:38 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:31:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:31:38 --> URI Class Initialized
DEBUG - 2014-03-04 06:31:38 --> Router Class Initialized
DEBUG - 2014-03-04 06:31:38 --> Output Class Initialized
DEBUG - 2014-03-04 06:31:38 --> Security Class Initialized
DEBUG - 2014-03-04 06:31:38 --> Input Class Initialized
DEBUG - 2014-03-04 06:31:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:31:38 --> Language Class Initialized
DEBUG - 2014-03-04 06:31:38 --> Loader Class Initialized
DEBUG - 2014-03-04 06:31:38 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:31:38 --> Session Class Initialized
DEBUG - 2014-03-04 06:31:38 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:31:38 --> Session routines successfully run
DEBUG - 2014-03-04 06:31:38 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:31:38 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:31:38 --> Controller Class Initialized
DEBUG - 2014-03-04 06:31:38 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:31:38 --> Model Class Initialized
DEBUG - 2014-03-04 06:31:38 --> Final output sent to browser
DEBUG - 2014-03-04 06:31:38 --> Total execution time: 0.3366
DEBUG - 2014-03-04 06:33:12 --> Config Class Initialized
DEBUG - 2014-03-04 06:33:12 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:33:12 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:33:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:33:12 --> URI Class Initialized
DEBUG - 2014-03-04 06:33:12 --> Router Class Initialized
DEBUG - 2014-03-04 06:33:12 --> Output Class Initialized
DEBUG - 2014-03-04 06:33:12 --> Security Class Initialized
DEBUG - 2014-03-04 06:33:12 --> Input Class Initialized
DEBUG - 2014-03-04 06:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:33:12 --> Language Class Initialized
DEBUG - 2014-03-04 06:33:12 --> Loader Class Initialized
DEBUG - 2014-03-04 06:33:12 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:33:12 --> Session Class Initialized
DEBUG - 2014-03-04 06:33:12 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:33:12 --> Session routines successfully run
DEBUG - 2014-03-04 06:33:12 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:33:12 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:33:12 --> Controller Class Initialized
DEBUG - 2014-03-04 06:33:12 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:33:12 --> Model Class Initialized
ERROR - 2014-03-04 06:33:12 --> Severity: Notice  --> Array to string conversion C:\wamp\www\nas\application\controllers\query.php 41
DEBUG - 2014-03-04 06:33:12 --> Final output sent to browser
DEBUG - 2014-03-04 06:33:12 --> Total execution time: 0.4780
DEBUG - 2014-03-04 06:33:17 --> Config Class Initialized
DEBUG - 2014-03-04 06:33:17 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:33:17 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:33:17 --> URI Class Initialized
DEBUG - 2014-03-04 06:33:17 --> Router Class Initialized
DEBUG - 2014-03-04 06:33:17 --> Output Class Initialized
DEBUG - 2014-03-04 06:33:17 --> Security Class Initialized
DEBUG - 2014-03-04 06:33:17 --> Input Class Initialized
DEBUG - 2014-03-04 06:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:33:17 --> Language Class Initialized
DEBUG - 2014-03-04 06:33:17 --> Loader Class Initialized
DEBUG - 2014-03-04 06:33:17 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:33:17 --> Session Class Initialized
DEBUG - 2014-03-04 06:33:17 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:33:17 --> Session routines successfully run
DEBUG - 2014-03-04 06:33:17 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:33:17 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:33:18 --> Controller Class Initialized
DEBUG - 2014-03-04 06:33:18 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:33:18 --> Model Class Initialized
ERROR - 2014-03-04 06:33:18 --> Severity: Notice  --> Array to string conversion C:\wamp\www\nas\application\controllers\query.php 41
DEBUG - 2014-03-04 06:33:18 --> Final output sent to browser
DEBUG - 2014-03-04 06:33:18 --> Total execution time: 0.5610
DEBUG - 2014-03-04 06:34:36 --> Config Class Initialized
DEBUG - 2014-03-04 06:34:36 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:34:36 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:34:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:34:36 --> URI Class Initialized
DEBUG - 2014-03-04 06:34:36 --> Router Class Initialized
DEBUG - 2014-03-04 06:34:36 --> Output Class Initialized
DEBUG - 2014-03-04 06:34:37 --> Security Class Initialized
DEBUG - 2014-03-04 06:34:37 --> Input Class Initialized
DEBUG - 2014-03-04 06:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:34:37 --> Language Class Initialized
DEBUG - 2014-03-04 06:34:37 --> Loader Class Initialized
DEBUG - 2014-03-04 06:34:37 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:34:37 --> Session Class Initialized
DEBUG - 2014-03-04 06:34:37 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:34:37 --> Session routines successfully run
DEBUG - 2014-03-04 06:34:37 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:34:37 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:34:37 --> Controller Class Initialized
DEBUG - 2014-03-04 06:34:37 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:34:37 --> Model Class Initialized
DEBUG - 2014-03-04 06:34:37 --> Final output sent to browser
DEBUG - 2014-03-04 06:34:37 --> Total execution time: 0.5688
DEBUG - 2014-03-04 06:36:34 --> Config Class Initialized
DEBUG - 2014-03-04 06:36:34 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:36:34 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:36:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:36:34 --> URI Class Initialized
DEBUG - 2014-03-04 06:36:34 --> Router Class Initialized
DEBUG - 2014-03-04 06:36:34 --> Output Class Initialized
DEBUG - 2014-03-04 06:36:34 --> Security Class Initialized
DEBUG - 2014-03-04 06:36:34 --> Input Class Initialized
DEBUG - 2014-03-04 06:36:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:36:34 --> Language Class Initialized
DEBUG - 2014-03-04 06:36:34 --> Loader Class Initialized
DEBUG - 2014-03-04 06:36:34 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:36:34 --> Session Class Initialized
DEBUG - 2014-03-04 06:36:34 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:36:34 --> Session routines successfully run
DEBUG - 2014-03-04 06:36:34 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:36:34 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:36:34 --> Controller Class Initialized
DEBUG - 2014-03-04 06:36:34 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:36:35 --> Model Class Initialized
DEBUG - 2014-03-04 06:36:35 --> Final output sent to browser
DEBUG - 2014-03-04 06:36:35 --> Total execution time: 0.5660
DEBUG - 2014-03-04 06:46:16 --> Config Class Initialized
DEBUG - 2014-03-04 06:46:16 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:46:16 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:46:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:46:16 --> URI Class Initialized
DEBUG - 2014-03-04 06:46:16 --> Router Class Initialized
DEBUG - 2014-03-04 06:46:16 --> Output Class Initialized
DEBUG - 2014-03-04 06:46:16 --> Security Class Initialized
DEBUG - 2014-03-04 06:46:16 --> Input Class Initialized
DEBUG - 2014-03-04 06:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:46:17 --> Language Class Initialized
DEBUG - 2014-03-04 06:46:17 --> Loader Class Initialized
DEBUG - 2014-03-04 06:46:17 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:46:17 --> Session Class Initialized
DEBUG - 2014-03-04 06:46:17 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:46:17 --> Session routines successfully run
DEBUG - 2014-03-04 06:46:17 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:46:17 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:46:17 --> Controller Class Initialized
DEBUG - 2014-03-04 06:46:17 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:46:17 --> Model Class Initialized
DEBUG - 2014-03-04 06:46:17 --> Final output sent to browser
DEBUG - 2014-03-04 06:46:17 --> Total execution time: 0.6212
DEBUG - 2014-03-04 06:46:29 --> Config Class Initialized
DEBUG - 2014-03-04 06:46:29 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:46:29 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:46:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:46:29 --> URI Class Initialized
DEBUG - 2014-03-04 06:46:29 --> Router Class Initialized
DEBUG - 2014-03-04 06:46:29 --> Output Class Initialized
DEBUG - 2014-03-04 06:46:29 --> Security Class Initialized
DEBUG - 2014-03-04 06:46:29 --> Input Class Initialized
DEBUG - 2014-03-04 06:46:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:46:29 --> Language Class Initialized
DEBUG - 2014-03-04 06:46:29 --> Loader Class Initialized
DEBUG - 2014-03-04 06:46:29 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:46:29 --> Session Class Initialized
DEBUG - 2014-03-04 06:46:29 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:46:29 --> Session routines successfully run
DEBUG - 2014-03-04 06:46:30 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:46:30 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:46:30 --> Controller Class Initialized
DEBUG - 2014-03-04 06:46:30 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:46:30 --> Model Class Initialized
DEBUG - 2014-03-04 06:46:30 --> Final output sent to browser
DEBUG - 2014-03-04 06:46:30 --> Total execution time: 0.5212
DEBUG - 2014-03-04 06:46:53 --> Config Class Initialized
DEBUG - 2014-03-04 06:46:53 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:46:53 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:46:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:46:53 --> URI Class Initialized
DEBUG - 2014-03-04 06:46:53 --> Router Class Initialized
DEBUG - 2014-03-04 06:46:53 --> Output Class Initialized
DEBUG - 2014-03-04 06:46:53 --> Security Class Initialized
DEBUG - 2014-03-04 06:46:53 --> Input Class Initialized
DEBUG - 2014-03-04 06:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:46:53 --> Language Class Initialized
DEBUG - 2014-03-04 06:46:53 --> Loader Class Initialized
DEBUG - 2014-03-04 06:46:53 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:46:53 --> Session Class Initialized
DEBUG - 2014-03-04 06:46:53 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:46:53 --> Session routines successfully run
DEBUG - 2014-03-04 06:46:53 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:46:54 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:46:54 --> Controller Class Initialized
DEBUG - 2014-03-04 06:46:54 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:46:54 --> Model Class Initialized
DEBUG - 2014-03-04 06:46:54 --> Final output sent to browser
DEBUG - 2014-03-04 06:46:54 --> Total execution time: 0.4731
DEBUG - 2014-03-04 06:48:28 --> Config Class Initialized
DEBUG - 2014-03-04 06:48:28 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:48:28 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:48:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:48:28 --> URI Class Initialized
DEBUG - 2014-03-04 06:48:28 --> Router Class Initialized
DEBUG - 2014-03-04 06:48:28 --> Output Class Initialized
DEBUG - 2014-03-04 06:48:28 --> Security Class Initialized
DEBUG - 2014-03-04 06:48:28 --> Input Class Initialized
DEBUG - 2014-03-04 06:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:48:28 --> Language Class Initialized
DEBUG - 2014-03-04 06:48:28 --> Loader Class Initialized
DEBUG - 2014-03-04 06:48:28 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:48:28 --> Session Class Initialized
DEBUG - 2014-03-04 06:48:28 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:48:28 --> Session routines successfully run
DEBUG - 2014-03-04 06:48:28 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:48:28 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:48:28 --> Controller Class Initialized
DEBUG - 2014-03-04 06:48:28 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:48:28 --> Model Class Initialized
DEBUG - 2014-03-04 06:48:28 --> Final output sent to browser
DEBUG - 2014-03-04 06:48:28 --> Total execution time: 0.4539
DEBUG - 2014-03-04 06:48:41 --> Config Class Initialized
DEBUG - 2014-03-04 06:48:41 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:48:41 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:48:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:48:42 --> URI Class Initialized
DEBUG - 2014-03-04 06:48:42 --> Router Class Initialized
DEBUG - 2014-03-04 06:48:42 --> Output Class Initialized
DEBUG - 2014-03-04 06:48:42 --> Security Class Initialized
DEBUG - 2014-03-04 06:48:42 --> Input Class Initialized
DEBUG - 2014-03-04 06:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:48:42 --> Language Class Initialized
DEBUG - 2014-03-04 06:48:42 --> Loader Class Initialized
DEBUG - 2014-03-04 06:48:42 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:48:42 --> Session Class Initialized
DEBUG - 2014-03-04 06:48:42 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:48:42 --> Session routines successfully run
DEBUG - 2014-03-04 06:48:42 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:48:42 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:48:42 --> Controller Class Initialized
DEBUG - 2014-03-04 06:48:42 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:48:42 --> Model Class Initialized
DEBUG - 2014-03-04 06:48:42 --> Final output sent to browser
DEBUG - 2014-03-04 06:48:42 --> Total execution time: 0.6462
DEBUG - 2014-03-04 06:49:37 --> Config Class Initialized
DEBUG - 2014-03-04 06:49:37 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:49:37 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:49:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:49:37 --> URI Class Initialized
DEBUG - 2014-03-04 06:49:37 --> Router Class Initialized
DEBUG - 2014-03-04 06:49:37 --> Output Class Initialized
DEBUG - 2014-03-04 06:49:37 --> Security Class Initialized
DEBUG - 2014-03-04 06:49:37 --> Input Class Initialized
DEBUG - 2014-03-04 06:49:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:49:37 --> Language Class Initialized
DEBUG - 2014-03-04 06:49:37 --> Loader Class Initialized
DEBUG - 2014-03-04 06:49:37 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:49:38 --> Session Class Initialized
DEBUG - 2014-03-04 06:49:38 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:49:38 --> Session routines successfully run
DEBUG - 2014-03-04 06:49:38 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:49:38 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:49:38 --> Controller Class Initialized
DEBUG - 2014-03-04 06:49:38 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:49:38 --> Model Class Initialized
DEBUG - 2014-03-04 06:49:38 --> Final output sent to browser
DEBUG - 2014-03-04 06:49:38 --> Total execution time: 0.4937
DEBUG - 2014-03-04 06:49:44 --> Config Class Initialized
DEBUG - 2014-03-04 06:49:44 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:49:44 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:49:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:49:44 --> URI Class Initialized
DEBUG - 2014-03-04 06:49:44 --> Router Class Initialized
DEBUG - 2014-03-04 06:49:44 --> Output Class Initialized
DEBUG - 2014-03-04 06:49:44 --> Security Class Initialized
DEBUG - 2014-03-04 06:49:44 --> Input Class Initialized
DEBUG - 2014-03-04 06:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:49:44 --> Language Class Initialized
DEBUG - 2014-03-04 06:49:44 --> Loader Class Initialized
DEBUG - 2014-03-04 06:49:44 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:49:44 --> Session Class Initialized
DEBUG - 2014-03-04 06:49:44 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:49:44 --> Session routines successfully run
DEBUG - 2014-03-04 06:49:44 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:49:44 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:49:44 --> Controller Class Initialized
DEBUG - 2014-03-04 06:49:44 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:49:44 --> Model Class Initialized
DEBUG - 2014-03-04 06:49:44 --> Final output sent to browser
DEBUG - 2014-03-04 06:49:44 --> Total execution time: 0.4956
DEBUG - 2014-03-04 06:49:48 --> Config Class Initialized
DEBUG - 2014-03-04 06:49:48 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:49:48 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:49:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:49:48 --> URI Class Initialized
DEBUG - 2014-03-04 06:49:48 --> Router Class Initialized
DEBUG - 2014-03-04 06:49:48 --> Output Class Initialized
DEBUG - 2014-03-04 06:49:48 --> Security Class Initialized
DEBUG - 2014-03-04 06:49:48 --> Input Class Initialized
DEBUG - 2014-03-04 06:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:49:48 --> Language Class Initialized
DEBUG - 2014-03-04 06:49:48 --> Loader Class Initialized
DEBUG - 2014-03-04 06:49:48 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:49:48 --> Session Class Initialized
DEBUG - 2014-03-04 06:49:48 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:49:48 --> Session routines successfully run
DEBUG - 2014-03-04 06:49:48 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:49:48 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:49:48 --> Controller Class Initialized
DEBUG - 2014-03-04 06:49:48 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:49:48 --> Model Class Initialized
DEBUG - 2014-03-04 06:49:48 --> Final output sent to browser
DEBUG - 2014-03-04 06:49:48 --> Total execution time: 0.4330
DEBUG - 2014-03-04 06:50:06 --> Config Class Initialized
DEBUG - 2014-03-04 06:50:06 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:50:06 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:50:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:50:06 --> URI Class Initialized
DEBUG - 2014-03-04 06:50:06 --> Router Class Initialized
DEBUG - 2014-03-04 06:50:06 --> Output Class Initialized
DEBUG - 2014-03-04 06:50:06 --> Security Class Initialized
DEBUG - 2014-03-04 06:50:06 --> Input Class Initialized
DEBUG - 2014-03-04 06:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:50:06 --> Language Class Initialized
DEBUG - 2014-03-04 06:50:06 --> Loader Class Initialized
DEBUG - 2014-03-04 06:50:06 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:50:06 --> Session Class Initialized
DEBUG - 2014-03-04 06:50:06 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:50:07 --> Session routines successfully run
DEBUG - 2014-03-04 06:50:07 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:50:07 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:50:07 --> Controller Class Initialized
DEBUG - 2014-03-04 06:50:07 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:50:07 --> Model Class Initialized
DEBUG - 2014-03-04 06:50:07 --> Final output sent to browser
DEBUG - 2014-03-04 06:50:07 --> Total execution time: 0.5683
DEBUG - 2014-03-04 06:52:03 --> Config Class Initialized
DEBUG - 2014-03-04 06:52:03 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:52:03 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:52:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:52:03 --> URI Class Initialized
DEBUG - 2014-03-04 06:52:03 --> Router Class Initialized
DEBUG - 2014-03-04 06:52:03 --> Output Class Initialized
DEBUG - 2014-03-04 06:52:03 --> Security Class Initialized
DEBUG - 2014-03-04 06:52:03 --> Input Class Initialized
DEBUG - 2014-03-04 06:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:52:03 --> Language Class Initialized
DEBUG - 2014-03-04 06:52:03 --> Loader Class Initialized
DEBUG - 2014-03-04 06:52:03 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:52:03 --> Session Class Initialized
DEBUG - 2014-03-04 06:52:03 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:52:03 --> Session routines successfully run
DEBUG - 2014-03-04 06:52:04 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:52:04 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:52:04 --> Controller Class Initialized
DEBUG - 2014-03-04 06:52:04 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:52:04 --> Model Class Initialized
DEBUG - 2014-03-04 06:52:04 --> Final output sent to browser
DEBUG - 2014-03-04 06:52:04 --> Total execution time: 0.5698
DEBUG - 2014-03-04 06:52:07 --> Config Class Initialized
DEBUG - 2014-03-04 06:52:07 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:52:07 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:52:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:52:07 --> URI Class Initialized
DEBUG - 2014-03-04 06:52:07 --> Router Class Initialized
DEBUG - 2014-03-04 06:52:07 --> Output Class Initialized
DEBUG - 2014-03-04 06:52:07 --> Security Class Initialized
DEBUG - 2014-03-04 06:52:07 --> Input Class Initialized
DEBUG - 2014-03-04 06:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:52:07 --> Language Class Initialized
DEBUG - 2014-03-04 06:52:07 --> Loader Class Initialized
DEBUG - 2014-03-04 06:52:07 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:52:07 --> Session Class Initialized
DEBUG - 2014-03-04 06:52:07 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:52:07 --> Session routines successfully run
DEBUG - 2014-03-04 06:52:07 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:52:07 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:52:07 --> Controller Class Initialized
DEBUG - 2014-03-04 06:52:07 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:52:07 --> Model Class Initialized
DEBUG - 2014-03-04 06:52:07 --> Final output sent to browser
DEBUG - 2014-03-04 06:52:07 --> Total execution time: 0.5259
DEBUG - 2014-03-04 06:53:00 --> Config Class Initialized
DEBUG - 2014-03-04 06:53:00 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:53:00 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:53:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:53:00 --> URI Class Initialized
DEBUG - 2014-03-04 06:53:00 --> Router Class Initialized
DEBUG - 2014-03-04 06:53:00 --> Output Class Initialized
DEBUG - 2014-03-04 06:53:00 --> Security Class Initialized
DEBUG - 2014-03-04 06:53:00 --> Input Class Initialized
DEBUG - 2014-03-04 06:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:53:00 --> Language Class Initialized
DEBUG - 2014-03-04 06:53:00 --> Loader Class Initialized
DEBUG - 2014-03-04 06:53:00 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:53:00 --> Session Class Initialized
DEBUG - 2014-03-04 06:53:00 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:53:00 --> Session routines successfully run
DEBUG - 2014-03-04 06:53:00 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:53:00 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:53:00 --> Controller Class Initialized
DEBUG - 2014-03-04 06:53:00 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:53:00 --> this->setMessage()
DEBUG - 2014-03-04 06:53:00 --> File loaded: application/views/query.php
DEBUG - 2014-03-04 06:53:00 --> File loaded: application/views/master.php
DEBUG - 2014-03-04 06:53:00 --> Final output sent to browser
DEBUG - 2014-03-04 06:53:00 --> Total execution time: 0.6053
DEBUG - 2014-03-04 06:53:08 --> Config Class Initialized
DEBUG - 2014-03-04 06:53:08 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:53:08 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:53:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:53:08 --> URI Class Initialized
DEBUG - 2014-03-04 06:53:09 --> Router Class Initialized
DEBUG - 2014-03-04 06:53:09 --> Output Class Initialized
DEBUG - 2014-03-04 06:53:09 --> Security Class Initialized
DEBUG - 2014-03-04 06:53:09 --> Input Class Initialized
DEBUG - 2014-03-04 06:53:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:53:09 --> Language Class Initialized
DEBUG - 2014-03-04 06:53:09 --> Loader Class Initialized
DEBUG - 2014-03-04 06:53:09 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:53:09 --> Session Class Initialized
DEBUG - 2014-03-04 06:53:09 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:53:09 --> Session routines successfully run
DEBUG - 2014-03-04 06:53:09 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:53:09 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:53:09 --> Controller Class Initialized
DEBUG - 2014-03-04 06:53:09 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:53:09 --> Model Class Initialized
DEBUG - 2014-03-04 06:53:09 --> Final output sent to browser
DEBUG - 2014-03-04 06:53:09 --> Total execution time: 0.6028
DEBUG - 2014-03-04 06:53:15 --> Config Class Initialized
DEBUG - 2014-03-04 06:53:15 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:53:15 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:53:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:53:15 --> URI Class Initialized
DEBUG - 2014-03-04 06:53:15 --> Router Class Initialized
DEBUG - 2014-03-04 06:53:15 --> Output Class Initialized
DEBUG - 2014-03-04 06:53:15 --> Security Class Initialized
DEBUG - 2014-03-04 06:53:15 --> Input Class Initialized
DEBUG - 2014-03-04 06:53:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:53:15 --> Language Class Initialized
DEBUG - 2014-03-04 06:53:15 --> Loader Class Initialized
DEBUG - 2014-03-04 06:53:15 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:53:15 --> Session Class Initialized
DEBUG - 2014-03-04 06:53:15 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:53:16 --> Session routines successfully run
DEBUG - 2014-03-04 06:53:16 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:53:16 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:53:16 --> Controller Class Initialized
DEBUG - 2014-03-04 06:53:16 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:53:16 --> Model Class Initialized
DEBUG - 2014-03-04 06:53:16 --> Final output sent to browser
DEBUG - 2014-03-04 06:53:16 --> Total execution time: 0.3733
DEBUG - 2014-03-04 06:53:55 --> Config Class Initialized
DEBUG - 2014-03-04 06:53:55 --> Hooks Class Initialized
DEBUG - 2014-03-04 06:53:55 --> Utf8 Class Initialized
DEBUG - 2014-03-04 06:53:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-04 06:53:55 --> URI Class Initialized
DEBUG - 2014-03-04 06:53:55 --> Router Class Initialized
DEBUG - 2014-03-04 06:53:55 --> Output Class Initialized
DEBUG - 2014-03-04 06:53:55 --> Security Class Initialized
DEBUG - 2014-03-04 06:53:55 --> Input Class Initialized
DEBUG - 2014-03-04 06:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-04 06:53:55 --> Language Class Initialized
DEBUG - 2014-03-04 06:53:55 --> Loader Class Initialized
DEBUG - 2014-03-04 06:53:55 --> Database Driver Class Initialized
DEBUG - 2014-03-04 06:53:55 --> Session Class Initialized
DEBUG - 2014-03-04 06:53:55 --> Helper loaded: string_helper
DEBUG - 2014-03-04 06:53:55 --> Session routines successfully run
DEBUG - 2014-03-04 06:53:55 --> XML-RPC Class Initialized
DEBUG - 2014-03-04 06:53:55 --> User Agent Class Initialized
DEBUG - 2014-03-04 06:53:55 --> Controller Class Initialized
DEBUG - 2014-03-04 06:53:55 --> Helper loaded: url_helper
DEBUG - 2014-03-04 06:53:55 --> Model Class Initialized
DEBUG - 2014-03-04 06:53:55 --> Final output sent to browser
DEBUG - 2014-03-04 06:53:55 --> Total execution time: 0.6357
