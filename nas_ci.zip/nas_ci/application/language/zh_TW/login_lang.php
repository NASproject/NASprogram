<?php
$lang["title"] = "人才推薦計畫－實踐大學資管系";
$lang["footer"] = "實踐大學│資訊管理學系";
$lang["contact_address"] = "高雄市內門區大學路200號J-304系辦";
$lang["contact_phone"] = "07-6678888#4261";
// login main form
$lang["formName"] = "使用者登錄";
$lang["lblInstitution"] = "教育機構";//
$lang["hintInstitution"] = "所屬教育機構編號";
$lang["lblIDtype"] = "身分別";
$lang["lblID"] = "帳號／職號";
$lang["lblPassword"] = "密碼";
$lang["btnSubmit"] = "確認";
$lang["btnReset"] = "清除";
$lang["IDType1"] = "教師";
$lang["IDType2"] = "在校生";
$lang["IDType3"] = "業主";
?>
